"""把历史训练集还原成原始字段（含 tx_lon/rx_lon），以便按 (频率,小时) 重算特征。

建库时只存了 tx_lat/rx_lat/mid_lat/mid_lon/distance_km，没存两端经度。
但经度对「距离」和「中点纬度」都是平移不变的：把整条路径沿经度整体平移 Δ，
距离不变、mid_lat 不变、mid_lon 平移 Δ。于是可以：

  1. 令 tx_lon = 0，由 distance 反解 Δlon = ±acos(...)（两个解，东/西镜像）
  2. 算出该摆位下的 mid_lon0，整体平移 (mid_lon − mid_lon0)
  3. 用存好的 zenith_tx/zenith_rx 验证并在两个镜像解中择一

还原结果必须能复现存档里的三个天顶角，否则这一行不可用。
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from models.geo import EARTH_RADIUS_KM, midpoint, solar_zenith_deg


def _delta_lon(lat1: float, lat2: float, dist_km: float) -> float | None:
    """由两端纬度与大圆距离反解经差（取正解；负解为其镜像）。"""
    c = math.cos(dist_km / EARTH_RADIUS_KM)
    p1, p2 = math.radians(lat1), math.radians(lat2)
    denom = math.cos(p1) * math.cos(p2)
    if abs(denom) < 1e-12:
        return None
    v = (c - math.sin(p1) * math.sin(p2)) / denom
    if not (-1.0 <= v <= 1.0):
        return None
    return math.degrees(math.acos(v))


def recover(df: pd.DataFrame) -> pd.DataFrame:
    """新增 tx_lon/rx_lon/hour_utc/month 列，并剔除还原失败的行。"""
    # hour/month 由 sin/cos 反解（建库时就是由它们编码的）
    hour = (np.degrees(np.arctan2(df["sin_hour"], df["cos_hour"])) / 15.0) % 24.0
    month = np.rint(
        (np.degrees(np.arctan2(df["sin_month"], df["cos_month"])) / 30.0) % 12.0
    ).astype(int)
    month = np.where(month == 0, 12, month)

    tx_lon = np.full(len(df), np.nan)
    rx_lon = np.full(len(df), np.nan)
    tx_lat = df["tx_lat"].to_numpy()
    rx_lat = df["rx_lat"].to_numpy()
    dist = df["distance_km"].to_numpy()
    mid_lon = df["mid_lon"].to_numpy()
    z_tx = df["zenith_tx"].to_numpy()
    z_rx = df["zenith_rx"].to_numpy()
    h = hour.to_numpy()

    for i in range(len(df)):
        d = _delta_lon(tx_lat[i], rx_lat[i], dist[i])
        if d is None:
            continue
        best, best_err = None, 1e9
        for sign in (+1.0, -1.0):
            dl = sign * d
            _, ml0 = midpoint(tx_lat[i], 0.0, rx_lat[i], dl)
            shift = mid_lon[i] - ml0
            a = ((0.0 + shift + 540.0) % 360.0) - 180.0
            b = ((dl + shift + 540.0) % 360.0) - 180.0
            err = (abs(solar_zenith_deg(tx_lat[i], a, month[i], h[i]) - z_tx[i])
                   + abs(solar_zenith_deg(rx_lat[i], b, month[i], h[i]) - z_rx[i]))
            if err < best_err:
                best, best_err = (a, b), err
        if best is not None and best_err < 1.0:  # 两端天顶角合计误差 < 1°
            tx_lon[i], rx_lon[i] = best

    out = df.copy()
    out["tx_lon"], out["rx_lon"] = tx_lon, rx_lon
    out["hour_utc"], out["month"] = h, month
    ok = np.isfinite(tx_lon)
    print(f"经度还原成功 {ok.sum()}/{len(df)}（{ok.mean()*100:.1f}%）")
    return out[ok].reset_index(drop=True)


def verify(df: pd.DataFrame) -> None:
    """用还原出的经度重算三个天顶角，与存档值对比。"""
    from models.features import FEATURE_NAMES, build_features

    sub = df.head(3000)
    feats = np.array([build_features({
        "distance_km": r.distance_km, "tx_lat": r.tx_lat, "tx_lon": r.tx_lon,
        "rx_lat": r.rx_lat, "rx_lon": r.rx_lon, "hour_utc": r.hour_utc,
        "month": r.month, "freq_mhz": r.freq_mhz, "ssn": r.ssn,
        "tx_power_dbm": r.tx_power_dbm, "voacap_snr": r.voacap_snr,
        "voacap_muf": r.voacap_muf,
    }) for r in sub.itertuples()])
    worst = 0.0
    for j, name in enumerate(FEATURE_NAMES):
        err = float(np.max(np.abs(feats[:, j] - sub[name].to_numpy())))
        worst = max(worst, err)
        if err > 1e-6:
            print(f"  {name:16s} 最大偏差 {err:.4g}")
    print(f"特征重建最大偏差 {worst:.3g}（应接近 0）")


if __name__ == "__main__":
    d = pd.read_parquet("data/processed/dataset_multiyear.parquet")
    r = recover(d)
    verify(r)
    r.to_parquet("data/processed/_raw_recovered.parquet", index=False)
    print("已写入 data/processed/_raw_recovered.parquet")
