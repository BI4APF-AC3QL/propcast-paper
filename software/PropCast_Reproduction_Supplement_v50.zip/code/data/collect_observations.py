"""后端自采观测：从 PSKReporter 全球实时上报取样，写入 spool 供 ingest。

设计要点
--------
1. **数据源**：PSKReporter 全球实时上报（真实 tx→rx 链路 + 实测 SNR），
   与训练集原有的 WSPR 同为 2500Hz 参考带宽的 SNR，量纲可比。
2. **记录原始字段而非特征向量**：FEATURE_NAMES 未来会演进，存原始字段才能
   在特征变更后重新构建，不必重采。
3. **可信来源**：这一路是我们自己取的数据，标记 trusted=True，因此有资格进入
   评判模型好坏的测试集。用户浏览器上报（contrib-*）只参与训练、不参与评判
   —— 理由见 data/obs_store.py 与 models/retrain.py。

为什么取样要分层，而不是按波段轮转取前 N 条
------------------------------------------
实测一次全球流（30 min 窗口）返回约 1500 条通过校验的链路，其中：

    0-2000km  30.3%   2000-6000km  35.4%   6000-10000km 27.7%
    10000-14000km 5.4%   >14000km 1.2%（99 条 / 18 条）

而原先"按波段轮转取前 120 条"只留下其中 9 条 >10000km、2 条 >14000km ——
**长链路本来就在批次里，是被截断丢掉的**。这一点要紧，因为论文第 5 章的结论是：
模型失效集中在训练支撑稀薄的超长路径（>14000km 段支撑仅 0.1%，输出抖动是物理
模型的数十倍），而那恰是用户查询最集中的跨洲 DX 区间。短链路我们已有 8 万余条，
再多采一万条也改变不了什么；长链路每批只有几十条，丢掉就是真的没有了。

因此改为分层配额：**稀缺的先全收，剩余额度再按波段轮转补齐**。优先级依次是
  (1) 任一端落在关注网格（PROPCAST_PRIORITY_GRIDS）内的链路；
  (2) 距离 ≥ collect_far_km 的长链路；
  (3) 其余按波段轮转，避免全被 20m 占满（该波段上报量常是 160m 的两个数量级）。

关于"按网格定向查询"这条路
------------------------
retrieve.pskreporter.info 的 senderLocator 参数**实测无效**：请求
`senderLocator=QF56` 返回的是未过滤的全球流（1518 条，发射网格全部为
EM29/EN63/FM19 等美欧网格，QF56 开头的 0 条）。因此关注网格只能在**本地过滤**
实现，不能寄望上游按网格返回——好在全球流本就含全球链路，本地筛选不额外消耗
上游配额。该端点限流很严（实测两分钟内 16 次请求即对本机全面 503，并把全球流
一并挡住），每轮 tick 只发一次请求是硬约束。

用法：
    python -m data.collect_observations              # 采一批
    python -m data.collect_observations --limit 200  # 采更多
    python -m data.collect_observations --ingest     # 采完立即并入 parquet
    python -m data.collect_observations --dry-run    # 只看这批的分层构成，不落盘

正常运行时无需手动调用：后端启动后由 propcast.services.trainer 定时执行。
"""
from __future__ import annotations

import argparse
import asyncio
import re
from datetime import datetime, timezone

from data.obs_store import grid_to_latlon, ingest, spool_append
from data.obs_store import normalize as _normalize

__all__ = ["collect", "grid_to_latlon", "select_stratified"]

_GRID4_RE = re.compile(r"^[A-R]{2}\d{2}$", re.IGNORECASE)
# 采集时不截断每波段条数：分层选取必须看到整批，否则稀缺的长链路会在看到之前
# 就被 per_band_cap 砍掉——那正是本模块要解决的问题。
_NO_CAP = 10_000


def _priority_grids() -> set[str]:
    from propcast.config import settings

    out = set()
    for g in settings.priority_grids or []:
        g = (g or "").strip().upper()
        if _GRID4_RE.match(g):
            out.add(g)
    return out


def _touches(row: dict, grids: set[str]) -> bool:
    """链路任一端落在关注网格内。收发两端都算——两个方向的观测同样有价值。"""
    if not grids:
        return False
    return (str(row.get("tx_grid") or "")[:4].upper() in grids
            or str(row.get("rx_grid") or "")[:4].upper() in grids)


def select_stratified(rows: list[dict], limit: int, far_km: float,
                      grids: set[str] | None = None,
                      far_share: float = 1.0) -> tuple[list[dict], dict]:
    """按稀缺程度分层选取，返回 (选中的行, 各层计数)。

    rows 为已归一化的行（含 distance_km / band / tx_grid / rx_grid）。
    稀缺的先收：关注网格 → 长链路（远的优先）→ 其余按波段轮转补齐。

    far_share 限制长链路最多占额度的多大比例。不加这个上限的话，实测一批里有 99 条
    长链路而额度只有 120，会变成 82% 的采集都是长链路——偏斜强度完全由当批内容决定，
    不可控；而且可信测试集也随之改变构成（长链路 RMSE 高达 78.9 dB），使重训之间的
    纵向指标更难解读（该效应在论文 6.5 节已有讨论）。取 1.0 即不限制。
    """
    grids = grids or set()
    far_budget = max(0, int(limit * max(0.0, min(1.0, far_share))))
    picked: list[dict] = []
    seen: set[int] = set()
    stats = {"priority": 0, "far": 0, "filler": 0}

    def take(r: dict, kind: str) -> bool:
        if len(picked) >= limit or id(r) in seen:
            return False
        seen.add(id(r))
        picked.append(r)
        stats[kind] += 1
        return True

    for r in rows:
        if _touches(r, grids):
            take(r, "priority")
    # 最远的优先——>14000km 每批只有十几条，是最稀缺的
    for r in sorted((x for x in rows if x["distance_km"] >= far_km),
                    key=lambda x: -x["distance_km"]):
        if stats["far"] >= far_budget:
            break
        take(r, "far")

    # 剩余额度按波段轮转，保持波段多样性
    buckets: dict[str, list[dict]] = {}
    for r in rows:
        if id(r) not in seen:
            buckets.setdefault(r["band"], []).append(r)
    order = list(buckets.values())
    i = 0
    while len(picked) < limit and any(i < len(b) for b in order):
        for b in order:
            if len(picked) >= limit:
                break          # 额度用完；不要写成靠 take() 的返回值判断，
            if i < len(b):     # 那样一旦以后有重复行混进 buckets 就会误当额度已满
                take(b[i], "filler")
        i += 1
    return picked, stats


async def collect(limit: int = 60, do_ingest: bool = False,
                  dry_run: bool = False) -> dict:
    """采一批全球链路 → 校验归一化 → 分层选取 → 落 spool。"""
    from propcast.config import settings
    from propcast.services.pskreporter import get_psk_global_spots

    # 拉全球流是一次几秒的阻塞 HTTP，放线程里，别卡住调用方的事件循环。
    # 不截断每波段条数：选取要在整批上做。
    glob = await asyncio.to_thread(
        get_psk_global_spots, settings.collect_window_min, _NO_CAP, 60)
    if not glob.get("ok"):
        return {"ok": False, "error": glob.get("error", "PSKReporter 不可用"), "spooled": 0}

    now = int(datetime.now(timezone.utc).timestamp())
    rows: list[dict] = []
    for b in glob.get("by_band", {}).values():
        for s in b:
            # 全球分组接口不含 time 字段；窗口内取样，以取样时刻近似观测时刻
            row = _normalize({
                "ts": now,
                "tx_call": s.get("tx"), "rx_call": s.get("rx"),
                "tx_grid": s.get("tx_grid"), "rx_grid": s.get("rx_grid"),
                "freq_mhz": float(s.get("freq_khz") or 0) / 1000.0,
                "mode": s.get("mode"), "snr": s.get("snr"),
            }, source="pskreporter", now=now)
            if row:
                # 分层要用到网格，normalize 只留经纬度，这里补回去
                row = dict(row, tx_grid=s.get("tx_grid"), rx_grid=s.get("rx_grid"))
                rows.append(row)

    picked, stats = select_stratified(rows, limit, settings.collect_far_km,
                                      _priority_grids(), settings.collect_far_share)
    for r in picked:  # spool 不需要网格列，去掉以免污染 schema
        r.pop("tx_grid", None)
        r.pop("rx_grid", None)

    far = sum(r["distance_km"] >= settings.collect_far_km for r in picked)
    out: dict = {
        "ok": True, "available": len(rows), "selected": len(picked),
        "far": far, "layers": stats,
    }
    if dry_run:
        out["spooled"] = 0
        return out

    n = spool_append(picked)
    out["spooled"] = n
    out["ok"] = bool(n)
    if not n:
        out["error"] = "本批无有效观测"
    if do_ingest:
        out["ingest"] = await ingest()
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=60, help="本批最多采集的链路数")
    ap.add_argument("--ingest", action="store_true", help="采完立即并入 parquet")
    ap.add_argument("--dry-run", action="store_true", help="只报告分层构成，不落盘")
    a = ap.parse_args()
    print(asyncio.run(collect(a.limit, a.ingest, a.dry_run)))


if __name__ == "__main__":
    main()
