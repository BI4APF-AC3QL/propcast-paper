"""数据采集与训练集构建包（Phase 3 实装）。

预期模块：
  - ingest_wspr.py    : 拉取 WSPR/RBN/PSKReporter 实测链路记录
  - build_dataset.py  : 与太阳指数对齐，构建 (特征, 标签) 训练集
"""
