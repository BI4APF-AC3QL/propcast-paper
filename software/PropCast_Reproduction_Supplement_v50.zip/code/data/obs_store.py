"""观测数据仓库 —— 「越多人用、跑得越久、模型越准」的落点。

三段式写入管线
--------------
    浏览器/采集器  --POST/直写-->  spool(.jsonl 追加)  --ingest-->  observations.parquet

为什么中间要有 spool 而不是直接写 parquet：
* 部署是**双进程** uvicorn（0.0.0.0 与 :: 各一个），两个进程同时改写同一个
  parquet 会互相覆盖甚至写坏文件。JSONL 以 O_APPEND 短句柄追加，多进程安全。
* POST 路径必须快。VOACAP 基线要按链路逐条算，放在 ingest 批量做，
  上报接口只做校验与落盘。

ingest 时才做的事：补当时的空间天气（SSN/SFI/Kp）、算 VOACAP 基线与残差、去重。

数据可信度分层（重要）
--------------------
``source`` 区分数据来源，``trusted`` 标记该行是否由**我们自己**取得：
* ``wspr-historical`` / ``pskreporter`` —— 后端自采，trusted=True
* ``contrib-psk`` / ``contrib-qso`` —— 用户浏览器上报，trusted=False

服务开在公网上，上报接口谁都能调。因此**评估模型好坏时只用 trusted 数据**
（见 models/retrain.py）：用户数据可以参与训练，但不能给自己作证。
"""
from __future__ import annotations

import json
import math
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

_DIR = Path(__file__).parent / "processed"
OBS_PATH = _DIR / "observations.parquet"
SPOOL = _DIR / "spool.jsonl"

# 自采数据可信；浏览器上报的一律不可信（用于训练，不用于评判模型）
TRUSTED_SOURCES = {"wspr-historical", "pskreporter"}

# 去重键：同一时刻、同一对呼号、同一频率视为同一条观测
_KEY = ["ts", "tx_call", "rx_call", "freq_mhz"]

# VOACAP 有效频段（2–30 MHz）内的业余波段。60m 保留：5.3 MHz 在范围内。
HF_ONLY = {"160m", "80m", "60m", "40m", "30m", "20m", "17m", "15m", "12m", "10m"}

MAX_BATCH = 200  # 单次上报最多条数
_MAX_AGE_S = 24 * 3600  # 太旧的观测（空间天气已对不上）丢弃
_MIN_KM, _MAX_KM = 200.0, 20_100.0  # 过近以地波为主；上限为对跖点距离
_MIN_SNR, _MAX_SNR = -40.0, 40.0


def grid_to_latlon(grid: str) -> tuple[float, float] | None:
    """Maidenhead → 经纬度（网格中心）。与前端 fromGrid 同一套换算。"""
    g = (grid or "").strip().upper()
    if len(g) < 4 or not g[0].isalpha() or not g[1].isalpha() or not g[2:4].isdigit():
        return None
    try:
        lon = (ord(g[0]) - 65) * 20 - 180 + int(g[2]) * 2
        lat = (ord(g[1]) - 65) * 10 - 90 + int(g[3])
    except (ValueError, IndexError):
        return None
    if len(g) >= 6 and g[4].isalpha() and g[5].isalpha():
        lon += (ord(g[4]) - 65) * (2 / 24) + 1 / 24
        lat += (ord(g[5]) - 65) * (1 / 24) + 0.5 / 24
    else:
        lon += 1.0
        lat += 0.5
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        return None
    return lat, lon


# --------------------------------------------------------------------------- #
# 校验 —— 接口在公网上，任何字段都可能是伪造/畸形的
# --------------------------------------------------------------------------- #
def normalize(raw: dict[str, Any], source: str, now: float | None = None) -> dict | None:
    """把一条上报归一化为 spool 行；任何不合规的字段直接丢弃该条（返回 None）。

    只做**不需要外部依赖**的检查，保证上报接口是纯 CPU、可在请求线程里跑完。
    """
    from propcast.bands import band_of_hz

    now = time.time() if now is None else now
    try:
        ts = int(raw.get("ts") or 0)
        freq_mhz = float(raw.get("freq_mhz") or 0)
        snr = raw.get("snr")
        snr = None if snr is None or snr == "" else float(snr)
    except (TypeError, ValueError):
        return None
    if not (now - _MAX_AGE_S <= ts <= now + 300):
        return None
    band = band_of_hz(freq_mhz * 1e6)
    # 只收 HF。VOACAP 的适用范围是 2–30 MHz，喂 6m/2m 会算出 -1169 dB 这种
    # 完全无意义的基线，而残差正是以它为基准——一条这样的记录就能把训练集拖歪。
    if band is None or band not in HF_ONLY:
        return None

    tx = grid_to_latlon(str(raw.get("tx_grid") or ""))
    rx = grid_to_latlon(str(raw.get("rx_grid") or ""))
    if tx is None or rx is None:
        return None
    from models.geo import great_circle_km

    dist = great_circle_km(tx[0], tx[1], rx[0], rx[1])
    if not (_MIN_KM <= dist <= _MAX_KM):
        return None
    if snr is not None and not (_MIN_SNR <= snr <= _MAX_SNR):
        return None

    power_w = raw.get("tx_power_w")
    try:
        power_w = float(power_w) if power_w else 0.0
    except (TypeError, ValueError):
        power_w = 0.0
    if not (0 < power_w <= 1500):
        power_w = 50.0  # 未提供/离谱时取常见值；PSKReporter 本就无功率字段

    return {
        "ts": ts,
        "tx_call": str(raw.get("tx_call") or "")[:16].upper(),
        "rx_call": str(raw.get("rx_call") or "")[:16].upper(),
        "tx_lat": tx[0], "tx_lon": tx[1], "rx_lat": rx[0], "rx_lon": rx[1],
        "distance_km": dist,
        "freq_mhz": freq_mhz, "band": band,
        "mode": str(raw.get("mode") or "")[:12].upper(),
        "snr": snr,
        "tx_power_w": power_w,
        "source": source,
    }


# --------------------------------------------------------------------------- #
# spool：多进程安全的追加
# --------------------------------------------------------------------------- #
def spool_append(rows: Iterable[dict]) -> int:
    """把归一化后的行追加进 spool。短句柄 + O_APPEND，多进程并发安全。"""
    rows = [r for r in rows if r]
    if not rows:
        return 0
    _DIR.mkdir(parents=True, exist_ok=True)
    payload = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows)
    with open(SPOOL, "a", encoding="utf-8") as f:
        f.write(payload)
    return len(rows)


def _stage_spool() -> list[Path]:
    """把当前 spool 改名为 .staged 后独占处理，避免与追加写竞争。

    写入方持有句柄的时间极短（一次 open/write/close），改名偶发失败时直接跳过，
    下一轮 ingest 再来即可 —— 不会丢数据。历史遗留的 .staged 也一并处理。
    """
    staged = sorted(_DIR.glob("spool-*.staged")) if _DIR.is_dir() else []
    if SPOOL.exists():
        target = _DIR / f"spool-{int(time.time())}.staged"
        try:
            SPOOL.rename(target)
            staged.append(target)
        except OSError:
            pass  # 正被写入，下轮再处理
    return staged


# --------------------------------------------------------------------------- #
# ingest：spool -> parquet（补空间天气 + VOACAP 基线 + 残差）
# --------------------------------------------------------------------------- #
async def ingest() -> dict:
    """把 spool 中的原始上报转成带 VOACAP 基线与残差的观测，合并进 parquet。

    返回 {"added": n, "staged": m, "total": N}。无数据时是无副作用的空操作。
    逐条跑 VOACAP + 读写 parquet 都是阻塞的重活，放到线程里做，
    否则后台学习循环每次入库都会把整站卡住几秒。
    """
    import asyncio

    from propcast.services.spaceweather import get_space_weather

    staged = _stage_spool()
    raws: list[dict] = []
    for p in staged:
        try:
            for line in p.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    try:
                        raws.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        except OSError:
            continue
    if not raws:
        for p in staged:
            p.unlink(missing_ok=True)
        return {"added": 0, "staged": 0, "total": _total()}

    sw = await get_space_weather()
    ssn = float(sw.get("ssn") or 100.0)
    sfi = float(sw.get("sfi") or 100.0)
    kp = float(sw.get("kp") if sw.get("kp") is not None else 2.0)

    added = await asyncio.to_thread(_ingest_sync, raws, ssn, sfi, kp)
    for p in staged:
        p.unlink(missing_ok=True)
    return {"added": added, "staged": len(raws), "total": _total()}


def _ingest_sync(raws: list[dict], ssn: float, sfi: float, kp: float) -> int:
    """CPU/IO 密集部分：逐条算 VOACAP 基线与残差，然后并入 parquet。

    基线必须用 ``voacap_point``（实际频率 + 小数小时），与历史训练集的算法完全一致。
    走 ``VoacapModel.predict`` 会用波段代表频率和整点小时，两种口径混进同一个训练集
    等于给 voacap_snr 注入系统性偏差，而残差正是以它为基准算出来的。
    """
    import math as _math

    import pandas as pd
    from dvoacap.path_geometry import GeoPoint
    from dvoacap.prediction_engine import VoacapParams

    from data.build_dataset import _make_engine, voacap_point
    from models.features import clip_baseline

    eng = _make_engine()
    rows: list[dict] = []
    for r in raws:
        try:
            when = datetime.fromtimestamp(int(r["ts"]), tz=timezone.utc)
            hour = when.hour + when.minute / 60.0
            power_w = float(r.get("tx_power_w") or 50.0)
            v_snr, v_muf = voacap_point(
                eng, VoacapParams, GeoPoint,
                r["tx_lat"], r["tx_lon"], r["rx_lat"], r["rx_lon"],
                float(r["freq_mhz"]), hour, when.month, ssn, power_w,
            )
            if not (_math.isfinite(v_snr) and _math.isfinite(v_muf)):
                continue
            snr = r.get("snr")
            rows.append({
                "ts": int(r["ts"]),
                "tx_call": r.get("tx_call", ""), "rx_call": r.get("rx_call", ""),
                "tx_lat": r["tx_lat"], "tx_lon": r["tx_lon"],
                "rx_lat": r["rx_lat"], "rx_lon": r["rx_lon"],
                "distance_km": float(r["distance_km"]),
                "hour_utc": hour, "month": int(when.month),
                "freq_mhz": float(r["freq_mhz"]), "band": r["band"],
                "mode": r.get("mode", ""), "source": r.get("source", "contrib"),
                "trusted": r.get("source") in TRUSTED_SOURCES,
                # 历史 WSPR 数据集永远补不上 Kp（NOAA 只存近一天），
                # 但从现在起采集的每条观测都带着——这正是持续采集的价值
                "ssn": ssn, "sfi": sfi, "kp": kp,
                "tx_power_dbm": 10.0 * math.log10(max(1e-3, power_w)) + 30.0,
                # 基线入库前截断到物理下限。VOACAP 对闭合路径输出 -1772 dB 这类
                # 哨兵值，它表达的是"完全闭合"而非一个标定过的信噪比；原样存下来，
                # residual 就会出现 +1758 dB 这种目标值。这里截断而非丢弃该行——
                # 链路确实被收到了，"物理模型判它闭合却实际通联"正是最该学的样本
                # （实测：丢弃会使这类路径上的预测误差从 84.5 dB 恶化到 214.8 dB）。
                # 截断后仍严格保持 residual = measured_snr - voacap_snr。
                # 取值依据见 models/features.VOACAP_SNR_FLOOR。
                "voacap_snr": clip_baseline(v_snr), "voacap_muf": v_muf,
                # 无实测 SNR 的记录（SSB/CW 的主观 RST）仍然入库：它是「链路确实通了」
                # 的正样本，将来可训练可达概率；但 residual 为空，不参与 SNR 回归。
                "measured_snr": float(snr) if snr is not None else float("nan"),
                "residual": (float(snr) - clip_baseline(v_snr)
                             if snr is not None else float("nan")),
            })
        except Exception:
            continue  # 单条失败不影响整批

    return _merge(pd.DataFrame(rows)) if rows else 0


def _merge(new) -> int:
    """并入 parquet（原子替换），返回净新增行数。"""
    import pandas as pd

    _DIR.mkdir(parents=True, exist_ok=True)
    if OBS_PATH.exists():
        old = pd.read_parquet(OBS_PATH)
        if "trusted" not in old.columns:  # 兼容加入分层之前写下的观测
            old["trusted"] = old.get("source", "pskreporter").isin(TRUSTED_SOURCES) \
                if "source" in old.columns else True
        before = len(old)
        merged = pd.concat([old, new], ignore_index=True).drop_duplicates(subset=_KEY, keep="last")
    else:
        merged, before = new, 0
    tmp = OBS_PATH.with_suffix(".parquet.tmp")
    merged.to_parquet(tmp, index=False)
    os.replace(tmp, OBS_PATH)  # 原子替换：读方永远看到完整文件
    return len(merged) - before


def _total() -> int:
    """行数直接读 parquet footer，不加载数据——观测库会长到百万行级。"""
    if not OBS_PATH.exists():
        return 0
    try:
        import pyarrow.parquet as pq

        return int(pq.ParquetFile(OBS_PATH).metadata.num_rows)
    except Exception:
        return 0


# --------------------------------------------------------------------------- #
# 统计 —— 供 /api/modelstats 展示「数据在增长」
# --------------------------------------------------------------------------- #
# /api/modelstats 每个浏览器标签每 2 分钟拉一次，而 stats() 要整表扫描
# （去重计数、分组统计）。观测库只会越来越大，不缓存的话人越多越慢——
# 恰好和这套设计的目标相反。按 parquet 的 mtime 失效即可，数据变了立刻反映。
_stats_cache: tuple[float, dict] | None = None


def stats() -> dict:
    """观测库概览：总量、来源分布、贡献站点数、时间跨度、待 ingest 条数。"""
    global _stats_cache
    try:
        mtime = OBS_PATH.stat().st_mtime
    except OSError:
        mtime = 0.0
    if _stats_cache and _stats_cache[0] == mtime:
        return {**_stats_cache[1], "pending": _pending()}  # pending 变化快，不缓存
    out = _stats_uncached()
    _stats_cache = (mtime, out)
    return dict(out)


def _stats_uncached() -> dict:
    out: dict[str, Any] = {
        "total": 0, "by_source": {}, "trusted": 0, "contributed": 0,
        "stations": 0, "first_ts": None, "last_ts": None, "pending": _pending(),
    }
    if not OBS_PATH.exists():
        return out
    try:
        import pandas as pd

        df = pd.read_parquet(OBS_PATH)
    except Exception:
        return out
    out["total"] = len(df)
    if "source" in df.columns:
        out["by_source"] = {str(k): int(v) for k, v in df["source"].value_counts().items()}
        contributed = int((~df["source"].isin(TRUSTED_SOURCES)).sum())
        out["contributed"] = contributed
        out["trusted"] = len(df) - contributed
    if "ts" in df.columns and len(df):
        out["first_ts"] = int(df["ts"].min())
        out["last_ts"] = int(df["ts"].max())
    # 「参与贡献的站点数」：出现过的不同接收方呼号，反映覆盖广度
    if "rx_call" in df.columns:
        out["stations"] = int(df["rx_call"].replace("", None).nunique())
    return out


def _pending() -> int:
    n = 0
    for p in ([SPOOL] if SPOOL.exists() else []) + (list(_DIR.glob("spool-*.staged")) if _DIR.is_dir() else []):
        try:
            with open(p, "r", encoding="utf-8") as f:
                n += sum(1 for line in f if line.strip())
        except OSError:
            continue
    return n
