"""太阳指数 Provider（月度）。

数据源：NOAA SWPC observed-solar-cycle-indices.json（含 ssn / f10.7，1749 至今）。
月度 SSN 正是 VOACAP 的输入，故按年-月 join 与物理模型一致。
本环境下 SILSO/CelesTrak 的日级源被代理拦截，故首版用月度；
日级 Kp 富集留作后续增强。
"""
from __future__ import annotations

import json
import urllib.request
from pathlib import Path

_URL = "https://services.swpc.noaa.gov/json/solar-cycle/observed-solar-cycle-indices.json"
_CACHE = Path(__file__).parent / "cache" / "solar_monthly.json"


class SolarProvider:
    def __init__(self, refresh: bool = False) -> None:
        self._by_month: dict[str, tuple[float, float]] = {}
        self._load(refresh)

    def _load(self, refresh: bool) -> None:
        if not refresh and _CACHE.exists():
            raw = json.loads(_CACHE.read_text(encoding="utf-8"))
        else:
            with urllib.request.urlopen(_URL, timeout=30) as resp:
                raw = json.load(resp)
            _CACHE.parent.mkdir(parents=True, exist_ok=True)
            _CACHE.write_text(json.dumps(raw), encoding="utf-8")

        for row in raw:
            tag = row.get("time-tag")  # "YYYY-MM"
            if not tag:
                continue
            ssn = row.get("ssn", -1.0)
            f107 = row.get("f10.7", -1.0)
            # 取该月有效的 SSN（observed 优先），f10.7 同理
            ssn = row.get("observed_swpc_ssn") if row.get("observed_swpc_ssn", -1) and row["observed_swpc_ssn"] >= 0 else ssn
            self._by_month[tag] = (float(ssn), float(f107))

    def lookup(self, year: int, month: int) -> tuple[float, float]:
        """返回 (ssn, f10.7)。缺失或哨兵值时回退到 100.0 / 130.0。"""
        ssn, f107 = self._by_month.get(f"{year:04d}-{month:02d}", (-1.0, -1.0))
        if ssn is None or ssn < 0:
            ssn = 100.0
        if f107 is None or f107 < 0:
            f107 = 130.0
        return ssn, f107


_default: SolarProvider | None = None


def get_solar_provider() -> SolarProvider:
    global _default
    if _default is None:
        _default = SolarProvider()
    return _default
