"""从 wspr.live 公开 ClickHouse HTTP 接口采集 WSPR 实测链路。

wspr.live 与 ham-stats 同源（WSPR 上游），公开免费、无需鉴权。
表 wspr.rx 已含 tx/rx 经纬度、band(MHz)、frequency(Hz)、power(dBm)、snr(dB)、distance(km)。

采样策略：按 (波段 × 年-月) 各取 limit 条最新 spot，覆盖多波段多季节，
避免单次拉取超大结果。
"""
from __future__ import annotations

import urllib.parse
import urllib.request

WSPR_LIVE = "https://db1.wspr.live/"

# 业余波段 -> WSPR band 整数（MHz）
BAND_MHZ = {
    "160m": 1,
    "80m": 3,
    "40m": 7,
    "30m": 10,
    "20m": 14,
    "17m": 18,
    "15m": 21,
    "12m": 24,
    "10m": 28,
}


def _query(sql: str, timeout: float = 60.0) -> list[dict]:
    url = WSPR_LIVE + "?query=" + urllib.parse.quote(sql + " FORMAT JSONEachRow")
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        text = resp.read().decode()
    return [__import__("json").loads(line) for line in text.splitlines() if line.strip()]


def fetch_spots(
    bands: list[str],
    year: int,
    month: int,
    limit_per_band: int = 3000,
    min_distance_km: int = 300,
    hash_mod: int = 7,
) -> list[dict]:
    """取指定年-月、各波段的 spot 样本，**按 UTC 小时分桶**采样。

    propagation 强烈依赖时刻，故对 0-23 时各取 ~limit/24 条，保证小时覆盖。
    采样用 cityHash64(id)%hash_mod 过滤（无需全表排序，快），
    避免 ORDER BY rand() 的全表排序超时。
    过滤掉过近的地波/本地链路与空坐标。
    """
    out: list[dict] = []
    ym_start = f"{year:04d}-{month:02d}-01"
    nm = (month % 12) + 1
    ny = year + (1 if month == 12 else 0)
    ym_end = f"{ny:04d}-{nm:02d}-01"
    per_hour = max(1, limit_per_band // 24)

    for band in bands:
        bmhz = BAND_MHZ.get(band)
        if bmhz is None:
            continue
        for hour in range(24):
            sql = (
                "SELECT toUnixTimestamp(time) AS ts, band, frequency, "
                "tx_lat, tx_lon, rx_lat, rx_lon, distance, power, snr "
                "FROM wspr.rx "
                f"WHERE band = {bmhz} "
                f"AND time >= '{ym_start} 00:00:00' AND time < '{ym_end} 00:00:00' "
                f"AND toHour(time) = {hour} "
                f"AND distance >= {min_distance_km} "
                "AND tx_lat != 0 AND rx_lat != 0 "
                f"AND cityHash64(id) % {hash_mod} = 0 "
                f"LIMIT {per_hour}"
            )
            try:
                rows = _query(sql, timeout=90.0)
            except Exception as e:  # noqa: BLE001
                print(f"    [warn] {band} h{hour} 查询失败: {e}")
                continue
            for r in rows:
                r["band_name"] = band
            out.extend(rows)
    return out
