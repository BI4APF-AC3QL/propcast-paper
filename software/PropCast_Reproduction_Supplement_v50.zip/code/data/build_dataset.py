"""构建训练集：WSPR 实测 spot → VOACAP 基线 → 残差标签 + 特征 → parquet。

目标变量（残差）：
    residual = measured_snr(WSPR) - voacap_snr(预测)
混合模型即学习该残差，对 VOACAP 做偏差校正。

用法（从仓库根目录，已 pip install -e ".[ml]"）：
    python -m data.build_dataset --bands 20m 40m --year 2024 --months 3 6 9 12 \
        --limit-per-band 1500 --out data/processed/dataset.parquet
"""
from __future__ import annotations

import argparse
import math
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from data.ingest_wspr import fetch_spots
from data.solar import get_solar_provider
from models.features import FEATURE_NAMES, build_features


def _dbm_to_watts(dbm: float) -> float:
    return 10.0 ** ((dbm - 30.0) / 10.0)


def _make_engine():
    from dvoacap.prediction_engine import PredictionEngine

    return PredictionEngine()


def voacap_point(eng, Params, GeoPoint, tx_lat, tx_lon, rx_lat, rx_lon,
                 freq_mhz, hour, month, ssn, power_w):
    """单点单频 VOACAP：返回 (snr_db, muf_mhz)。失败返回 (nan, nan)。

    持续采集的新观测（data/obs_store.py）必须复用这个函数，而不是走
    ``VoacapModel.predict``：后者按**波段代表频率**（20m 一律 14.1 MHz）和整点
    小时计算，而历史训练集用的是链路的**实际频率与小数小时**。两者混在同一个
    训练集里，等于给 voacap_snr 这一列注入了系统性偏差。
    """
    try:
        eng.params = Params(
            ssn=float(ssn), month=int(month),
            tx_location=GeoPoint.from_degrees(tx_lat, tx_lon),
            tx_power=max(0.001, float(power_w)),
        )
        eng.predict(GeoPoint.from_degrees(rx_lat, rx_lon), (hour % 24) / 24.0, [float(freq_mhz)])
        muf = float(eng.circuit_muf.muf) if eng.circuit_muf else float("nan")
        snr = float(eng.predictions[0].signal.snr_db)
        return snr, muf
    except Exception:
        return float("nan"), float("nan")


def build(bands: list[str], year: int, months: list[int],
          limit_per_band: int, out_path: Path) -> pd.DataFrame:
    from dvoacap.prediction_engine import VoacapParams
    from dvoacap.path_geometry import GeoPoint

    solar = get_solar_provider()
    eng = _make_engine()

    records: list[dict] = []
    for month in months:
        ssn, f107 = solar.lookup(year, month)
        spots = fetch_spots(bands, year, month, limit_per_band=limit_per_band)
        print(f"  {year}-{month:02d}: 取到 {len(spots)} 条 spot (ssn={ssn})")
        for s in spots:
            dt = datetime.fromtimestamp(int(s["ts"]), tz=timezone.utc)
            hour = dt.hour + dt.minute / 60.0
            freq_mhz = float(s["frequency"]) / 1e6
            power_w = _dbm_to_watts(float(s["power"]))
            v_snr, v_muf = voacap_point(
                eng, VoacapParams, GeoPoint,
                s["tx_lat"], s["tx_lon"], s["rx_lat"], s["rx_lon"],
                freq_mhz, hour, month, ssn, power_w,
            )
            if not (math.isfinite(v_snr) and math.isfinite(v_muf)):
                continue
            raw = {
                "distance_km": float(s["distance"]),
                "tx_lat": float(s["tx_lat"]), "tx_lon": float(s["tx_lon"]),
                "rx_lat": float(s["rx_lat"]), "rx_lon": float(s["rx_lon"]),
                "hour_utc": hour, "month": month, "freq_mhz": freq_mhz,
                "ssn": ssn, "tx_power_dbm": float(s["power"]),
                "voacap_snr": v_snr, "voacap_muf": v_muf,
            }
            feats = build_features(raw)  # type: ignore[arg-type]
            rec = dict(zip(FEATURE_NAMES, feats))
            rec.update({
                "measured_snr": float(s["snr"]),
                "voacap_snr": v_snr,
                "voacap_muf": v_muf,
                "residual": float(s["snr"]) - v_snr,
                "band": s["band_name"],
                "ts": int(s["ts"]),
            })
            records.append(rec)

    df = pd.DataFrame.from_records(records)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_path, index=False)
    print(f"已写出 {len(df)} 行 -> {out_path}")
    return df


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bands", nargs="+", default=["20m", "40m"])
    ap.add_argument("--year", type=int, default=2024)
    ap.add_argument("--months", nargs="+", type=int, default=[3, 6, 9, 12])
    ap.add_argument("--limit-per-band", type=int, default=1500)
    ap.add_argument("--out", type=Path, default=Path("data/processed/dataset.parquet"))
    args = ap.parse_args()
    build(args.bands, args.year, args.months, args.limit_per_band, args.out)


if __name__ == "__main__":
    main()
