"""增量重训：历史数据 + 持续采集的新观测 → 候选模型 → **只有更好才上线**。

为什么要有「只有更好才上线」的护栏
--------------------------------
模型改动并不总是改进；而"是不是改进"本身又高度依赖评估协议。护栏在**同一时间
切分**上对比候选与在役模型，只有 RMSE 改进超过阈值才替换产物。

一个来自本项目的教训：早期曾据单一时间切分判定一组扩展特征（log(freq/MUF)、
路径最高纬度、白昼比例等 6 项）"劣化 0.54%"并据此放弃；后用 12 折留一(年,月)
交叉验证重测，结论反号——-1.63%（即轻微改善），配对 t 检验 p=0.048、
Wilcoxon p=0.092，处于显著性边缘。这说明护栏拦得住"变差的模型"，却拦不住
"错误的评估协议"；后者只能在离线实验里靠交叉验证解决。

为什么评判只用「可信」数据
------------------------
上报接口开在公网，任何人都能提交观测。若测试集里混入用户上报，投毒者就能
**同时污染训练集和评分标准**，让劣化的模型看起来在变好。因此：
* 训练集：全部数据（用户上报参与训练，这是"人越多模型越准"的来源）
* 测试集：仅 trusted（后端自采的 WSPR/PSKReporter），用户数据不能给自己作证
再叠加对用户数据的稳健离群剔除（6×MAD），投毒的收益被压到很低；
即便如此还伤到了模型，promote 门槛会直接拦下上线。

用法：
    python -m models.retrain                    # 历史 + 新观测，试训并按需上线
    python -m models.retrain --dry-run          # 只评估不替换
    python -m models.retrain --min-gain 0.5     # 要求至少改进 0.5%
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd

from data.obs_store import OBS_PATH as OBSERVATIONS
from data.obs_store import TRUSTED_SOURCES
from models import calibration
from models.features import (FEATURE_NAMES, apply_baseline_floor,
                            build_features)
from models.hyperparams import (EARLY_STOPPING_ROUNDS, LGBM_PARAMS,
                                NO_EARLY_STOP_ROUNDS)

ARTIFACT = Path(__file__).parent / "artifacts" / "hybrid_correction.joblib"
HISTORICAL = Path(__file__).parent.parent / "data" / "processed" / "dataset_multiyear.parquet"
REPORT = Path(__file__).parent.parent / "data" / "processed" / "retrain_report.json"
HISTORY = Path(__file__).parent.parent / "data" / "processed" / "retrain_history.jsonl"

# 评判需要足够的可信样本，否则"改进"只是噪声
MIN_TRUSTED_TEST = 200
# 用户上报的稳健离群阈值（中位数绝对偏差的倍数）
CONTRIB_MAD_K = 6.0
MAX_SLICE_DEGRADATION_PCT = 2.0
MIN_SLICE_TEST = 500
MIN_CONTRIB_FOR_MAD = 50  # 少于这么多条时不做离群剔除（统计量不可靠）


def _slice_guard(df: pd.DataFrame, y: np.ndarray, candidate: np.ndarray,
                 incumbent: np.ndarray) -> dict:
    work = pd.DataFrame({"y": y, "candidate": candidate, "incumbent": incumbent,
                         "distance_km": df["distance_km"].to_numpy(),
                         "freq_mhz": df["freq_mhz"].to_numpy()})
    work["distance_slice"] = pd.cut(work["distance_km"], [-np.inf, 3000, 7000, 10000, 14000, np.inf])
    work["frequency_slice"] = pd.cut(work["freq_mhz"], [-np.inf, 5, 9, 16, 23, np.inf])
    rows = []
    for kind in ("distance_slice", "frequency_slice"):
        for name, g in work.groupby(kind, observed=True):
            if len(g) < MIN_SLICE_TEST:
                continue
            cr = float(np.sqrt(np.mean((g["y"] - g["candidate"]) ** 2)))
            ir = float(np.sqrt(np.mean((g["y"] - g["incumbent"]) ** 2)))
            rows.append({"kind": kind, "slice": str(name), "n": int(len(g)),
                         "candidate_rmse": cr, "incumbent_rmse": ir,
                         "degradation_pct": (cr - ir) / ir * 100.0 if ir else float("inf")})
    failed = [r for r in rows if r["degradation_pct"] > MAX_SLICE_DEGRADATION_PCT]
    return {"passed": not failed, "slices": rows, "failed": failed}


def _featurize(df: pd.DataFrame) -> pd.DataFrame:
    """确保 df 含全部 FEATURE_NAMES 列；缺失则由原始字段重算。

    历史数据集已含特征列；新观测只存原始字段，需在此构建——这样 FEATURE_NAMES
    演进后，历史观测无需重采即可用新特征重新训练。
    """
    if all(c in df.columns for c in FEATURE_NAMES):
        return df
    need = {"tx_lat", "tx_lon", "rx_lat", "rx_lon", "hour_utc", "month",
            "freq_mhz", "ssn", "tx_power_dbm", "voacap_snr", "voacap_muf", "distance_km"}
    missing = need - set(df.columns)
    if missing:
        raise SystemExit(f"数据缺少构建特征所需的原始字段: {sorted(missing)}")
    feats = [build_features(r._asdict()) for r in df.itertuples(index=False)]  # type: ignore[arg-type]
    for i, name in enumerate(FEATURE_NAMES):
        df[name] = [f[i] for f in feats]
    return df


def _load_all() -> pd.DataFrame:
    cols = FEATURE_NAMES + ["residual", "ts", "source", "trusted"]
    frames: list[pd.DataFrame] = []
    if HISTORICAL.exists():
        # 先截断再构建特征——顺序不能反，理由见 features.apply_baseline_floor
        h = _featurize(apply_baseline_floor(pd.read_parquet(HISTORICAL)))
        if "source" not in h.columns:
            h["source"] = "wspr-historical"
        h["trusted"] = True
        frames.append(h[cols])
    if OBSERVATIONS.exists():
        o = _featurize(apply_baseline_floor(pd.read_parquet(OBSERVATIONS)))
        if "trusted" not in o.columns:
            o["trusted"] = o["source"].isin(TRUSTED_SOURCES)
        frames.append(o[cols])
    if not frames:
        raise SystemExit("没有可用数据：历史数据集与观测文件都不存在")
    df = pd.concat(frames, ignore_index=True)
    # 只有实测 SNR 的行能参与残差回归；SSB/CW 的主观 RST 入库但不训练
    df = df[np.isfinite(df["residual"].to_numpy())]
    df["trusted"] = df["trusted"].fillna(False).astype(bool)
    return df.sort_values("ts").reset_index(drop=True)


def _reject_outliers(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """对**用户上报**做稳健离群剔除，限制投毒/误报的影响。

    自采数据不剔除：那里的极端残差是真实的传播现象（如 sporadic-E 突增），
    剔掉反而丢信息。
    """
    untrusted = ~df["trusted"].to_numpy()
    # 样本太少时 MAD 本身就是噪声，此时剔除等于随机丢数据
    if untrusted.sum() < MIN_CONTRIB_FOR_MAD:
        return df, 0
    r = df.loc[untrusted, "residual"].to_numpy()
    med = float(np.median(r))
    mad = float(np.median(np.abs(r - med))) * 1.4826
    if mad <= 0:
        return df, 0
    bad = untrusted.copy()
    bad[untrusted] = np.abs(r - med) > CONTRIB_MAD_K * mad
    return df[~bad].reset_index(drop=True), int(bad.sum())


def _metrics(y: np.ndarray, pred: np.ndarray) -> dict:
    err = y - pred
    return {
        "rmse": float(np.sqrt((err ** 2).mean())),
        "mae": float(np.abs(err).mean()),
        "bias": float(err.mean()),
        "n": int(len(y)),
    }


def _artifact_predict(artifact: dict, X: np.ndarray) -> np.ndarray:
    """用产物的完整输出契约预测；旧产物没有偏移字段时保持向后兼容。"""
    return (artifact["model"].predict(X)
            + float(artifact.get("output_offset") or 0.0))


HIST_SOURCE = "wspr-historical"
TRAIN_FRAC = 0.8          # 每个来源各自留最新的 1-TRAIN_FRAC 作测试
VAL_FRAC = 0.1            # 训练池中各来源各自留最新的这一比例作早停验证集


def split_by_source(df: pd.DataFrame, new_train_frac: float
                    ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """按**来源分别**做时间切分，返回 (训练集, 早停验证集, 测试集)。

    为什么不能对全表做一次 80/20
    ---------------------------
    历史 WSPR 是按时间排在最前面的一整块（93 500 条）。对全表切 80/20 时，切分点
    落在这一块**内部**，于是训练集 100% 是历史数据、可信测试集 93% 是新采集的
    FT8——候选模型从未见过新数据，却被拿新数据评判。实测 54 次重训中候选一律更差，
    且差距随数据量单调扩大（r=+0.425，+0.097 pp/千条），与该结构完全吻合：每多采
    一条，测试集就更不像训练集一分。新数据要等累计超过 hist/4 ≈ 23 000 条才会开始
    渗入训练集——也就是说闭环至今从未从众包数据里学到任何东西。

    改为每个来源各自按时间切：各来源都贡献最新的 20% 作测试、其余进训练池。

    为什么新数据只放一部分
    --------------------
    受控实验（固定新数据留出与历史留出，只改放入比例，3 个随机种子）：

        放入比例   新数据留出增益   历史留出代价
          0.25        +1.20 %         +0.26 %
          0.50        +4.22 %         +0.70 %     <- 唯一两端都为正
          0.75        +2.47 %         -0.94 %
          1.00        +4.77 %         -2.70 %

    两个来源在特征空间上完全可分（来源判别器 AUC=1.000）：新数据的 tx_power_dbm
    恒为 46.99 dBm（50 W 假设，历史为 19 个真实取值）、月份只有 8 月（历史只采
    3/6/9/12 月）、ssn 只有单一值。这不是特征卫生问题——去掉这些列反而让历史劣化
    从 -5.4% 扩大到 -8.1%，因为它们本来起的是"把两个分布分开处理"的作用。真实原因
    是领域漂移：现阶段新数据只覆盖两天、一个月份、一个太阳活动水平。全量放入会让
    模型过度迁就这个窄切片。

    因此这是个**过渡期参数**：待新观测覆盖多个月份与太阳活动水平后，该比例应上调，
    届时需按上表重新扫描（脚本见 paper/experiments/）。

    早停验证集为什么也要分层
    ----------------------
    验证集若沿用"训练池按时间取尾部 10%"，在本切分下会退化成**几乎 100% 新数据**
    ——新观测的时间戳全部晚于历史数据，排序后都在尾部。那样模型按新分布挑轮数，
    却在 81% 是历史数据的测试集上受评判，实测导致候选反而劣化 6.2%。因此验证集
    同样按来源各取尾部，使其来源构成与训练集一致。
    """
    frac = min(1.0, max(0.0, new_train_frac))
    fit_parts, va_parts, te_parts = [], [], []
    for src, g in df.groupby("source", sort=False):
        g = g.sort_values("ts")
        if g["trusted"].any():
            cut = int(len(g) * TRAIN_FRAC)
            pool, te = g.iloc[:cut], g.iloc[cut:]
        else:
            # 不可信来源永远进不了测试集（评判只用可信数据），全部留给训练池，
            # 否则按 80/20 切会白白丢掉 20% 本可用于训练的用户上报
            pool, te = g, g.iloc[:0]
        if src != HIST_SOURCE:
            pool = pool.iloc[:int(len(pool) * frac)]
        v_cut = int(len(pool) * (1.0 - VAL_FRAC))
        fit_parts.append(pool.iloc[:v_cut])
        va_parts.append(pool.iloc[v_cut:])
        te_parts.append(te)

    key = lambda parts: pd.concat(parts).sort_values("ts").reset_index(drop=True)
    return key(fit_parts), key(va_parts), key(te_parts)


def retrain(min_gain_pct: float = 0.0, dry_run: bool = False,
            contrib_weight: float = 1.0,
            new_train_frac: float = 0.5) -> dict:
    df, dropped = _reject_outliers(_load_all())
    tr_fit, va_all, te = split_by_source(df, new_train_frac)
    tr = pd.concat([tr_fit, va_all]).sort_values("ts").reset_index(drop=True)

    # 评判只用可信样本（见模块 docstring）
    te_t = te[te["trusted"]]
    Xte, yte = te_t[FEATURE_NAMES].to_numpy(), te_t["residual"].to_numpy()
    enough = len(te_t) >= MIN_TRUSTED_TEST

    # 早停的验证集必须**独立于测试集**：早停会挑选在监控集上表现最好的轮数，
    # 若监控的就是准入门槛所用的测试集，候选模型等于偷看了考卷，其成绩偏乐观，
    # 门槛也就从"保守"变成了"宽松"。split_by_source 已按来源各留尾部 10% 作验证，
    # 与测试集不相交。此处只取可信样本，否则用户上报能间接左右模型选轮。
    va = va_all[va_all["trusted"]] if enough else None
    if va is None or len(va) < MIN_TRUSTED_TEST:   # 可信验证样本不足则退回不早停
        tr_fit, va = tr, None

    Xtr, ytr = tr_fit[FEATURE_NAMES].to_numpy(), tr_fit["residual"].to_numpy()
    wtr = np.where(tr_fit["trusted"].to_numpy(), 1.0, contrib_weight)

    params = dict(LGBM_PARAMS)
    fit_kw: dict = {"sample_weight": wtr}
    if va is not None:
        fit_kw |= {"eval_set": [(va[FEATURE_NAMES].to_numpy(), va["residual"].to_numpy())],
                   "callbacks": [lgb.early_stopping(EARLY_STOPPING_ROUNDS, verbose=False)]}
    else:
        # 没有独立验证集就没法早停。此时**不能**跑满轮数上限——那等于关掉早停训练
        # 1500 轮，正是第 7 章批评的过拟合情形；改用保守固定轮数。
        params["n_estimators"] = NO_EARLY_STOP_ROUNDS
    model = lgb.LGBMRegressor(**params)
    model.fit(Xtr, ytr, **fit_kw)

    # 树模型在独立验证集上仍可能残留一个近似常数的系统偏差。只用验证集估计
    # 加性偏移，既不触碰准入测试集，也不增加模型容量；无验证集时保守取 0。
    output_offset = (float(np.mean(va["residual"].to_numpy()
                                   - model.predict(va[FEATURE_NAMES].to_numpy())))
                     if va is not None else 0.0)

    cand = _metrics(yte, model.predict(Xte) + output_offset) if enough else None
    voacap = _metrics(yte, np.zeros_like(yte)) if enough else None

    # 在役模型在同一测试集上的表现（特征不匹配则视为无在役模型）
    incumbent = None
    incumbent_pred = None
    if ARTIFACT.exists() and enough:
        try:
            art = joblib.load(ARTIFACT)
            if list(art.get("feature_names") or []) == FEATURE_NAMES:
                incumbent_pred = _artifact_predict(art, Xte)
                incumbent = _metrics(yte, incumbent_pred)
        except Exception:
            incumbent = None

    gain = None
    if cand and incumbent:
        gain = (incumbent["rmse"] - cand["rmse"]) / incumbent["rmse"] * 100

    # 分来源的指标。整体 RMSE 由历史数据主导（可信测试集约八成是历史），
    # 众包数据带来的改进集中在余下两成上，全局指标根本反映不出来——这与 5.4.4 节
    # 低容量模型的处境是同一个问题：**收益集中于子群体时，以全局指标为准的门槛
    # 会系统性地拒绝正确的改进**。不记录下来，就无从判断门槛拒绝的是什么。
    by_source: dict = {}
    if enough:
        try:
            inc_art = None
            if ARTIFACT.exists():
                _a = joblib.load(ARTIFACT)
                if list(_a.get("feature_names") or []) == FEATURE_NAMES:
                    inc_art = _a
            for src, g in te_t.groupby("source"):
                Xg, yg = g[FEATURE_NAMES].to_numpy(), g["residual"].to_numpy()
                rec = {"n": int(len(g)), "candidate": _metrics(
                    yg, model.predict(Xg) + output_offset)["rmse"]}
                if inc_art is not None:
                    rec["incumbent"] = _metrics(
                        yg, _artifact_predict(inc_art, Xg))["rmse"]
                    rec["gain_pct"] = (rec["incumbent"] - rec["candidate"]) / rec["incumbent"] * 100
                by_source[str(src)] = rec
        except Exception as e:  # noqa: BLE001 —— 诊断信息缺失不应让重训失败
            by_source = {"error": str(e)}
    # 可信测试样本不足时一律不上线：宁可用旧模型，也不用无法验证的新模型
    slice_guard = (_slice_guard(te_t, yte, model.predict(Xte), incumbent_pred)
                   if enough and incumbent_pred is not None else None)
    promote = enough and (incumbent is None or (
        gain is not None and gain > min_gain_pct and slice_guard and slice_guard["passed"]))

    report = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "n_train": len(tr_fit), "n_val": len(va) if va is not None else 0,
        "n_test_trusted": len(te_t), "n_total": len(df),
        "outliers_dropped": dropped,
        "output_offset": output_offset,
        "contrib_weight": contrib_weight,
        "new_train_frac": new_train_frac,
        # 训练/测试各自的来源构成——切分方式改动过一次，不记下来就无法解释
        # 不同批次之间 RMSE 为何跳变（见 split_by_source 的说明）
        "train_sources": {str(k): int(v) for k, v in tr["source"].value_counts().items()},
        "test_sources": {str(k): int(v) for k, v in te_t["source"].value_counts().items()},
        "sources": {str(k): int(v) for k, v in df["source"].value_counts().items()},
        "voacap": voacap, "incumbent": incumbent, "candidate": cand,
        "by_source": by_source,
        "slice_guard": slice_guard,
        "gain_pct": gain, "min_gain_pct": min_gain_pct,
        "promoted": bool(promote and not dry_run),
        "dry_run": dry_run,
        "reason": None if enough else f"可信测试样本不足（{len(te_t)} < {MIN_TRUSTED_TEST}），不评判、不上线",
    }

    if promote and not dry_run:
        if ARTIFACT.exists():  # 保留上一版，便于回滚
            shutil.copy2(ARTIFACT, ARTIFACT.with_suffix(".joblib.bak"))
        resid = tr["residual"].to_numpy()
        tmp = ARTIFACT.with_suffix(".joblib.tmp")
        joblib.dump({
            "model": model,
            "feature_names": FEATURE_NAMES,
            "target": "residual",
            "trained_at": report["trained_at"],
            "n_train": len(tr_fit), "n_test": len(te_t),
            "rmse": cand["rmse"] if cand else None,
            "output_offset": output_offset,
            "sources": report["sources"],
            # reliability 的 logistic 中心/尺度由训练集校正后 SNR 分布标定
            "snr_center": float(np.median(tr["voacap_snr"].to_numpy() + resid)),
            "snr_scale": float(max(2.0, np.std(tr["voacap_snr"].to_numpy() + resid) / 2)),
        }, tmp)
        os.replace(tmp, ARTIFACT)  # 原子替换：在线进程不会读到写了一半的产物

    # 标定文件描述**数据**（训练集的距离分布）与**在役模型**的实测误差，
    # 与候选是否上线无关，因此每轮都更新 —— 否则会出现「模型没变好 → 平滑与
    # 可靠度标定也跟着停更」。候选上线时用候选的成绩，否则用在役的。
    if not dry_run:
        eff = (cand if report["promoted"] else incumbent) or {}
        # 低容量粗模型：稀疏距离段的回退目标。它容量被压死，不参与「只有更好才上线」
        # 的门槛 —— 那道门槛看的是整体 RMSE，而粗模型的价值集中在占样本 3% 的
        # 超长路径段（10-14k km，CV 实测 +4.93%），整体指标根本反映不出来。
        coarse_rmse = None
        try:
            # 早停监控**验证集**而非测试集。此前这里传的是 te_t/yte，与 7.1.3 节
            # 批评的做法完全一致——粗模型挑的是在考卷上最优的轮数，随后又用同一份
            # 考卷报出它的 RMSE，而该 RMSE 正是"粗模型是否可用"硬规则的判据。
            cm = calibration.train_coarse(
                tr_fit[calibration.COARSE_FEATURE_NAMES].to_numpy(),
                tr_fit["residual"].to_numpy(),
                eval_set=((va[calibration.COARSE_FEATURE_NAMES].to_numpy(),
                           va["residual"].to_numpy()) if va is not None else None))
            if enough:
                coarse_rmse = _metrics(yte, cm.predict(
                    te_t[calibration.COARSE_FEATURE_NAMES].to_numpy()))["rmse"]
        except Exception as e:  # noqa: BLE001 —— 粗模型失败只是失去回退，不该拖垮重训
            logging.getLogger(__name__).warning("粗模型训练失败：%s", e)
        report["coarse_rmse"] = coarse_rmse
        calibration.save(eff.get("rmse"), df["distance_km"].to_numpy(), coarse_rmse)

    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if dry_run:
        # 试跑不计入历史：论文表 6-1 的「自动重训次数」与图 6-2 都数这个文件，
        # 把人工试跑混进去会虚增闭环的运行记录。
        return report
    # 历史轨迹：供前端画出「随时间/数据量增长，误差如何变化」
    with open(HISTORY, "a", encoding="utf-8") as f:
        f.write(json.dumps({
            "at": report["trained_at"], "n_total": report["n_total"],
            "rmse": cand["rmse"] if cand else None,
            "incumbent_rmse": incumbent["rmse"] if incumbent else None,
            "voacap_rmse": voacap["rmse"] if voacap else None,
            "promoted": report["promoted"],
        }, ensure_ascii=False) + "\n")
    return report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-gain", type=float, default=0.0, help="上线所需的最小 RMSE 改进百分比")
    ap.add_argument("--dry-run", action="store_true", help="只评估不替换 artifact")
    ap.add_argument("--contrib-weight", type=float, default=1.0,
                    help="用户上报样本的训练权重（1.0 = 与自采数据同权）")
    ap.add_argument("--new-train-frac", type=float, default=0.5,
                    help="放入训练集的新观测比例（按时间取最早的部分；1.0 = 全放）")
    a = ap.parse_args()
    r = retrain(a.min_gain, a.dry_run, a.contrib_weight, a.new_train_frac)
    print(json.dumps(r, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
