"""共享特征构建器 —— 训练（data/build_dataset）与推理（HybridModel）共用。

把一条链路的原始字段转成**有序、命名一致**的特征向量，
保证训练时与预测时的特征完全对齐（避免线上线下特征漂移）。

只使用**预测时可得**的特征（不含年份/具体日期/实测量），
因此模型可在网站实时推理时复用。
"""
from __future__ import annotations

import math
from typing import TypedDict

from models.geo import midpoint, solar_zenith_deg

# 特征顺序固定；训练产物会另存一份以校验。
FEATURE_NAMES: list[str] = [
    "distance_km",
    "mid_lat",
    "mid_lon",
    "abs_mid_lat",
    "tx_lat",
    "rx_lat",
    "sin_hour",
    "cos_hour",
    "sin_month",
    "cos_month",
    "freq_mhz",
    "ssn",
    "tx_power_dbm",
    "voacap_snr",
    "voacap_muf",
    "freq_over_muf",
    "zenith_mid",
    "zenith_tx",
    "zenith_rx",
]


# 低容量「粗模型」的特征子集。必须是 FEATURE_NAMES 的子集：这样一次 build_features
# 即可同时喂细/粗两个模型，无需重复构建。
#
# 选取标准是「少量样本就能可靠估计」：路径长度、频率、物理基线本身、离 MUF 的远近、
# 中点日照。刻意不含 tx/rx 经纬度与各端天顶角——那些维度需要大量样本才撑得起来，
# 正是稀疏区会跑偏的地方。
COARSE_FEATURE_NAMES: list[str] = [
    "distance_km",
    "freq_mhz",
    "voacap_snr",
    "freq_over_muf",
    "zenith_mid",
]
COARSE_INDEX: list[int] = [FEATURE_NAMES.index(n) for n in COARSE_FEATURE_NAMES]


class RawLink(TypedDict):
    distance_km: float
    tx_lat: float
    tx_lon: float
    rx_lat: float
    rx_lon: float
    hour_utc: float
    month: int
    freq_mhz: float
    ssn: float
    tx_power_dbm: float
    voacap_snr: float
    voacap_muf: float


# VOACAP 用极端负值表示"该路径此频率完全闭合"。实测其输出低至 -2838 dB，
# 而真实可解调的信噪比不低于约 -30 dB（WSPR，2500 Hz 参考带宽）。这类取值是
# **哨兵值而非标定过的信噪比**：-60 与 -1772 表达的是同一件事（闭合），二者之间
# 的差异没有物理含义。
#
# 若原样使用，后果有两处且都很严重：
#   1. 训练时 residual = 实测 - voacap_snr 会得到 +1758 dB 这样的目标值，
#      而这些行恰好集中在超长路径（14000-20100 km 段占 6.7%），使该段的残差
#      RMSE 从 32 虚增到 185，把"物理模型给了个哨兵值"误记为"这段路径极难预测"；
#   2. 推理时同样会发生——基线 -1772 加一个小校正仍是 -1772，用户得到的是一个
#      彻底错误的答案。**只在训练侧剔除这些行并不能解决第 2 点**，反而使模型
#      没见过这种情形、失效行上的误差从 84.5 dB 恶化到 214.8 dB（实测）。
#
# 因此统一截断，且**训练目标、特征、推理三处必须用同一个下限**，否则模型的
# 输入与它要拟合的目标就对不上。
#
# 取值 -120 dB 的依据有二。物理上：数据集中实测信噪比最低为 -99 dB，预测值低于
# -120 已在任何观测值之外，再区分"多闭合"没有意义。实测上（截断点扫描，两个
# 随机种子，干净子集 RMSE / 失效行 SNR 误差）：
#     -30: 11.653 / 8.1      -60:  8.718 / 8.3
#     -80:  8.261 / 8.3     -120:  8.203 / 8.1
#     不处理: 8.382 / 84.5   剔除: 8.207 / 214.8
# 失效行上的收益与截断点几乎无关，而干净子集随截断变深单调改善——因为截得太浅会
# 把大量**有意义的**弱信号基线一并压平。-120 只影响 1.7% 的行，是两项指标同时
# 最优的点。
VOACAP_SNR_FLOOR = -120.0


def clip_baseline(snr: float) -> float:
    """把 VOACAP 的闭合哨兵值压到物理有意义的下限。"""
    return snr if snr > VOACAP_SNR_FLOOR else VOACAP_SNR_FLOOR


def apply_baseline_floor(df):
    """对整张表施加下限，并据此**重算回归目标**；返回新表。

    放在这里而不是某个训练脚本里，是因为读取存档数据的入口不止一个
    （models/train.py、models/evaluate.py、models/retrain.py、paper/experiments/*），
    每处各写一份必然漏掉几处——第一版就漏了冷启动那条路径，表现为改完之后
    数字一个没变。任何直接读 parquet 的地方都应当先过这个函数。

    存档里的 residual 与特征列 voacap_snr 都是按**未截断**的基线算出来的，
    因此必须同时更新两者，否则模型的输入与它要拟合的目标对不上。
    """
    need = {"voacap_snr", "measured_snr"}
    if not need <= set(df.columns):
        raise KeyError(f"数据缺少截断所需的列：{sorted(need - set(df.columns))}")
    if not (df["voacap_snr"] < VOACAP_SNR_FLOOR).any():
        return df
    df = df.copy()
    lo = df["voacap_snr"].clip(lower=VOACAP_SNR_FLOOR)
    df["voacap_snr"] = lo
    if "residual" in df.columns:
        df["residual"] = df["measured_snr"].to_numpy() - lo.to_numpy()
    return df


def build_features(r: RawLink) -> list[float]:
    """原始字段 -> 与 FEATURE_NAMES 对齐的特征值列表。"""
    mlat, mlon = midpoint(r["tx_lat"], r["tx_lon"], r["rx_lat"], r["rx_lon"])
    hour = float(r["hour_utc"])
    month = int(r["month"])
    muf = float(r["voacap_muf"]) or 1e-6
    return [
        float(r["distance_km"]),
        mlat,
        mlon,
        abs(mlat),
        float(r["tx_lat"]),
        float(r["rx_lat"]),
        math.sin(2 * math.pi * hour / 24.0),
        math.cos(2 * math.pi * hour / 24.0),
        math.sin(2 * math.pi * month / 12.0),
        math.cos(2 * math.pi * month / 12.0),
        float(r["freq_mhz"]),
        float(r["ssn"]),
        float(r["tx_power_dbm"]),
        clip_baseline(float(r["voacap_snr"])),
        float(r["voacap_muf"]),
        float(r["freq_mhz"]) / muf,
        solar_zenith_deg(mlat, mlon, month, hour),
        solar_zenith_deg(r["tx_lat"], r["tx_lon"], month, hour),
        solar_zenith_deg(r["rx_lat"], r["rx_lon"], month, hour),
    ]
