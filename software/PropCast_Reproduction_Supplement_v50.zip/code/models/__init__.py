"""可插拔短波传播预测模型包。

所有模型（VOACAP / 自有混合模型）都实现 ``PropagationModel`` 接口，
网站通过统一的 ``registry`` 调用，从而可一键切换或并列对比。
"""
from models.base import (
    Band,
    PropagationModel,
    PredictRequest,
    PredictResult,
    BandHourCell,
    GeoLocation,
    AntennaSpec,
    BANDS,
    band_to_freq_mhz,
)
from models.registry import get_model, list_models, register_model

__all__ = [
    "Band",
    "PropagationModel",
    "PredictRequest",
    "PredictResult",
    "BandHourCell",
    "GeoLocation",
    "AntennaSpec",
    "BANDS",
    "band_to_freq_mhz",
    "get_model",
    "list_models",
    "register_model",
]
