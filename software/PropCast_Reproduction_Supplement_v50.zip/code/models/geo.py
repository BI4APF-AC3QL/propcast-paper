"""大圆距离与方位角计算（与具体传播模型无关的纯几何工具）。"""
from __future__ import annotations

import math

EARTH_RADIUS_KM = 6371.0


def great_circle_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """两点间大圆距离 (km)，haversine。"""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * EARTH_RADIUS_KM * math.asin(min(1.0, math.sqrt(a)))


def initial_bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """从 (lat1,lon1) 指向 (lat2,lon2) 的初始方位角，0-360°。"""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0


def midpoint(lat1: float, lon1: float, lat2: float, lon2: float) -> tuple[float, float]:
    """大圆路径中点 (lat, lon)，度。"""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    bx = math.cos(p2) * math.cos(dl)
    by = math.cos(p2) * math.sin(dl)
    lat = math.atan2(
        math.sin(p1) + math.sin(p2),
        math.sqrt((math.cos(p1) + bx) ** 2 + by ** 2),
    )
    lon = math.radians(lon1) + math.atan2(by, math.cos(p1) + bx)
    return math.degrees(lat), (math.degrees(lon) + 540.0) % 360.0 - 180.0


def solar_zenith_deg(lat: float, lon: float, month: int, hour_utc: float) -> float:
    """给定月份与 UTC 小时，估算某点太阳天顶角（度）。

    用 month -> 年中日序 的近似（与年份无关），保证训练/推理一致。
    天顶角 < 90° 即白昼。
    """
    doy = (month - 0.5) * 30.4  # 年中日序近似
    decl = math.radians(-23.44 * math.cos(math.radians(360.0 / 365.0 * (doy + 10))))
    lst = hour_utc + lon / 15.0  # 当地太阳时（小时）
    hour_angle = math.radians(15.0 * (lst - 12.0))
    p = math.radians(lat)
    cos_z = math.sin(p) * math.sin(decl) + math.cos(p) * math.cos(decl) * math.cos(hour_angle)
    cos_z = max(-1.0, min(1.0, cos_z))
    return math.degrees(math.acos(cos_z))
