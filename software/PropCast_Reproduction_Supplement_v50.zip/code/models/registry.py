"""模型注册表。

后端通过 ``get_model(name)`` 拿到模型实例，前端通过 ``list_models()``
列出可选模型。新增模型（如混合模型）只需 ``register_model`` 即可被网站发现，
无需改动 API 层 —— 这是“模型可插拔”设计的落点。
"""
from __future__ import annotations

from typing import Callable

from models.base import PropagationModel

# name -> 工厂函数（惰性构造，避免导入期就加载重资源）
_FACTORIES: dict[str, Callable[[], PropagationModel]] = {}
_INSTANCES: dict[str, PropagationModel] = {}


def register_model(name: str, factory: Callable[[], PropagationModel]) -> None:
    """注册一个模型工厂。name 为前端可见的稳定标识。"""
    _FACTORIES[name] = factory


def list_models() -> list[str]:
    """返回所有已注册模型名。"""
    return sorted(_FACTORIES.keys())


def get_model(name: str) -> PropagationModel:
    """按名取模型实例（单例，惰性构造）。未知名抛 KeyError。"""
    if name not in _FACTORIES:
        raise KeyError(f"未知模型: {name!r}. 可用: {list_models()}")
    if name not in _INSTANCES:
        _INSTANCES[name] = _FACTORIES[name]()
    return _INSTANCES[name]


# --------------------------------------------------------------------------- #
# 内置模型注册
# --------------------------------------------------------------------------- #
def _make_voacap() -> PropagationModel:
    from models.voacap_model import VoacapModel

    return VoacapModel()


def _make_hybrid() -> PropagationModel:
    from models.hybrid_model import HybridModel

    return HybridModel()


register_model("voacap", _make_voacap)
register_model("hybrid", _make_hybrid)
