"""训练混合模型的 ML 校正层：用 LightGBM 回归 VOACAP 残差。

用法：
    python -m models.train --data data/processed/dataset.parquet
产物：models/artifacts/hybrid_correction.joblib
      （含 model / feature_names / metadata，供 HybridModel 加载）
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path

import joblib
import lightgbm as lgb
import pandas as pd

from models.features import FEATURE_NAMES, apply_baseline_floor
from models.hyperparams import EARLY_STOPPING_ROUNDS, LGBM_PARAMS

ARTIFACT = Path(__file__).parent / "artifacts" / "hybrid_correction.joblib"


def split_by_time(df: pd.DataFrame, train_frac: float = 0.8) -> tuple[pd.DataFrame, pd.DataFrame]:
    """按时间排序后切分，避免时间泄漏（用过去预测未来）。"""
    df = df.sort_values("ts").reset_index(drop=True)
    cut = int(len(df) * train_frac)
    return df.iloc[:cut], df.iloc[cut:]


def train(data_path: Path, artifact: Path = ARTIFACT) -> dict:
    # 先施加 VOACAP 基线下限：存档里的 residual 与 voacap_snr 都是按未截断的
    # 值算出来的，直接拿来训练等于把哨兵值当回归目标。见 features 里的说明。
    df = apply_baseline_floor(pd.read_parquet(data_path))
    train_df, test_df = split_by_time(df)

    # 早停的验证集必须独立于测试集：监控测试集等于让模型挑选在考卷上最好的轮数，
    # 报出的成绩偏乐观（详见论文 7.1.3 节）。从训练集尾部另切 10 % 专供早停。
    va_cut = int(len(train_df) * 0.9)
    fit_df, val_df = train_df.iloc[:va_cut], train_df.iloc[va_cut:]

    model = lgb.LGBMRegressor(**LGBM_PARAMS)
    # 用 numpy 数组训练（不带列名），与推理时按位置传特征列表保持一致，避免特征名告警。
    model.fit(
        fit_df[FEATURE_NAMES].to_numpy(),
        fit_df["residual"].to_numpy(),
        eval_set=[(val_df[FEATURE_NAMES].to_numpy(), val_df["residual"].to_numpy())],
        callbacks=[lgb.early_stopping(EARLY_STOPPING_ROUNDS, verbose=False)],
    )

    # 校正后 SNR 处于真实 WSPR 量纲；记录其分布用于 reliability/score 的数据驱动标定。
    measured = train_df["measured_snr"].astype(float)
    snr_center = float(measured.median())
    snr_scale = float((measured.quantile(0.75) - measured.quantile(0.25)) / 2.0) or 6.0

    import numpy as np

    from models import calibration

    output_offset = float((val_df["residual"].to_numpy()
                           - model.predict(val_df[FEATURE_NAMES].to_numpy())).mean())
    pred = model.predict(test_df[FEATURE_NAMES].to_numpy()) + output_offset
    rmse = float(np.sqrt(((test_df["residual"].to_numpy() - pred) ** 2).mean()))

    bundle = {
        "model": model,
        "feature_names": FEATURE_NAMES,
        "target": "residual",
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "n_train": len(fit_df),
        "n_test": len(test_df),
        # 冷启动产物此前不写 rmse，而 /api/modelstats 正是读这个字段展示
        # 「在役模型 RMSE」——于是界面上显示为空，看起来像模型没训好。
        # 值本来就已算出，只是没存进去。
        "rmse": rmse,
        "output_offset": output_offset,
        "snr_center": snr_center,  # 真实 SNR 中位数（reliability logistic 中心）
        "snr_scale": snr_scale,    # 半 IQR（logistic 尺度）
    }
    artifact.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, artifact)

    # 同步标定文件：自适应平滑的带宽与 reliability 的尺度都依赖它，
    # 缺了会退回"完全不平滑 + 旧尺度"。见 models/calibration.py。
    # 粗模型的早停同样必须监控验证集：此前这里传的是 test_df，与上面刚修掉的
    # 主模型缺陷是同一个——挑在考卷上最优的轮数，再用同一份考卷报成绩。
    cm = calibration.train_coarse(
        fit_df[calibration.COARSE_FEATURE_NAMES].to_numpy(), fit_df["residual"].to_numpy(),
        eval_set=(val_df[calibration.COARSE_FEATURE_NAMES].to_numpy(),
                  val_df["residual"].to_numpy()))
    c_rmse = float(np.sqrt(((test_df["residual"].to_numpy()
                             - cm.predict(test_df[calibration.COARSE_FEATURE_NAMES].to_numpy())) ** 2).mean()))
    calibration.save(rmse, train_df["distance_km"].to_numpy(), c_rmse)

    print(f"已训练 (train={len(train_df)}, test={len(test_df)}, RMSE={rmse:.3f}) -> {artifact}")
    return bundle


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, default=Path("data/processed/dataset.parquet"))
    ap.add_argument("--out", type=Path, default=ARTIFACT)
    args = ap.parse_args()
    train(args.data, args.out)


if __name__ == "__main__":
    main()
