"""标定文件：描述**训练数据的形状**，与模型产物解耦。

为什么不塞进 joblib 产物里
------------------------
产物的替换受「只有更好才上线」的门槛控制。但下面这些量描述的是数据而非候选模型，
即使候选没上线也应该更新：
* ``incumbent_rmse``：在役模型在最新可信测试集上的误差 —— 用来定 reliability 的尺度
* ``distance_hist``：训练集的路径长度分布 —— 用来判断某次查询有多少数据支撑

把它们跟产物绑在一起，会出现「模型没变好 → 标定也跟着停更」的怪现象。

自适应平滑的依据
--------------
实测（数字由 paper/make_ch5_tables.py 生成，见论文表 5-1）：混合模型输出的 (波段×小时)
网格，抖动程度与该路径长度在训练集里的支撑量强相关 —— 北京→东京（支撑 27.1%）抖动
5.38，与 VOACAP 的 5.75 持平；北京→圣保罗（支撑 0.1%）抖动 14.25，而 VOACAP 在该路径
上无可读单元。因此平滑带宽按支撑量自适应：数据密处不动，数据稀处向邻域借力。
"""
from __future__ import annotations

import json
from pathlib import Path

from models.features import COARSE_FEATURE_NAMES, COARSE_INDEX  # noqa: F401  (供 hybrid_model 取列)

CALIB_PATH = Path(__file__).parent / "artifacts" / "calibration.json"
COARSE_PATH = Path(__file__).parent / "artifacts" / "coarse_correction.joblib"

# 距离直方图的分箱（km）。500km 一档足以刻画"这个距离有没有数据"。
DIST_BIN_KM = 500.0
N_DIST_BINS = 41  # 0..20500 km

# 自适应带宽：σ = σ_max · K / (K + n)，n 为该距离档的训练样本数。
# K 取 2000 —— 训练集里"够密"的量级（0-2000km 档有 53k 条，8000km 以上不足 3k）。
SUPPORT_K = 2000.0
SIGMA_HOUR_MAX = 8.0     # 小时方向最大核宽（小时）
SIGMA_FREQ_MAX = 0.9     # 频率方向最大核宽（相对频率）
SMOOTH_MIN_SIGMA_H = 0.25  # 低于此值视为不平滑，直接走单点预测（省 45 倍算力）

# 由 SNR 预测误差换算 logistic 尺度：误差~N(0,σ) 时，
# 标准正态 CDF 与 logistic 的最佳拟合系数约为 1.7。
NORMAL_TO_LOGISTIC = 1.7

# --- 稀疏区回退：细模型 × 低容量粗模型的混合权重 --- #
# w = max(W_MIN, n/(n+K))，n 为该距离档的训练支撑。
# K/W_MIN 由留一(年,月)交叉验证选出（12 折，按距离分段）：
#   K=300 时 10-14k 段改进 +4.93%（11/12 折都赢），密集段代价 −0.01%…−0.34%，整体 +0.43%
#   K=600 在 10-14k 更好（+5.79%）但密集段代价翻倍（−0.88%）且只赢 10/12，故取 300
BLEND_K = 300.0
BLEND_W_MIN = 0.5   # 粗模型单独用时比细模型差得多，不允许权重超过一半
# 粗模型误差超过在役模型这么多倍就不参与混合（防止它自己训坏了还被当作稳健回退）
COARSE_MAX_RMSE_RATIO = 3.0


def load() -> dict | None:
    try:
        return json.loads(CALIB_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def save(incumbent_rmse: float | None, distances, coarse_rmse: float | None = None) -> None:
    """写入标定文件（原子替换）。distances 为训练集各链路的大圆距离。"""
    import os

    import numpy as np

    hist, _ = np.histogram(np.asarray(distances, dtype=float),
                           bins=N_DIST_BINS, range=(0.0, N_DIST_BINS * DIST_BIN_KM))
    CALIB_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = CALIB_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps({
        "incumbent_rmse": incumbent_rmse,
        "coarse_rmse": coarse_rmse,
        "dist_bin_km": DIST_BIN_KM,
        "distance_hist": [int(v) for v in hist],
        "n_train": int(len(distances)),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, CALIB_PATH)


def train_coarse(X, y, eval_set=None):
    """训练低容量粗模型并原子写入 COARSE_PATH，返回模型。

    容量是刻意压死的（深度 2 / 4 叶子 / min_child_samples=200）：它学不到细结构，
    因此在样本稀薄的距离段也不会乱来 —— 这正是要它来兜底的原因。
    """
    import os

    import joblib
    import lightgbm as lgb

    m = lgb.LGBMRegressor(n_estimators=400, learning_rate=0.05, num_leaves=4, max_depth=2,
                          min_child_samples=200, subsample=0.8, colsample_bytree=0.8,
                          random_state=42, verbose=-1)
    from models.hyperparams import EARLY_STOPPING_ROUNDS

    kw = {}
    if eval_set is not None:
        kw = {"eval_set": [eval_set],
              "callbacks": [lgb.early_stopping(EARLY_STOPPING_ROUNDS, verbose=False)]}
    m.fit(X, y, **kw)
    COARSE_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = COARSE_PATH.with_suffix(".joblib.tmp")
    joblib.dump({"model": m, "features": COARSE_FEATURE_NAMES}, tmp)
    os.replace(tmp, COARSE_PATH)
    return m


def load_coarse(calib: dict | None):
    """加载粗模型；特征不符或误差异常时返回 None（退回纯细模型）。"""
    if not COARSE_PATH.exists():
        return None
    try:
        import joblib

        art = joblib.load(COARSE_PATH)
    except Exception:
        return None
    if list(art.get("features") or []) != COARSE_FEATURE_NAMES:
        return None
    fine_rmse = (calib or {}).get("incumbent_rmse")
    coarse_rmse = (calib or {}).get("coarse_rmse")
    if fine_rmse and coarse_rmse and coarse_rmse > COARSE_MAX_RMSE_RATIO * fine_rmse:
        return None  # 粗模型自己训坏了，不配当稳健回退
    return art["model"]


def blend_weight(n_support: int | None) -> float:
    """细模型的权重。支撑越少越向粗模型让步，但绝不低于 W_MIN。

    注意这里让的是**低容量模型**，不是纯 VOACAP。实测纯 VOACAP 在每个距离段都比
    ML 差 4-5 倍（如 6000-10000km：75.4 vs 13.6），把权重让给它只会更糟；
    真正需要削弱的是高容量模型在稀疏区的自由度。
    """
    if n_support is None:
        return 1.0
    return max(BLEND_W_MIN, n_support / (n_support + BLEND_K))


def support_at(calib: dict | None, distance_km: float) -> int | None:
    """某路径长度在训练集里的支撑样本数（取相邻 3 档之和，避免分箱边界抖动）。

    直方图缺失时返回 None 而不是 0：0 会被 bandwidth() 当成"极度稀疏"从而全程重度
    平滑，把"不知道"错当成"没数据"。调用方应把 None 视为不平滑。
    """
    hist = (calib or {}).get("distance_hist") or []
    if not hist:
        return None
    w = float(calib.get("dist_bin_km") or DIST_BIN_KM)  # type: ignore[union-attr]
    i = int(max(0.0, distance_km) // w)
    return sum(hist[j] for j in range(max(0, i - 1), min(len(hist), i + 2)))


def bandwidth(n_support: int | None) -> tuple[float, float]:
    """支撑量 → (小时核宽, 相对频率核宽)。支撑越多核越窄，密集区几乎不平滑。

    n_support 为 None（无标定信息）时不平滑：宁可保持原行为，也不要在不知道
    数据分布的情况下擅自抹平输出。
    """
    if n_support is None:
        return 0.0, 0.0
    f = SUPPORT_K / (SUPPORT_K + max(0, n_support))
    return SIGMA_HOUR_MAX * f, SIGMA_FREQ_MAX * f


def reliability_sigma(calib: dict | None, fallback: float) -> float:
    """reliability 的 logistic 尺度 = 模型自身的 SNR 预测误差 / 1.7。

    原先取「训练集校正后 SNR 分布宽度的一半」，那是数据的离散程度，
    不是**单条预测的不确定度**，没有理论依据，且过窄（4.3dB）会把 ±6dB 的
    正常预测波动放大成评分上 50 分的跳变。
    改用测得的 RMSE 后还有一个好处：持续学习让 RMSE 下降时，曲线会自动变锐利。
    """
    r = (calib or {}).get("incumbent_rmse")
    if r and r > 0:
        return max(2.0, float(r) / NORMAL_TO_LOGISTIC)
    return max(2.0, fallback)
