"""模型抽象接口与共享数据结构。

设计目标：让 VOACAP 与自有混合模型实现**同一个**接口，
使前端可以零改动地切换模型或并列对比。

数据结构用 Pydantic v2 定义，既作为模型 I/O，也直接作为 FastAPI 的请求/响应模型复用。
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from pydantic import BaseModel, Field, field_validator


# --------------------------------------------------------------------------- #
# 波段定义
# --------------------------------------------------------------------------- #
# 业余无线电 HF 主力波段 -> 代表频率 (MHz)。
# 频率取各波段常用 SSB/数据中心频点附近的代表值，用于传播计算。
BANDS: dict[str, float] = {
    "160m": 1.9,
    "80m": 3.6,
    "60m": 5.35,
    "40m": 7.1,
    "30m": 10.12,
    "20m": 14.1,
    "17m": 18.1,
    "15m": 21.1,
    "12m": 24.9,
    "10m": 28.4,
    "6m": 50.1,
}

# 类型别名（仅文档用途）
Band = str


def band_to_freq_mhz(band: Band) -> float:
    """波段名 -> 代表频率 (MHz)。未知波段抛 KeyError。"""
    return BANDS[band]


# --------------------------------------------------------------------------- #
# 输入
# --------------------------------------------------------------------------- #
class GeoLocation(BaseModel):
    """地理坐标。lat: 纬度(北正)，lon: 经度(东正)。"""

    lat: float = Field(..., ge=-90, le=90, description="纬度，北纬为正")
    lon: float = Field(..., ge=-180, le=180, description="经度，东经为正")
    name: str | None = Field(default=None, description="可选地名/呼号/网格")


class AntennaSpec(BaseModel):
    """天线规格（Phase 1 仅用增益占位，后续可扩展方向图）。"""

    type: str = Field(default="isotropic", description="isotropic | dipole")
    gain_dbi: float = Field(default=0.0, description="峰值增益 dBi")
    height_m: float = Field(default=10.0, description="架设高度（米）")


class PredictRequest(BaseModel):
    """点到点、多波段、跨时段的传播预测请求。

    时间维度用 UTC 整点小时列表表示（默认 0..23 全天）。
    课题中“未来一段时间内”的预测：太阳活动参数 (ssn) 由调用方按预报日期给定。
    """

    tx: GeoLocation = Field(..., description="发射点")
    rx: GeoLocation = Field(..., description="接收点")
    # bands/hours 有上限：predict 对每个 (band × hour) 同步跑一次 VOACAP 引擎，
    # 无上限时单请求 hours=[0]*5000 即可放大成数十万次计算占死线程池（CPU DoS）。
    bands: list[Band] = Field(
        default_factory=lambda: ["80m", "40m", "30m", "20m", "17m", "15m", "12m", "10m"],
        description="要预测的波段列表",
        max_length=len(BANDS),
    )
    hours_utc: list[int] = Field(
        default_factory=lambda: list(range(24)),
        description="要预测的 UTC 整点小时 (0-23)",
        max_length=24,
    )

    @field_validator("bands")
    @classmethod
    def _valid_bands(cls, v: list[str]) -> list[str]:
        # 去重并剔除未知波段（保序），避免重复放大与无效频率
        seen: set[str] = set()
        out = [b for b in v if b in BANDS and not (b in seen or seen.add(b))]
        if not out:
            raise ValueError("bands 需至少包含一个有效波段")
        return out

    @field_validator("hours_utc")
    @classmethod
    def _valid_hours(cls, v: list[int]) -> list[int]:
        # 去重、只保留 0-23（保序）
        seen: set[int] = set()
        out = [h for h in v if 0 <= h <= 23 and not (h in seen or seen.add(h))]
        if not out:
            raise ValueError("hours_utc 需至少包含一个 0-23 的小时")
        return out
    month: int = Field(default=6, ge=1, le=12, description="月份（电离层季节性）")
    ssn: float = Field(default=100.0, ge=0, description="太阳黑子数 (Smoothed Sunspot Number)")
    tx_power_w: float = Field(default=100.0, gt=0, description="发射功率 (瓦)")
    tx_antenna: AntennaSpec = Field(default_factory=AntennaSpec)
    rx_antenna: AntennaSpec = Field(default_factory=AntennaSpec)
    # 默认 24.0 是「弱信号/数字模式」口径（与 WSPR/FT8 训练数据一致），
    # 刻意低于 VOACAP 原生 SSB 语音默认 73.0——本项目的可靠度面向弱信号联络。
    required_snr_db: float = Field(
        default=24.0, description="判定链路可用所需的最小 SNR（弱信号/数字模式口径，非 SSB 73 约定），影响 reliability"
    )
    long_path: bool = Field(default=False, description="是否走长路径")


# --------------------------------------------------------------------------- #
# 输出
# --------------------------------------------------------------------------- #
class BandHourCell(BaseModel):
    """单个 (波段, 小时) 的预测结果。"""

    band: Band
    hour_utc: int
    freq_mhz: float
    muf_mhz: float = Field(..., description="该时刻路径 MUF（与波段无关，便于前端对比）")
    # VOACAP 输出（dvoacap 内部按 2700 Hz SSB 参考带宽算噪声，
    # 与 WSPR/PSKReporter 训练数据的 2500 Hz 参考带宽接近，二者可直接相减
    # 作残差——这里曾错写成 "dB-Hz"（1 Hz 参考），并被论文 4.3 节抄了一遍，
    # 误导成"两种量纲不可比较"；实际训练目标全程都在直接相减，见 3.3 节。
    snr_db: float = Field(..., description="信噪比 (dB，约 2700 Hz 参考带宽)")
    reliability: float = Field(..., ge=0, le=1, description="链路可用概率 0-1 (REL)")
    signal_dbw: float = Field(..., description="接收信号功率 (dBW)")
    score: float = Field(..., ge=0, le=100, description="0-100 综合可用性评分（用于热力图着色）")


class PredictResult(BaseModel):
    """一次预测的完整结果。"""

    model: str = Field(..., description="产生该结果的模型名，如 'voacap' / 'hybrid'")
    tx: GeoLocation
    rx: GeoLocation
    distance_km: float
    bearing_deg: float = Field(..., description="从 TX 看 RX 的方位角")
    month: int
    ssn: float
    cells: list[BandHourCell]


# --------------------------------------------------------------------------- #
# 模型接口
# --------------------------------------------------------------------------- #
@runtime_checkable
class PropagationModel(Protocol):
    """所有传播预测模型必须满足的接口。

    实现类需提供 ``name`` 属性与 ``predict`` 方法。
    """

    name: str

    def predict(self, req: PredictRequest) -> PredictResult:
        """对给定请求返回逐 (波段, 小时) 的预测结果。"""
        ...
