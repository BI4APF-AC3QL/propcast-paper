"""VoacapModel —— 用 ``dvoacap`` (VOACAP 物理引擎的 Python 移植) 实现的预测模型。

参考真实 API（已验证）：
    eng = PredictionEngine()
    eng.params = VoacapParams(ssn=.., month=.., tx_location=GeoPoint, tx_power=..)
    eng.predict(rx_geopoint, utc_fraction, [freqs_mhz])
    -> eng.circuit_muf.muf
    -> eng.predictions[i].signal.snr_db / service_prob / signal.power_dbw
"""
from __future__ import annotations

import math

from models.base import (
    AntennaSpec,
    BandHourCell,
    GeoLocation,
    PredictRequest,
    PredictResult,
    band_to_freq_mhz,
)
from models.geo import great_circle_km, initial_bearing_deg


def _reliability_to_score(reliability: float, snr_db: float) -> float:
    """把 reliability(0-1) 映射成 0-100 评分，并用 SNR 略作修正，便于热力图着色。"""
    base = max(0.0, min(1.0, reliability)) * 100.0
    # SNR 在 0-40 dB 之间给一点加权，避免 reliability 饱和时无区分度
    snr_bonus = max(0.0, min(40.0, snr_db)) / 40.0 * 10.0
    return max(0.0, min(100.0, 0.9 * base + snr_bonus))


class VoacapModel:
    """满足 ``PropagationModel`` 接口的 VOACAP 封装。"""

    name = "voacap"

    def __init__(self) -> None:
        # 延迟导入，确保未安装 dvoacap 时其余系统仍可启动
        from dvoacap.prediction_engine import PredictionEngine, VoacapParams
        from dvoacap.path_geometry import GeoPoint

        self._Engine = PredictionEngine
        self._Params = VoacapParams
        self._GeoPoint = GeoPoint

    def predict(self, req: PredictRequest) -> PredictResult:
        GeoPoint = self._GeoPoint
        tx_pt = GeoPoint.from_degrees(req.tx.lat, req.tx.lon)

        eng = self._Engine()
        eng.params = self._Params(
            ssn=float(req.ssn),
            month=int(req.month),
            tx_location=tx_pt,
            tx_power=float(req.tx_power_w),
            required_snr=float(req.required_snr_db),
            long_path=bool(req.long_path),
        )
        # 应用天线增益（Phase 1：等效到所需 SNR 的简化处理在 required_snr 之外，
        # 这里通过 antenna farm 默认 isotropic；增益细化留待后续）。
        _apply_antenna(eng, req.tx_antenna, req.rx_antenna)

        rx_pt = GeoPoint.from_degrees(req.rx.lat, req.rx.lon)
        freqs = [band_to_freq_mhz(b) for b in req.bands]

        cells: list[BandHourCell] = []
        for hour in req.hours_utc:
            utc_fraction = (hour % 24) / 24.0
            eng.predict(rx_pt, utc_fraction, list(freqs))
            muf = float(eng.circuit_muf.muf) if eng.circuit_muf else 0.0
            for band, freq, pred in zip(req.bands, freqs, eng.predictions):
                sig = pred.signal
                snr = float(getattr(sig, "snr_db", 0.0))
                rel = float(getattr(pred, "service_prob", 0.0))
                power_dbw = float(getattr(sig, "power_dbw", -200.0))
                cells.append(
                    BandHourCell(
                        band=band,
                        hour_utc=hour % 24,
                        freq_mhz=freq,
                        muf_mhz=round(muf, 2),
                        snr_db=round(snr, 1),
                        reliability=round(max(0.0, min(1.0, rel)), 3),
                        signal_dbw=round(power_dbw, 1),
                        score=round(_reliability_to_score(rel, snr), 1),
                    )
                )

        return PredictResult(
            model=self.name,
            tx=req.tx,
            rx=req.rx,
            distance_km=round(great_circle_km(req.tx.lat, req.tx.lon, req.rx.lat, req.rx.lon), 1),
            bearing_deg=round(initial_bearing_deg(req.tx.lat, req.tx.lon, req.rx.lat, req.rx.lon), 1),
            month=req.month,
            ssn=req.ssn,
            cells=cells,
        )


def _apply_antenna(eng, tx_ant: AntennaSpec, rx_ant: AntennaSpec) -> None:
    """把简单天线规格作用到引擎的天线农场。

    Phase 1 仅在 dvoacap 默认 isotropic 基础上设置峰值增益；
    方向图/俯仰角建模留待后续阶段。当前实现对默认值是安全的无操作。
    """
    try:
        from dvoacap import IsotropicAntenna

        for farm, spec in ((eng.tx_antennas, tx_ant), (eng.rx_antennas, rx_ant)):
            ant = IsotropicAntenna()
            # 部分版本以 dBi 常量增益建模 isotropic；若无对应属性则跳过。
            if hasattr(ant, "gain_db"):
                ant.gain_db = float(spec.gain_dbi)
            farm.add_antenna(ant)
            farm.select_antenna(0)
    except Exception:
        # 天线设置失败不应阻断预测，使用引擎默认天线即可。
        pass
