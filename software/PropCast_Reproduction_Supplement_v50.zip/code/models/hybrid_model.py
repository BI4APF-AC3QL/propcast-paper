"""HybridModel —— 课题核心模型（物理基线 + ML 偏差校正）。

Phase 1（当前）：物理基线 = VOACAP 输出；ML 校正层为**未训练的恒等占位**，
因此结果暂时等同 VOACAP，但接口、注册、网站“并列对比”视图已全部打通。

Phase 3：在 ``_apply_ml_correction`` 中加载训练好的模型
（基于 WSPR/RBN/PSKReporter 实测数据回归 VOACAP 残差或可达概率），
对每个 (band, hour) cell 的 snr/reliability/score 做校正。
届时本文件无需改动接口，网站可零改动切换。
"""
from __future__ import annotations

import logging
import math
from pathlib import Path
import numpy as np

from models import calibration
from models.base import BandHourCell, PredictRequest, PredictResult
from models.features import FEATURE_NAMES, build_features, clip_baseline
from models.geo import great_circle_km
from models.voacap_model import VoacapModel, _reliability_to_score


def cell_distance(req: PredictRequest) -> float:
    return great_circle_km(req.tx.lat, req.tx.lon, req.rx.lat, req.rx.lon)


def _snr_to_reliability(snr_db: float, required_snr_db: float, sigma: float = 10.0) -> float:
    """由修正后的 SNR 估计链路可用概率（logistic，sigma≈日间 SNR 波动尺度）。

    指数必须夹紧：波段完全关闭时 VOACAP 会给出 -1000 dB 量级的 SNR，
    math.exp 直接 OverflowError —— 表现为该路径整个预测请求 500。
    """
    x = (snr_db - required_snr_db) / max(1e-6, sigma)
    if x < -50.0:   # 1/(1+e^50) 已小于 2e-22，再往下没有数值意义
        return 0.0
    if x > 50.0:
        return 1.0
    return 1.0 / (1.0 + math.exp(-x))

# 训练产物默认路径（Phase 3 写入）
_ARTIFACT = Path(__file__).parent / "artifacts" / "hybrid_correction.joblib"


class HybridModel:
    """满足 ``PropagationModel`` 接口的混合模型。"""

    name = "hybrid"

    def __init__(self) -> None:
        self._baseline = VoacapModel()
        self._mtime = self._artifact_mtime()
        self._corrector = self._load_corrector()
        self._calib = calibration.load()
        self._coarse = calibration.load_coarse(self._calib)

    @staticmethod
    def _artifact_mtime() -> float:
        """产物、标定、粗模型的 mtime 合并成一个签名，任一变化都触发热加载。"""
        t = 0.0
        for p in (_ARTIFACT, calibration.CALIB_PATH, calibration.COARSE_PATH):
            try:
                t += p.stat().st_mtime
            except OSError:
                pass
        return t

    def _refresh(self) -> None:
        """产物被重训替换后热加载，无需重启服务。

        模型是注册表里的单例，长驻进程；后台重训写入新 artifact 后若不重载，
        网站会一直用旧模型——"持续学习"就只停在磁盘上。retrain 用 os.replace
        原子替换，因此这里读到的一定是完整文件。
        """
        mtime = self._artifact_mtime()
        if mtime != self._mtime:
            self._mtime = mtime
            self._corrector = self._load_corrector()
            self._calib = calibration.load()
            self._coarse = calibration.load_coarse(self._calib)
            logging.getLogger(__name__).info("hybrid 模型已热加载新产物 (mtime=%s)", mtime)

    @staticmethod
    def _load_corrector():
        """加载训练好的 ML 校正器；未训练或特征不匹配时返回 None（走恒等校正）。"""
        if not _ARTIFACT.exists():
            return None
        try:
            import joblib  # 仅在有产物时才需要 ml 依赖

            art = joblib.load(_ARTIFACT)
        except Exception:
            return None
        # 特征契约校验：产物的特征名必须与当前 FEATURE_NAMES 完全一致。
        # 否则按位置传入会把值喂到错误的特征上——静默产出错误预测，比不校正更糟。
        saved = list(art.get("feature_names") or [])
        if saved != FEATURE_NAMES:
            logging.getLogger(__name__).warning(
                "hybrid artifact 特征与当前代码不一致（产物 %d 项 / 代码 %d 项），"
                "已回退为纯 VOACAP。请用 python -m models.train 重新训练。",
                len(saved), len(FEATURE_NAMES),
            )
            return None
        return art

    @property
    def is_trained(self) -> bool:
        self._refresh()
        return self._corrector is not None

    @property
    def info(self) -> dict:
        """当前在役产物的元信息，供 /api/modelstats 展示。"""
        self._refresh()
        c = self._corrector or {}
        return {
            "trained": self._corrector is not None,
            "trained_at": c.get("trained_at"),
            "n_train": c.get("n_train"),
            "rmse": c.get("rmse"),
            "output_offset": c.get("output_offset", 0.0),
            "n_features": len(c.get("feature_names") or []),
            "sources": c.get("sources"),
            # 标定：可靠度曲线的尺度 + 自适应平滑的档位（供前端解释"为什么这条路径更保守"）
            "reliability_sigma": round(calibration.reliability_sigma(
                self._calib, c.get("snr_scale", 8.0)), 2) if c else None,
            "calibrated": self._calib is not None,
            "smoothing": [
                {"distance_km": d,
                 "support": calibration.support_at(self._calib, d),
                 "sigma_hour": round(calibration.bandwidth(
                     calibration.support_at(self._calib, d))[0], 2),
                 "fine_weight": round(calibration.blend_weight(
                     calibration.support_at(self._calib, d)), 2)}
                for d in (2000, 6000, 10000, 16000)
            ] if self._calib else [],
            "coarse_rmse": (self._calib or {}).get("coarse_rmse"),
            "coarse_active": self._coarse is not None,
        }

    def predict(self, req: PredictRequest) -> PredictResult:
        self._refresh()
        result = self._baseline.predict(req)
        if self._corrector is None:
            # 未训练：恒等校正，仅改 model 名（接口/对比视图照常工作）
            return result.model_copy(update={"model": self.name})

        # 一次性批量校正所有 (波段,小时) cell，避免逐 cell 调用模型。
        deltas = self._predict_deltas(result.cells, req)
        center = self._corrector.get("snr_center", -13.0)
        # 尺度取模型自身的预测误差，而非训练分布宽度（理由见 models/calibration.py）
        scale = calibration.reliability_sigma(
            self._calib, self._corrector.get("snr_scale", 8.0))
        # 对残差校正做轻量二维连续性平滑，抑制树模型在相邻小时/波段间的棋盘状跳变。
        # 仅平滑校正量，不改变 VOACAP 基线；边界使用相邻有效单元的加权平均。
        arr = np.asarray(deltas, dtype=float).reshape(len(req.bands), len(req.hours_utc))
        if arr.size and arr.shape[0] > 1 and arr.shape[1] > 1:
            sm = arr.copy()
            for i in range(arr.shape[0]):
                for j in range(arr.shape[1]):
                    neigh = [arr[i, j]]
                    if i: neigh.append(arr[i - 1, j])
                    if i + 1 < arr.shape[0]: neigh.append(arr[i + 1, j])
                    if j: neigh.append(arr[i, j - 1])
                    if j + 1 < arr.shape[1]: neigh.append(arr[i, j + 1])
                    sm[i, j] = 0.55 * arr[i, j] + 0.45 * float(np.mean(neigh))
            deltas = sm.ravel()
        corrected = []
        for cell, delta in zip(result.cells, deltas):
            # 基线也要截断。VOACAP 对闭合路径会给出 -1772 dB 这类哨兵值，直接相加
            # 得到的仍是 -1772 —— 校正量本身是有界的，救不回来。训练侧已按同一下限
            # 重算过目标（见 retrain._apply_baseline_floor），推理侧不跟上就会两端
            # 口径不一致。实测该处失效路径上的信噪比误差由 84.5 dB 降至 8.3 dB。
            new_snr = clip_baseline(cell.snr_db) + float(delta)
            # 校正后 SNR 为真实 WSPR 量纲；reliability 用训练集标定的中心/尺度。
            new_rel = _snr_to_reliability(new_snr, center, sigma=scale)
            corrected.append(cell.model_copy(update={
                "snr_db": round(new_snr, 1),
                "reliability": round(new_rel, 3),
                "score": round(_reliability_to_score(new_rel, new_snr), 1),
            }))
        return result.model_copy(update={"model": self.name, "cells": corrected})

    # 邻域采样点。核宽由支撑度决定，这里只需覆盖到最大核宽的量级。
    _DH = (-8.0, -4.0, -2.0, -1.0, 0.0, 1.0, 2.0, 4.0, 8.0)
    _DF = (-0.3, -0.15, 0.0, 0.15, 0.3)

    def _predict_deltas(self, cells: list[BandHourCell], req: PredictRequest):
        """回归 VOACAP 残差，并在 (小时, 频率) 邻域上按支撑度自适应加权平均。

        为什么要平滑：LightGBM 是分段常数，相邻 (波段,小时) 的校正量会跳变。实测这种
        跳变**只在训练支撑稀薄的路径上爆发** —— 北京→东京（该距离档占训练集 27.1%）
        的评分网格抖动 5.38，与 VOACAP 的 5.75 持平；北京→圣保罗（0.1%）抖动 14.25，
        而 VOACAP 在该路径上无可读单元（数字见论文表 5-1）。

        为什么按支撑度自适应：固定核宽会误伤数据密集处的真实结构。σ = σmax·K/(K+n)
        让密集处 σ→0（等价于不平滑，且跳过整个邻域计算），稀疏处 σ→σmax。

        为什么保持 voacap_snr/muf 不变、并让 MUF 随频率等比缩放：
        平滑的对象是**校正函数**，不是物理基线——基线的日变化正是要保留的信号。
        而校正量对「离 MUF 多远」极其敏感，扰动频率时若不同步缩放 MUF，采样点会落到
        不同的电离层工作区间，平滑掉的就是真信号。12 折交叉验证配对检验：σ_f=0.2 时
        同步优于不同步 1.13 个百分点（11/12 折，p=0.016），σ_f=0.35 时优 1.68 个
        百分点（p=0.007）；本处所用的小核宽下两者差异不显著，但方向性明确。
        """
        import warnings

        import numpy as np

        tx_power_dbm = 10.0 * math.log10(max(1e-3, req.tx_power_w)) + 30.0
        dist = cell_distance(req)
        n_sup = calibration.support_at(self._calib, dist)
        sigma_h, sigma_f = calibration.bandwidth(n_sup)
        smooth = sigma_h >= calibration.SMOOTH_MIN_SIGMA_H

        offs_h = self._DH if smooth else (0.0,)
        offs_f = self._DF if smooth else (0.0,)
        w = np.outer(
            [math.exp(-0.5 * (d / sigma_h) ** 2) for d in offs_h] if smooth else [1.0],
            [math.exp(-0.5 * (a / sigma_f) ** 2) for a in offs_f] if smooth else [1.0],
        ).ravel()
        w = w / w.sum()

        matrix = []
        for cell in cells:
            for dh in offs_h:
                for df in offs_f:
                    matrix.append(build_features({  # type: ignore[arg-type]
                        "distance_km": dist,
                        "tx_lat": req.tx.lat, "tx_lon": req.tx.lon,
                        "rx_lat": req.rx.lat, "rx_lon": req.rx.lon,
                        "hour_utc": (float(cell.hour_utc) + dh) % 24.0, "month": req.month,
                        "freq_mhz": cell.freq_mhz * (1.0 + df), "ssn": req.ssn,
                        "tx_power_dbm": tx_power_dbm,
                        "voacap_snr": cell.snr_db, "voacap_muf": cell.muf_mhz * (1.0 + df),
                    }))
        # 列顺序由 FEATURE_NAMES 保证与训练一致；按位置传入，过滤已知的特征名误报。
        X = np.asarray(matrix, dtype=float)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=UserWarning)
            fine = self._corrector["model"].predict(X).reshape(len(cells), -1) @ w
            fine = fine + float(self._corrector.get("output_offset") or 0.0)
            if self._coarse is None:
                return fine
            # 稀疏区回退：把权重从高容量模型让给低容量模型（不是让给纯 VOACAP，
            # 后者在受控抽稀的每一档上都差 2.4-8.1 倍，见论文表 5-5）。
            # 粗模型共用同一批特征，取列子集即可。
            coarse = self._coarse.predict(
                X[:, calibration.COARSE_INDEX]).reshape(len(cells), -1) @ w
        wf = calibration.blend_weight(n_sup)
        return wf * fine + (1.0 - wf) * coarse
