"""评估对比：VOACAP 基线 vs 混合模型（在时间留出集上）。

指标：对 measured_snr 的预测误差
  - VOACAP-only:  pred = voacap_snr
  - Hybrid:       pred = voacap_snr + 校正残差
报告 RMSE / MAE 及改进百分比，并写出 JSON。
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from models.features import apply_baseline_floor
from models.train import ARTIFACT, split_by_time


def _rmse(e: np.ndarray) -> float:
    return float(np.sqrt(np.mean(e ** 2)))


def evaluate(data_path: Path, artifact: Path = ARTIFACT) -> dict:
    # 与训练侧同一下限，否则评估用的基线和模型见过的基线不是一回事
    df = apply_baseline_floor(pd.read_parquet(data_path))
    _, test = split_by_time(df)
    bundle = joblib.load(artifact)
    model, feats = bundle["model"], bundle["feature_names"]

    import warnings

    measured = test["measured_snr"].to_numpy()
    voacap = test["voacap_snr"].to_numpy()
    # 列顺序由 feature_names 保证一致；按位置预测，过滤特征名误报。
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=UserWarning)
        delta = model.predict(test[feats].to_numpy())
    hybrid = voacap + delta

    err_v = measured - voacap
    err_h = measured - hybrid
    out = {
        "n_test": int(len(test)),
        "voacap": {"rmse": _rmse(err_v), "mae": float(np.mean(np.abs(err_v))),
                   "bias": float(np.mean(err_v))},
        "hybrid": {"rmse": _rmse(err_h), "mae": float(np.mean(np.abs(err_h))),
                   "bias": float(np.mean(err_h))},
    }
    out["rmse_improvement_pct"] = round(
        100.0 * (out["voacap"]["rmse"] - out["hybrid"]["rmse"]) / out["voacap"]["rmse"], 1
    )
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    Path("data/processed/eval.json").write_text(json.dumps(out, indent=2), encoding="utf-8")

    print("== 评估（测试集，对 measured_snr 的预测误差）==")
    print(f"  样本: {out['n_test']}")
    print(f"  VOACAP : RMSE={out['voacap']['rmse']:.2f}  MAE={out['voacap']['mae']:.2f}  bias={out['voacap']['bias']:.2f}")
    print(f"  Hybrid : RMSE={out['hybrid']['rmse']:.2f}  MAE={out['hybrid']['mae']:.2f}  bias={out['hybrid']['bias']:.2f}")
    print(f"  RMSE 改进: {out['rmse_improvement_pct']}%")
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=Path, default=Path("data/processed/dataset.parquet"))
    ap.add_argument("--artifact", type=Path, default=ARTIFACT)
    args = ap.parse_args()
    evaluate(args.data, args.artifact)


if __name__ == "__main__":
    main()
