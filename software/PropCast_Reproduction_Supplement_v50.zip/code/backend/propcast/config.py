"""后端配置（pydantic-settings）。支持通过环境变量或 .env 覆盖。"""
from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="PROPCAST_", env_file=".env", extra="ignore")

    # CORS：前端开发服务器
    cors_origins: list[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]

    # 外部数据源
    swpc_base: str = "https://services.swpc.noaa.gov"

    # 缓存 TTL（秒）
    spaceweather_ttl: int = 600
    predict_ttl: int = 900

    # 限流：每 IP 每分钟最大请求数（仅 /api/*）
    rate_limit_per_min: int = 120

    # HTTP 客户端超时
    http_timeout: float = 10.0

    # --- 持续学习闭环（采集 → 入库 → 增量重训） --- #
    trainer_enabled: bool = True          # 关掉即退回「手工跑脚本」模式
    # 每轮 tick 间隔。每轮只向上游发一次请求，因此这个值同时决定请求频率。
    # 取 15 分钟：全球流的回溯窗口是 10 分钟，比它更密只会拿到重复数据（会被
    # (时刻,呼号对,频率) 去重挡掉），意义不大；而 15 分钟 = 96 次/天，相对该端点
    # 的限流（实测两分钟内 16 次即被全面 503）是非常温和的频率。
    collect_interval_min: int = 15
    # 每轮自采链路数；0 = 只处理用户上报。
    # **这里曾是整个闭环最大的人为瓶颈**：上游单次请求返回约 1 450 条通过校验的
    # 链路，而这里只取 120 条，等于丢掉 92% 的免费数据——上游限的是请求次数而非
    # 行数，多取不花任何额外配额。实测代价极低：ingest 逐条算 VOACAP 为 5.4 ms/条，
    # 取满 1 456 条也只占 30 分钟轮期的 0.4%，一次完整重训另需 4 s。
    # 取 1 200：接近单次返回量，留出余量以免上游偶尔多返回时反而截断。
    collect_limit: int = 1200
    # 新增观测达到此数即触发重训。必须随 collect_limit 一同放大：若仍取 500，
    # 每轮采集都会越过阈值，重训就退化为"每轮都跑"。
    # 取 **正好两轮**的采集量：曾设为 2500，恰好比 2×1200 多 100 条，于是每次都要
    # 白等第三轮（45 分钟而非 30 分钟）。这类阈值应当对齐到采集额度的整数倍。
    retrain_min_new: int = 2400
    retrain_interval_h: float = 24.0      # 或距上次重训超过此小时数
    # 全局收益门槛 + models.retrain 中的距离/频段分片护栏。
    # 全局收益门槛 + models.retrain 中的距离/频段分片护栏。
    retrain_min_gain: float = 0.2
    # 放入训练集的新观测比例（按时间取最早的一部分）。**过渡期参数**：
    # 现阶段新数据只覆盖两天、一个月份、一个太阳活动水平，全量放入会让模型过度
    # 迁就这个窄切片（受控扫描：f=1.0 时新数据 +4.77% 但历史 -2.70%；f=0.5 时
    # +4.22% / +0.70%，是唯一两端都为正的档）。待新观测覆盖多个月份与太阳活动
    # 水平后应上调，届时需重新扫描，勿凭直觉调整。详见 models/retrain.py
    # 的 split_by_source。
    retrain_new_train_frac: float = 0.5

    # --- 采集的分层选取 --- #
    # 每轮只向 PSKReporter 发一次请求（该端点限流很严，实测两分钟内 16 次请求即对
    # 本机全面 503，恢复需数十分钟），但一次返回约 1500 条可用链路，远多于
    # collect_limit。因此取哪 N 条是有讲究的，详见 data/collect_observations.py。
    # 全球流回溯窗口。**调大它没有用，只会变差**，这一点实测过：
    #   10 min 窗口 -> 1494 条可用链路；30 min 窗口 -> 1493 条。
    # 上游对 flowStartSeconds 基本不敏感，返回的是一份大小固定（约 1500 条）的近实时
    # 流。而该接口的分组响应**不含时间字段**，所有记录只能按取样时刻打戳，于是窗口
    # 直接就是时间戳误差的上界——放宽到 30 min 等于把 hour_utc 的误差从 0.17h 放大到
    # 0.5h，而 hour_utc 与由它算出的三个太阳天顶角都是模型特征。
    # 想要更多可选链路，只能靠改进选取（见 select_stratified）。
    collect_window_min: int = 10
    # 距离 ≥ 此值的链路视为稀缺，优先全收。取 10000km 是因为训练集中 >10000km 仅占
    # 3.9%，而实测每批全球流里有约 100 条。
    collect_far_km: float = 10_000.0
    # 长链路最多占额度的比例。**在当前额度下这一层基本不再截断**：额度 1200 已接近
    # 单批可用量 1456，长链路（约 100 条）远低于 600 的上限，实际是全收。该参数是为
    # 额度被调小的情形保留的护栏——那时若不设限，一批里 100 条长链路会占满小额度的
    # 大半，采集分布就完全由当批内容决定。
    collect_far_share: float = 0.5
    # 关注网格（4 位 Maidenhead）：链路任一端落在其中就优先收下。
    # 只能本地过滤——上游的 senderLocator 参数实测无效，会返回未过滤的全球流。
    #   PROPCAST_PRIORITY_GRIDS='["QF56","GG66"]'
    priority_grids: list[str] = [
        "QF56", "GG66", "RE68", "KG33", "OF78",  # 悉尼 / 圣保罗 / 奥克兰 / 约堡 / 珀斯
        "FH17", "MK82", "OM89",                  # 利马 / 班加罗尔 / 华北
    ]

    # 众包上报
    contribute_enabled: bool = True
    contribute_rows_per_window: int = 3000  # 每 IP 每 10 分钟最多上报的观测条数


settings = Settings()
