"""极简内存 TTL 缓存（Phase 4 可替换为 Redis）。

有界版：过期条目原实现只在同键再次 get 时才被动删除，键随用户输入变化的
缓存（callsign:{呼号}、pskspots:{网格} 等）会无限累积——公网长期运行下
任何扫描器都能把内存撑大。现在 set 时超过上限就先清一遍过期项，仍超则
按「最早过期优先」淘汰，内存严格有界。
"""
from __future__ import annotations

import time
from typing import Any

_MAX_ENTRIES = 4096  # 正常工作集约几十个键，这个上限只防恶意/异常增长


class TTLCache:
    def __init__(self, max_entries: int = _MAX_ENTRIES) -> None:
        self._store: dict[str, tuple[float, Any]] = {}
        self._max = max_entries

    def get(self, key: str) -> Any | None:
        item = self._store.get(key)
        if item is None:
            return None
        expires_at, value = item
        if time.monotonic() > expires_at:
            self._store.pop(key, None)
            return None
        return value

    def get_stale(self, key: str) -> Any | None:
        """取值而不管是否过期——供上游数据源报错时的降级回退。

        与 get() 的区别：过期也返回、且不删除条目。只应在实时抓取失败时才用，
        正常路径永远走 get()，否则「缓存」就失去了 TTL 的意义。
        """
        item = self._store.get(key)
        return item[1] if item is not None else None

    def set(self, key: str, value: Any, ttl: int) -> None:
        if len(self._store) >= self._max and key not in self._store:
            self._evict()
        self._store[key] = (time.monotonic() + ttl, value)

    def _evict(self) -> None:
        """先清过期项；仍然超限则按最早过期优先淘汰约 10%，摊薄每次 set 的开销。"""
        now = time.monotonic()
        expired = [k for k, (exp, _) in self._store.items() if exp <= now]
        for k in expired:
            self._store.pop(k, None)
        if len(self._store) >= self._max:
            by_expiry = sorted(self._store.items(), key=lambda kv: kv[1][0])
            for k, _ in by_expiry[: max(1, self._max // 10)]:
                self._store.pop(k, None)


cache = TTLCache()
