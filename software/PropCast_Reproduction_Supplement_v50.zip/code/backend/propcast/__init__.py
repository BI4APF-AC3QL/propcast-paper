"""propcast —— 短波传播预测系统后端 (FastAPI)。"""

__version__ = "0.1.0"
