"""FastAPI 应用入口。

启动：
    uvicorn propcast.main:app --reload      （从仓库根目录，已 pip install -e .）
文档： http://127.0.0.1:8000/docs
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from propcast import __version__
from propcast.api import contrib as contrib_api
from propcast.api import data as data_api
from propcast.api import extras as extras_api
from propcast.api import predict as predict_api
from propcast.config import settings
from propcast.ratelimit import RateLimitMiddleware
from propcast.services import trainer

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


@asynccontextmanager
async def lifespan(_: FastAPI):
    # 后台学习循环：采集观测 → 入库 → 数据够多时增量重训。
    # 双进程部署下由锁文件选举，只有一个进程真正跑训练。
    trainer.start()
    yield
    await trainer.stop()


app = FastAPI(
    title="PropCast — 短波传播预测 API",
    version=__version__,
    description="点到点多波段 HF 传播预测（VOACAP / 混合模型可插拔）+ 空间天气 / spots / 灰线。",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(
    RateLimitMiddleware,
    max_requests=settings.rate_limit_per_min,
    window_s=60,
)

app.include_router(predict_api.router)
app.include_router(data_api.router)
app.include_router(extras_api.router)
app.include_router(contrib_api.router)


@app.get("/health", tags=["meta"])
def health() -> dict:
    return {"status": "ok", "version": __version__}


# 若前端已构建（frontend/dist），同端口托管静态资源 + SPA 回退。
# 本地公网部署用：一个进程同时提供 API 和网站，无需 Nginx/Docker。
_frontend_dist = Path(__file__).resolve().parents[2] / "frontend" / "dist"
if _frontend_dist.is_dir():
    app.mount("/assets", StaticFiles(directory=_frontend_dist / "assets"), name="assets")
    app.mount("/textures", StaticFiles(directory=_frontend_dist / "textures"), name="textures")

    _API_PREFIXES = ("api/", "docs", "redoc", "openapi.json", "health")

    @app.get("/{full_path:path}", tags=["meta"], include_in_schema=False)
    def spa(full_path: str):
        from fastapi.responses import FileResponse, JSONResponse

        # 未注册的 API 路径必须返回 JSON 404，不能被 SPA 兜底成 200+index.html——
        # 否则前端 r.json() 抛 "Unexpected token '<'"，把「路由不存在」伪装成解析错误。
        if full_path.startswith(_API_PREFIXES):
            return JSONResponse({"detail": f"接口不存在: /{full_path}"}, status_code=404)

        # 路径穿越防护：%2e%2e%2f 等编码不会被上游规范化，直接用 dist/ 拼接可读到
        # 仓库任意文件。解析真实路径后必须仍位于 dist 目录内，否则一律回退 index.html。
        if full_path:
            try:
                candidate = (_frontend_dist / full_path).resolve()
                if candidate.is_file() and candidate.is_relative_to(_frontend_dist.resolve()):
                    return FileResponse(candidate)
            except (OSError, ValueError):
                pass
        return FileResponse(_frontend_dist / "index.html")
