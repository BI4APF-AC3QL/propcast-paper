"""极简内存限流中间件（固定窗口，按客户端 IP）。

无外部依赖；生产可替换为 Redis 令牌桶。仅对 /api/* 生效。
"""
from __future__ import annotations

import time

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse


class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, max_requests: int = 120, window_s: int = 60) -> None:
        super().__init__(app)
        self.max_requests = max_requests
        self.window_s = window_s
        self._hits: dict[str, list[float]] = {}
        self._last_sweep = time.monotonic()

    def _sweep(self, window_start: float) -> None:
        """删除窗口内已无请求的 IP 条目。

        原实现只在单个 IP 的列表内裁剪时间戳，键本身永不删除——服务暴露在公网
        IPv6 上时，攻击者可用一个 /64 内的海量源地址无限撑大这个字典。
        """
        stale = [ip for ip, ts in self._hits.items() if not ts or ts[-1] <= window_start]
        for ip in stale:
            self._hits.pop(ip, None)

    async def dispatch(self, request: Request, call_next):
        if not request.url.path.startswith("/api/"):
            return await call_next(request)

        client = request.client.host if request.client else "unknown"
        now = time.monotonic()
        window_start = now - self.window_s
        # 每个窗口最多清扫一次，开销可忽略
        if now - self._last_sweep > self.window_s:
            self._sweep(window_start)
            self._last_sweep = now
        hits = [t for t in self._hits.get(client, []) if t > window_start]
        if len(hits) >= self.max_requests:
            retry = int(self.window_s - (now - hits[0])) + 1
            return JSONResponse(
                status_code=429,
                content={"detail": "请求过于频繁，请稍后再试。"},
                headers={"Retry-After": str(max(1, retry))},
            )
        hits.append(now)
        self._hits[client] = hits
        return await call_next(request)
