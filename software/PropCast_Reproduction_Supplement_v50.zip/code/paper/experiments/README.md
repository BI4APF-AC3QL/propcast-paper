# 论文实验脚本

复现顺序（均从仓库根目录运行）：

```bash
# 0) 还原历史训练集缺失的两端经度（后续按小时重算天顶角必需）
python paper/experiments/recover_raw.py      # -> data/processed/_raw_recovered.parquet

# 1) 第 7 章：单一切分的不可靠性（三种切分对照）
python paper/experiments/exp_splits.py

# 2) 第 5 章：邻域正则化的精度代价（12 折 CV）
python paper/experiments/exp_cv.py           # -> _exp_cv.csv

# 2b) 第 7.1.5 节：留一地理区域交叉验证 —— 模型是否在记住地理位置而非学物理
python paper/experiments/exp_geo_cv.py       # -> _exp_geo_cv.csv

# 3) 第 5 章：受控抽稀 —— 稀疏区该回退给谁
python paper/experiments/exp_sparse.py       # 改 BAND 常量切换目标距离段

# 4) 第 5 章：混合权重 w(n) 的端到端验证
python paper/experiments/exp_verify_sched.py # -> _exp_sched.csv

# 5) 第 5 章：频率扰动是否需要同步缩放 MUF（12 折 CV 配对检验）
python paper/experiments/exp_muf_sync.py     # -> _exp_muf_sync.csv

# 6) 第 7 章：特征组消融 + 扩展特征复核
python paper/experiments/exp_ablation.py     # -> _exp_ablation.csv, _exp_importance.csv

# 6b) 第 7.3.2 节：向物理基线全局收缩的代价（12 折 CV）
python paper/experiments/exp_shrink.py       # -> _exp_shrink.csv

# 6c) 第 6 章：众包数据是否真的让模型变好（按时间 6 折的受控对照）
#     依赖持续运行系统累积的 data/processed/observations.parquet，结果随数据增长而变
python paper/experiments/exp_crowd_gain.py   # -> _exp_crowd.csv

# 7) 生成插图
python paper/figures/make_ch3_figs.py
python paper/figures/make_ch4_figs.py
python paper/figures/make_ch5_figs.py
python paper/figures/make_ch6_figs.py
python paper/figures/make_ch7_figs.py

# 8) 刷新第 5 章的表 5-1 / 5-7（用固定的历史训练集，结果不随系统运行漂移）
python paper/make_ch5_tables.py --write

# 9) 刷新第 6 章的闭环运行状态（表 6-1 + 图 6-2，二者同时更新）
python paper/snapshot_system_state.py --write
```

## 关于第 6 章的数字

表 6-1 与 6.5 节的计数来自**持续运行**的系统，会随时间增长（实测数分钟内即可变化）。
它们由 `snapshot_system_state.py` 生成并标注数据截止时间，不要手工修改；
该脚本同时重画图 6-2，保证表、图注与图三者不会错位。

## 关于 exp_splits.py 的说明

该脚本刻意保留了两个缺陷——固定 600 棵树不做早停、且只用单一切分——因为第 7.1 节
正是要展示这两个缺陷各自的后果。**其绝对数值不应被单独引用**，只用于与交叉验证
结果作对照。其余脚本均使用独立验证集早停。

## 数据依赖

- `data/processed/dataset_multiyear.parquet`：93 500 条 WSPR 链路（由
  `python -m data.build_dataset` 生成，需联网访问 wspr.live）
- `models/artifacts/hybrid_correction.joblib`：在役模型产物（部分脚本用于对照）

上述两者均不入库（见 `.gitignore`），需先在本地生成。
