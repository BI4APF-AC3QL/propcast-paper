"""留一地理区域交叉验证：模型是否在"记住特定台站/区域"，而非学传播物理。

动机：7.1.3 节的交叉验证协议只按 (年, 月) 分折——只检验了时间维度的泛化，
没有检验空间维度。数据集本就被欧美站点主导（3.2 节），若模型的低 RMSE 主要
来自"见过这片区域的很多样本"而非学到了距离/太阳天顶角/频率等物理关系，
那么对训练时几乎没见过的地理区域，误差应当显著更差。

分区方式：按发射端经度 60° 分带（6 个区域，约等于大洲量级），而非精细网格——
数据高度不均血（143 个 20°×20° 网格中最大格 21 899 条、多数格远小于此），
精细分区会产生大量样本过少、RMSE 估计噪声很大的折；60° 分带在样本量与
地理跨度之间取得可用的折衷，且与时间维度的 12 折规模同量级、折数上可比较。

协议与 exp_cv.py 一致：留出一个区域整体作测试，其余按 90/10 切出验证集供
早停；不做平滑/收缩的超参搜索，只报基线 RMSE——这里要回答的是"留出一整片
没见过的地理区域后模型是否失效"，不是"某种正则化在这个切分下是否有效"。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import lightgbm as lgb

from models.features import FEATURE_NAMES
from models.features import apply_baseline_floor
from models.hyperparams import LGBM_PARAMS, EARLY_STOPPING_ROUNDS

LON_BAND_DEG = 60.0


def rmse(y, p):
    return float(np.sqrt(((y - p) ** 2).mean()))


def _region_label(lonband: int) -> str:
    lo = lonband * LON_BAND_DEG
    hi = lo + LON_BAND_DEG
    return f"[{lo:.0f},{hi:.0f})"


def main() -> None:
    df = apply_baseline_floor(pd.read_parquet("data/processed/_raw_recovered.parquet"))
    df["lonband"] = np.floor(df["tx_lon"] / LON_BAND_DEG).astype(int)

    groups = sorted(df.groupby("lonband").size().items(), key=lambda kv: kv[0])
    print(f"按发射端经度 {LON_BAND_DEG:.0f}° 分带（区域 -> 样本数）：",
          {_region_label(g): n for g, n in groups}, "\n")

    rng = np.random.default_rng(0)
    voacap_rmse_all = rmse(df["measured_snr"].to_numpy(), df["voacap_snr"].to_numpy())
    rows = []
    for lonband, n_total in groups:
        if n_total < 500:
            print(f"  区域 {_region_label(lonband)} 样本量 {n_total} 过少，跳过")
            continue
        te = df[df.lonband == lonband]
        rest = df[df.lonband != lonband]
        idx = rng.permutation(len(rest))
        nv = int(len(rest) * 0.1)
        va, tr = rest.iloc[idx[:nv]], rest.iloc[idx[nv:]]

        model = lgb.LGBMRegressor(**LGBM_PARAMS)
        model.fit(tr[FEATURE_NAMES].to_numpy(), tr["residual"].to_numpy(),
                  eval_set=[(va[FEATURE_NAMES].to_numpy(), va["residual"].to_numpy())],
                  callbacks=[lgb.early_stopping(EARLY_STOPPING_ROUNDS, verbose=False)])

        y = te["measured_snr"].to_numpy()
        pred_snr = te["voacap_snr"].to_numpy() + model.predict(te[FEATURE_NAMES].to_numpy())
        b0 = rmse(y, pred_snr)
        v0 = rmse(y, te["voacap_snr"].to_numpy())

        rec = {
            "region_lon": _region_label(lonband),
            "n_test": len(te),
            "n_train": len(tr),
            "rmse": b0,
            "voacap_rmse": v0,
            "trees": model.best_iteration_,
            "tx_lat_mean": float(te["tx_lat"].mean()),
        }
        rows.append(rec)
        print(f"  区域 {rec['region_lon']:>12}  n_test={rec['n_test']:>6}  "
              f"RMSE={b0:.2f}  VOACAP={v0:.2f}  trees={rec['trees']}")

    r = pd.DataFrame(rows)
    print(f"\n{len(r)} 个区域，样本量 {r['n_test'].min()}–{r['n_test'].max()}")
    print(f"混合模型 RMSE：{r['rmse'].min():.2f}–{r['rmse'].max():.2f} dB，"
          f"相差 {r['rmse'].max() / r['rmse'].min():.2f} 倍")
    print(f"全量池 VOACAP 基线 RMSE（对照，未分折）：{voacap_rmse_all:.2f} dB")
    print(f"各区域 VOACAP RMSE：{r['voacap_rmse'].min():.2f}–{r['voacap_rmse'].max():.2f} dB")
    r.to_csv("data/processed/_exp_geo_cv.csv", index=False)


if __name__ == "__main__":
    main()
