"""在三种切分上各自重训后评估平滑/收缩，排除分布漂移带来的假象。

默认的时间切分里，测试集只有 2024 年 9/12 月，训练集却跨 2021/2022/2024
（太阳活动 SSN 从 ~30 到 ~150）。此时"抹掉小时结构反而更好"很可能只是
说明跨太阳周期的小时×季节交互不可迁移，而不是小时本身没信息。

三种切分：
  time      原切分（含跨周期漂移）
  random    i.i.d. 随机切分（无漂移，纯粹回答"小时结构是信号还是噪声"）
  time2024  只用 2024 年数据做时间切分（同周期内的真实外推场景）
只有在三种切分下都成立的参数，才值得上线。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import lightgbm as lgb

from models.features import FEATURE_NAMES, build_features
from models.features import apply_baseline_floor

RAWCOLS = ["distance_km", "tx_lat", "tx_lon", "rx_lat", "rx_lon", "hour_utc",
           "month", "freq_mhz", "ssn", "tx_power_dbm", "voacap_snr", "voacap_muf"]
DH = [float(d) for d in range(-12, 13)]
DF = [-0.30, -0.15, 0.0, 0.15, 0.30]


def fit(tr):
    m = lgb.LGBMRegressor(n_estimators=600, learning_rate=0.05, num_leaves=63,
                          subsample=0.9, colsample_bytree=0.9, random_state=42, verbose=-1)
    m.fit(tr[FEATURE_NAMES].to_numpy(), tr["residual"].to_numpy())
    return m


def run(name: str, tr: pd.DataFrame, te: pd.DataFrame) -> None:
    y = te["residual"].to_numpy()
    model = fit(tr)
    base = model.predict(te[FEATURE_NAMES].to_numpy())
    b0 = float(np.sqrt(((y - base) ** 2).mean()))

    def rel(p):
        return (b0 - float(np.sqrt(((y - p) ** 2).mean()))) / b0 * 100

    raws = te[RAWCOLS].to_dict("records")
    print(f"\n=== {name} ===  train {len(tr)}  test {len(te)}  基线 RMSE {b0:.4f}")

    ph = {d: model.predict(np.array([build_features({**r, "hour_utc": (r["hour_utc"] + d) % 24.0})
                                     for r in raws])) for d in DH}
    print("  小时平滑 σ_h:  " + "  ".join(
        f"{s:g}h {rel(sum(np.exp(-0.5*(d/s)**2)*ph[d] for d in DH) / sum(np.exp(-0.5*(d/s)**2) for d in DH)):+.3f}%"
        for s in [1.0, 2.0, 3.0, 4.0, 6.0, 12.0]))

    pf = {a: model.predict(np.array([build_features({
        **r, "freq_mhz": r["freq_mhz"] * (1 + a), "voacap_muf": r["voacap_muf"] * (1 + a)})
        for r in raws])) for a in DF}
    print("  波段平滑 σ_f:  " + "  ".join(
        f"{s:g} {rel(sum(np.exp(-0.5*(a/s)**2)*pf[a] for a in DF) / sum(np.exp(-0.5*(a/s)**2) for a in DF)):+.3f}%"
        for s in [0.10, 0.20, 0.35]))

    # 分层收缩：细预测 -> 向宽核（σ=12h）预测收缩，权重由 (波段×小时×距离) 支撑度定
    wide = sum(np.exp(-0.5 * (d / 12.0) ** 2) * ph[d] for d in DH) \
        / sum(np.exp(-0.5 * (d / 12.0) ** 2) for d in DH)
    key = lambda d: list(zip(d["band"], (d["hour_utc"].round().astype(int) % 24),
                             (d["distance_km"] // 2000).astype(int)))
    cnt = pd.Series(key(tr)).value_counts()
    n = np.array([cnt.get(k, 0) for k in key(te)], dtype=float)
    lo = n < 30
    print(f"  支撑 n<30 占比 {lo.mean()*100:.1f}%   分层收缩 k:  " + "  ".join(
        f"{k} {rel(n/(n+k)*base + (1-n/(n+k))*wide):+.3f}%" for k in [5, 20, 50]))
    if lo.any():
        for k in [20]:
            w = n / (n + k)
            p = w * base + (1 - w) * wide
            rl = float(np.sqrt(((y[lo] - p[lo]) ** 2).mean()))
            bl = float(np.sqrt(((y[lo] - base[lo]) ** 2).mean()))
            print(f"    低支撑子集 (n<30)：基线 {bl:.3f} -> 收缩后 {rl:.3f} "
                  f"({(bl - rl) / bl * 100:+.2f}%)")


def main() -> None:
    df = apply_baseline_floor(pd.read_parquet("data/processed/_raw_recovered.parquet")).sort_values("ts").reset_index(drop=True)
    cut = int(len(df) * 0.8)
    run("time（原切分，跨太阳周期）", df.iloc[:cut], df.iloc[cut:].reset_index(drop=True))

    rng = np.random.default_rng(42)
    idx = rng.permutation(len(df))
    k = int(len(df) * 0.8)
    run("random（i.i.d.，无漂移）", df.iloc[idx[:k]], df.iloc[idx[k:]].reset_index(drop=True))

    d24 = df[pd.to_datetime(df["ts"], unit="s").dt.year == 2024].reset_index(drop=True)
    c24 = int(len(d24) * 0.8)
    run("time2024（同周期内外推）", d24.iloc[:c24], d24.iloc[c24:].reset_index(drop=True))


if __name__ == "__main__":
    main()
