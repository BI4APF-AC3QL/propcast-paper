"""复核生产模型的 L2 正则与验证集加性偏差校准。

固定使用生产的按来源切分与可信测试集；三个随机种子分别比较：
无 L2、L2=5、L2=5 + 仅由独立验证集估计的输出偏移。
脚本只读数据，不写模型产物与重训历史。
"""
from __future__ import annotations

import json

import lightgbm as lgb
import numpy as np

from models.features import FEATURE_NAMES
from models.hyperparams import EARLY_STOPPING_ROUNDS, LGBM_PARAMS
from models.retrain import _load_all, _metrics, split_by_source


def fit(seed: int, reg_lambda: float, tr, va):
    params = dict(LGBM_PARAMS, random_state=seed, reg_lambda=reg_lambda,
                  subsample=1.0)
    model = lgb.LGBMRegressor(**params)
    model.fit(
        tr[FEATURE_NAMES].to_numpy(), tr["residual"].to_numpy(),
        eval_set=[(va[FEATURE_NAMES].to_numpy(), va["residual"].to_numpy())],
        callbacks=[lgb.early_stopping(EARLY_STOPPING_ROUNDS, verbose=False)],
    )
    return model


def main() -> None:
    df = _load_all()
    tr, va, te = split_by_source(df, 0.5)
    va = va[va["trusted"]]
    te = te[te["trusted"]]
    Xte, yte = te[FEATURE_NAMES].to_numpy(), te["residual"].to_numpy()
    rows = []
    for seed in (42, 43, 44):
        base = fit(seed, 0.0, tr, va)
        l2 = fit(seed, 5.0, tr, va)
        p0 = base.predict(Xte)
        p1 = l2.predict(Xte)
        base_offset = float(np.mean(va["residual"].to_numpy()
                                    - base.predict(va[FEATURE_NAMES].to_numpy())))
        offset = float(np.mean(va["residual"].to_numpy()
                               - l2.predict(va[FEATURE_NAMES].to_numpy())))
        p0c = p0 + base_offset
        p2 = p1 + offset
        m0, m0c = _metrics(yte, p0), _metrics(yte, p0c)
        m1, m2 = _metrics(yte, p1), _metrics(yte, p2)
        rows.append({
            "seed": seed,
            "baseline_offset_db": base_offset,
            "offset_db": offset,
            "baseline": m0,
            "baseline_offset": m0c,
            "baseline_offset_gain_pct": (m0["rmse"] - m0c["rmse"]) / m0["rmse"] * 100,
            "l2": m1,
            "l2_gain_pct": (m0["rmse"] - m1["rmse"]) / m0["rmse"] * 100,
            "l2_offset": m2,
            "offset_gain_vs_l2_pct": (m1["rmse"] - m2["rmse"]) / m1["rmse"] * 100,
            "combined_gain_pct": (m0["rmse"] - m2["rmse"]) / m0["rmse"] * 100,
        })
    print(json.dumps({
        "n_total": len(df), "n_train": len(tr), "n_val": len(va),
        "n_test": len(te), "rows": rows,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
