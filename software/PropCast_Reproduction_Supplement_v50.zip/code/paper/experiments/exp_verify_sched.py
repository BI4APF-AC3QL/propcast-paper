"""验证按支撑度自动决定的混合权重 w(n)，端到端效果。

前一轮扫的是固定 w；实际要上线的是 w = max(W_MIN, n/(n+K))，n 由标定的距离直方图给出。
这里用同样的留一(年,月)CV，直接量这条曲线的净效果——避免"扫出最优 w 就宣布成功"
这种把超参搜索的收益当成真实收益的错误。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import lightgbm as lgb

from models.features import FEATURE_NAMES
from models.features import apply_baseline_floor

COARSE = ["distance_km", "freq_mhz", "voacap_snr", "freq_over_muf", "zenith_mid"]
EDGES = [0, 2000, 6000, 10000, 14000, 20100]
BIN = 500.0
SCHEDULES = [("K=200", 200.0, 0.5), ("K=300", 300.0, 0.5), ("K=600", 600.0, 0.5)]


def rmse(y, p):
    return float(np.sqrt(((y - p) ** 2).mean()))


def support(hist, km):
    i = int(max(0.0, km) // BIN)
    return sum(hist[j] for j in range(max(0, i - 1), min(len(hist), i + 2)))


def main() -> None:
    df = apply_baseline_floor(pd.read_parquet("data/processed/_raw_recovered.parquet"))
    df["year"] = pd.to_datetime(df["ts"], unit="s").dt.year
    groups = sorted(df.groupby(["year", "month"]).size().index.tolist())
    rng = np.random.default_rng(0)
    recs = []

    for yr, mo in groups:
        te = df[(df.year == yr) & (df.month == mo)]
        rest = df[~((df.year == yr) & (df.month == mo))]
        idx = rng.permutation(len(rest))
        nv = int(len(rest) * 0.1)
        va, tr = rest.iloc[idx[:nv]], rest.iloc[idx[nv:]]

        fine = lgb.LGBMRegressor(n_estimators=1500, learning_rate=0.05, num_leaves=63,
                                 subsample=0.9, colsample_bytree=0.9, random_state=42, verbose=-1)
        fine.fit(tr[FEATURE_NAMES].to_numpy(), tr["residual"].to_numpy(),
                 eval_set=[(va[FEATURE_NAMES].to_numpy(), va["residual"].to_numpy())],
                 callbacks=[lgb.early_stopping(50, verbose=False)])
        coarse = lgb.LGBMRegressor(n_estimators=400, learning_rate=0.05, num_leaves=4,
                                   max_depth=2, min_child_samples=200, subsample=0.8,
                                   colsample_bytree=0.8, random_state=42, verbose=-1)
        coarse.fit(tr[COARSE].to_numpy(), tr["residual"].to_numpy(),
                   eval_set=[(va[COARSE].to_numpy(), va["residual"].to_numpy())],
                   callbacks=[lgb.early_stopping(50, verbose=False)])

        # 直方图只能来自训练集（测试月不可见），与线上一致
        hist, _ = np.histogram(tr["distance_km"], bins=41, range=(0, 41 * BIN))
        hist = [int(v) for v in hist]

        y = te["residual"].to_numpy()
        pf = fine.predict(te[FEATURE_NAMES].to_numpy())
        pc = coarse.predict(te[COARSE].to_numpy())
        d = te["distance_km"].to_numpy()
        n_sup = np.array([support(hist, x) for x in d], dtype=float)

        for name, K, wmin in SCHEDULES:
            w = np.maximum(wmin, n_sup / (n_sup + K))
            p = w * pf + (1 - w) * pc
            for i in range(len(EDGES) - 1):
                m = (d >= EDGES[i]) & (d < EDGES[i + 1])
                if m.sum() < 30:
                    continue
                recs.append({"fold": f"{yr}-{mo:02d}", "sched": name,
                             "seg": f"{EDGES[i]//1000}-{EDGES[i+1]//1000}k", "n": int(m.sum()),
                             "fine": rmse(y[m], pf[m]), "blend": rmse(y[m], p[m]),
                             "w": float(w[m].mean())})
            recs.append({"fold": f"{yr}-{mo:02d}", "sched": name, "seg": "全部",
                         "n": len(y), "fine": rmse(y, pf), "blend": rmse(y, p),
                         "w": float(w.mean())})
        print(f"  {yr}-{mo:02d} 完成")

    r = pd.DataFrame(recs)
    for name, _, _ in SCHEDULES:
        s = r[r.sched == name]
        print(f"\n=== {name} ===")
        print(f"{'距离段':>8} {'平均w':>7} {'纯细模型':>9} {'混合':>9} {'改进':>8} {'赢的折数':>9}")
        for seg in [f"{EDGES[i]//1000}-{EDGES[i+1]//1000}k" for i in range(len(EDGES) - 1)] + ["全部"]:
            g = s[s.seg == seg]
            if g.empty:
                continue
            f_, b_ = g["fine"].mean(), g["blend"].mean()
            print(f"{seg:>8} {g['w'].mean():7.2f} {f_:9.2f} {b_:9.2f} "
                  f"{(f_ - b_) / f_ * 100:+7.2f}% {int((g['blend'] < g['fine']).sum()):5d}/{len(g)}")
    r.to_csv("data/processed/_exp_sched.csv", index=False)


if __name__ == "__main__":
    main()
