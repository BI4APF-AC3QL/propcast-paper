"""留一(年,月)交叉验证：平滑与收缩是否稳定有效。

前几轮的教训：
* 单一切分的结论方差极大（同一组参数在三种切分上分别 +5.1% / +2.0% / −10.2%），
  靠一个切分下结论必然是自欺。
* 新训模型必须有独立验证集做 early stopping。之前直接固定 600 棵树，
  基线 RMSE 12.16（在役产物是 10.59），是在一个过拟合的模型上量正则的收益，
  当然显得特别有效。

本轮协议：每次留出一个 (年,月) 作测试，其余按 90/10 再切出验证集供 early stopping。
只报各折相对增益的均值与标准差 —— 均值为正且明显大于标准差，才算真的有效。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import lightgbm as lgb

from models.features import FEATURE_NAMES, build_features
from models.features import apply_baseline_floor

RAWCOLS = ["distance_km", "tx_lat", "tx_lon", "rx_lat", "rx_lon", "hour_utc",
           "month", "freq_mhz", "ssn", "tx_power_dbm", "voacap_snr", "voacap_muf"]
DH = [-12.0, -8.0, -6.0, -4.0, -2.0, -1.0, 0.0, 1.0, 2.0, 4.0, 6.0, 8.0, 12.0]
DF = [-0.30, -0.15, 0.0, 0.15, 0.30]
SIG_H = [1.0, 2.0, 3.0, 4.0, 6.0]
SIG_F = [0.10, 0.20, 0.35]
KS = [5, 20, 50]


def rmse(y, p):
    return float(np.sqrt(((y - p) ** 2).mean()))


def kern(offsets, sig):
    w = np.array([np.exp(-0.5 * (o / sig) ** 2) for o in offsets])
    return w / w.sum()


def main() -> None:
    df = apply_baseline_floor(pd.read_parquet("data/processed/_raw_recovered.parquet"))
    df["year"] = pd.to_datetime(df["ts"], unit="s").dt.year
    groups = sorted(df.groupby(["year", "month"]).size().items(), key=lambda kv: kv[0])
    print("折（年,月 -> 样本数）:", {f"{y}-{m:02d}": n for (y, m), n in groups}, "\n")

    rng = np.random.default_rng(0)
    rows = []
    for (yr, mo), _ in groups:
        te = df[(df.year == yr) & (df.month == mo)]
        rest = df[~((df.year == yr) & (df.month == mo))]
        idx = rng.permutation(len(rest))
        nv = int(len(rest) * 0.1)
        va, tr = rest.iloc[idx[:nv]], rest.iloc[idx[nv:]]

        model = lgb.LGBMRegressor(n_estimators=1500, learning_rate=0.05, num_leaves=63,
                                  subsample=0.9, colsample_bytree=0.9,
                                  random_state=42, verbose=-1)
        model.fit(tr[FEATURE_NAMES].to_numpy(), tr["residual"].to_numpy(),
                  eval_set=[(va[FEATURE_NAMES].to_numpy(), va["residual"].to_numpy())],
                  callbacks=[lgb.early_stopping(50, verbose=False)])

        y = te["residual"].to_numpy()
        base = model.predict(te[FEATURE_NAMES].to_numpy())
        b0 = rmse(y, base)
        raws = te[RAWCOLS].to_dict("records")

        ph = np.array([model.predict(np.array(
            [build_features({**r, "hour_utc": (r["hour_utc"] + d) % 24.0}) for r in raws]))
            for d in DH])
        pf = np.array([model.predict(np.array(
            [build_features({**r, "freq_mhz": r["freq_mhz"] * (1 + a),
                             "voacap_muf": r["voacap_muf"] * (1 + a)}) for r in raws]))
            for a in DF])

        rec = {"fold": f"{yr}-{mo:02d}", "n": len(te), "base": b0,
               "trees": model.best_iteration_}
        for s in SIG_H:
            rec[f"h{s}"] = (b0 - rmse(y, kern(DH, s) @ ph)) / b0 * 100
        for s in SIG_F:
            rec[f"f{s}"] = (b0 - rmse(y, kern(DF, s) @ pf)) / b0 * 100

        wide = kern(DH, 12.0) @ ph
        key = lambda d: list(zip(d["band"], (d["hour_utc"].round().astype(int) % 24),
                                 (d["distance_km"] // 2000).astype(int)))
        cnt = pd.Series(key(tr)).value_counts()
        n = np.array([cnt.get(k, 0) for k in key(te)], dtype=float)
        lo = n < 30
        rec["lo%"] = lo.mean() * 100
        for k in KS:
            w = n / (n + k)
            rec[f"k{k}"] = (b0 - rmse(y, w * base + (1 - w) * wide)) / b0 * 100
        if lo.any():
            w = n / (n + 20)
            p = w * base + (1 - w) * wide
            rec["lo_gain"] = (rmse(y[lo], base[lo]) - rmse(y[lo], p[lo])) / rmse(y[lo], base[lo]) * 100
        rows.append(rec)
        print(f"  {rec['fold']} 完成  n={len(te)}  base={b0:.3f}  trees={rec['trees']}")

    r = pd.DataFrame(rows)
    print("\n各折基线 RMSE:", " ".join(f"{v:.2f}" for v in r["base"]))
    print(f"低支撑(n<30)样本占比 均值 {r['lo%'].mean():.1f}%\n")
    print(f"{'参数':>10} {'均值Δ%':>9} {'标准差':>8} {'为正的折数':>10}")
    for c in [f"h{s}" for s in SIG_H] + [f"f{s}" for s in SIG_F] + [f"k{k}" for k in KS]:
        v = r[c]
        print(f"{c:>10} {v.mean():+9.3f} {v.std():8.3f} {int((v > 0).sum()):>7}/{len(v)}")
    if "lo_gain" in r:
        v = r["lo_gain"].dropna()
        print(f"{'低支撑子集(k=20)':>10} {v.mean():+9.3f} {v.std():8.3f} {int((v > 0).sum()):>7}/{len(v)}")
    r.to_csv("data/processed/_exp_cv.csv", index=False)


if __name__ == "__main__":
    main()
