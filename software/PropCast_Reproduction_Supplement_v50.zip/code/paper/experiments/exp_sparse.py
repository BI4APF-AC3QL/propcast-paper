"""受控稀疏实验：样本变少时，该把权重让给谁？

问题：交叉验证测不出「稀疏区表现」——因为测试集里稀疏区的样本同样稀少，
信号淹没在噪声里。解法是**人为制造稀疏**：把某个距离段的训练样本抽稀到 0.5%…100%，
测试集固定不变，看各种回退策略在该段上的表现如何随样本量变化。

四个候选（delta = 实测SNR − VOACAP 的回归目标）：
  voacap    delta = 0                      —— 完全信物理（用户提议的字面版本）
  fine      现有 19 特征 LightGBM           —— 完全信数据
  coarse    低容量模型（5 特征/深度2）        —— 少量样本即可可靠估计
  blend     w·fine + (1−w)·coarse           —— 按样本量在两者间过渡

同时给出「最优 w 随样本量如何变化」，用来标定 w = n/(n+k) 里的 k。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import lightgbm as lgb

from models.features import FEATURE_NAMES
from models.features import apply_baseline_floor

# 低容量模型只用「少量样本就能可靠估计」的维度：路径长度、频率、物理基线本身
COARSE_FEATURES = ["distance_km", "freq_mhz", "voacap_snr", "freq_over_muf", "zenith_mid"]
BAND = (14000.0, 20100.0)          # 距离范围边缘：只能单侧外推，VOACAP 偏差在此变号
FRACTIONS = [0.005, 0.02, 0.05, 0.2, 0.5, 1.0]
WS = [0.0, 0.25, 0.5, 0.75, 1.0]


def rmse(y, p):
    return float(np.sqrt(((y - p) ** 2).mean()))


def fit_fine(tr):
    m = lgb.LGBMRegressor(n_estimators=1500, learning_rate=0.05, num_leaves=63,
                          subsample=0.9, colsample_bytree=0.9, random_state=42, verbose=-1)
    m.fit(tr[FEATURE_NAMES].to_numpy(), tr["residual"].to_numpy())
    return m


def fit_coarse(tr):
    """刻意压低容量：深度 2、叶子 4、强正则。它学不到细结构，也就不会在稀疏区乱来。"""
    m = lgb.LGBMRegressor(n_estimators=200, learning_rate=0.05, num_leaves=4, max_depth=2,
                          min_child_samples=200, subsample=0.8, colsample_bytree=0.8,
                          random_state=42, verbose=-1)
    m.fit(tr[COARSE_FEATURES].to_numpy(), tr["residual"].to_numpy())
    return m


def main() -> None:
    df = apply_baseline_floor(pd.read_parquet("data/processed/_raw_recovered.parquet"))
    rng = np.random.default_rng(7)

    in_band = (df.distance_km >= BAND[0]) & (df.distance_km < BAND[1])
    band = df[in_band].reset_index(drop=True)
    other = df[~in_band]
    idx = rng.permutation(len(band))
    n_te = int(len(band) * 0.25)
    te = band.iloc[idx[:n_te]].reset_index(drop=True)
    pool = band.iloc[idx[n_te:]].reset_index(drop=True)
    y = te["residual"].to_numpy()
    print(f"目标段 {BAND[0]:.0f}–{BAND[1]:.0f} km：共 {len(band)} 条，"
          f"测试固定 {len(te)} 条，可抽稀训练池 {len(pool)} 条")
    print(f"段外训练样本 {len(other)} 条（始终全量保留）\n")
    print(f"{'该段样本n':>9} {'VOACAP':>8} {'fine':>8} {'coarse':>8} "
          + " ".join(f"{'w=' + str(w):>8}" for w in WS) + f" {'最优w':>7}")

    for f in FRACTIONS:
        k = max(1, int(len(pool) * f))
        tr = pd.concat([other, pool.iloc[:k]], ignore_index=True)
        fine, coarse = fit_fine(tr), fit_coarse(tr)
        pf = fine.predict(te[FEATURE_NAMES].to_numpy())
        pc = coarse.predict(te[COARSE_FEATURES].to_numpy())
        vals = [rmse(y, w * pf + (1 - w) * pc) for w in WS]
        # 细扫最优 w
        grid = np.linspace(0, 1, 41)
        best = grid[int(np.argmin([rmse(y, w * pf + (1 - w) * pc) for w in grid]))]
        print(f"{k:9d} {rmse(y, np.zeros_like(y)):8.2f} {rmse(y, pf):8.2f} {rmse(y, pc):8.2f} "
              + " ".join(f"{v:8.2f}" for v in vals) + f" {best:7.2f}")


if __name__ == "__main__":
    main()
