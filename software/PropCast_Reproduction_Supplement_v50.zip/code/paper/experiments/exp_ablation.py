"""第 7 章材料：特征组消融 + v2 扩展特征的重新检验（均在 12 折留一(年,月)CV 下）。

为什么要重做 v2 实验：当初判定「6 个物理动机的新特征使 RMSE 劣化 0.54%」用的是
单一时间切分，而第 7 章正要论证单一切分不可靠。用不可靠的协议得出的负面结论，
不能直接写进论文——必须在 CV 下重新检验，哪怕结论因此反转。

消融方式：整组置零而非删列，保证各配置的特征维度一致、超参可比。
"""
from __future__ import annotations

import math

import lightgbm as lgb
import numpy as np
import pandas as pd

from models.features import FEATURE_NAMES, apply_baseline_floor

RAW = "data/processed/_raw_recovered.parquet"

# 特征分组（消融时整组置零）
GROUPS = {
    "几何": ["distance_km", "mid_lat", "mid_lon", "abs_mid_lat", "tx_lat", "rx_lat"],
    "时刻": ["sin_hour", "cos_hour"],
    "季节": ["sin_month", "cos_month"],
    "频率": ["freq_mhz"],
    "太阳活动": ["ssn"],
    "发射功率": ["tx_power_dbm"],
    "VOACAP基线": ["voacap_snr", "voacap_muf", "freq_over_muf"],
    "日照几何": ["zenith_mid", "zenith_tx", "zenith_rx"],
}


def v2_extra(df: pd.DataFrame) -> np.ndarray:
    """当初被判定为"劣化"的 6 个扩展特征，全部可由现有列推出。"""
    z = df[["zenith_mid", "zenith_tx", "zenith_rx"]].to_numpy()
    muf = np.maximum(df["voacap_muf"].to_numpy(), 1e-6)
    return np.column_stack([
        np.maximum(np.abs(df["tx_lat"]), np.abs(df["rx_lat"])),      # 路径最高纬度（极区吸收）
        df["distance_km"].to_numpy() / 4000.0,                        # 估计跳数
        np.log(np.maximum(df["freq_mhz"].to_numpy() / muf, 1e-6)),    # log(f/MUF)
        (z < 90).mean(axis=1),                                        # 白昼比例（D 层吸收）
        np.abs(z[:, 0] - 90.0),                                       # 距晨昏线远近（灰线增强）
        z.max(axis=1) - z.min(axis=1),                                # 天顶角跨度
    ])


def rmse(y, p):
    return float(np.sqrt(((y - p) ** 2).mean()))


def fit_eval(Xtr, ytr, Xva, yva, Xte, yte):
    m = lgb.LGBMRegressor(n_estimators=1500, learning_rate=0.05, num_leaves=63,
                          subsample=0.9, colsample_bytree=0.9, random_state=42, verbose=-1)
    m.fit(Xtr, ytr, eval_set=[(Xva, yva)],
          callbacks=[lgb.early_stopping(50, verbose=False)])
    return rmse(yte, m.predict(Xte)), m


def main() -> None:
    df = apply_baseline_floor(pd.read_parquet(RAW))
    df["year"] = pd.to_datetime(df["ts"], unit="s").dt.year
    groups = sorted(df.groupby(["year", "month"]).size().index.tolist())
    rng = np.random.default_rng(0)
    X_all = df[FEATURE_NAMES].to_numpy()
    X_v2 = np.hstack([X_all, v2_extra(df)])
    y_all = df["residual"].to_numpy()
    idx_of = {n: i for i, n in enumerate(FEATURE_NAMES)}

    recs = []
    for yr, mo in groups:
        te_m = ((df.year == yr) & (df.month == mo)).to_numpy()
        rest = np.where(~te_m)[0]
        perm = rng.permutation(len(rest))
        nv = int(len(rest) * 0.1)
        va_i, tr_i = rest[perm[:nv]], rest[perm[nv:]]
        te_i = np.where(te_m)[0]
        yte = y_all[te_i]

        base, model = fit_eval(X_all[tr_i], y_all[tr_i], X_all[va_i], y_all[va_i],
                               X_all[te_i], yte)
        row = {"fold": f"{yr}-{mo:02d}", "n": len(te_i),
               "voacap": rmse(yte, np.zeros_like(yte)), "完整": base}

        # v2 扩展特征
        row["v2扩展"] = fit_eval(X_v2[tr_i], y_all[tr_i], X_v2[va_i], y_all[va_i],
                               X_v2[te_i], yte)[0]

        # 特征组消融：整组置零
        for gname, cols in GROUPS.items():
            Xz = X_all.copy()
            for c in cols:
                Xz[:, idx_of[c]] = 0.0
            row[f"去{gname}"] = fit_eval(Xz[tr_i], y_all[tr_i], Xz[va_i], y_all[va_i],
                                        Xz[te_i], yte)[0]

        if not recs:  # 只在第一折取一次特征重要性
            imp = pd.Series(model.feature_importances_, index=FEATURE_NAMES)
            imp.sort_values(ascending=False).to_csv("data/processed/_exp_importance.csv")
        recs.append(row)
        print(f"  {row['fold']} 完成  完整={base:.3f}  v2={row['v2扩展']:.3f}")

    r = pd.DataFrame(recs)
    r.to_csv("data/processed/_exp_ablation.csv", index=False)

    print(f"\n各折基线 RMSE：{' '.join(f'{v:.2f}' for v in r['完整'])}")
    print(f"折间极差 {r['完整'].max() - r['完整'].min():.2f} dB "
          f"（{r['完整'].min():.2f} .. {r['完整'].max():.2f}）\n")
    print(f"{'配置':>12} {'RMSE均值':>9} {'相对完整':>9} {'标准差':>8} {'变差的折数':>10}")
    b = r["完整"]
    print(f"{'完整模型':>12} {b.mean():9.3f} {'—':>9} {'—':>8} {'—':>10}")
    print(f"{'VOACAP':>12} {r['voacap'].mean():9.3f} "
          f"{(r['voacap'].mean() - b.mean()) / b.mean() * 100:+8.1f}% {'—':>8} {'—':>10}")
    for c in ["v2扩展"] + [f"去{g}" for g in GROUPS]:
        d = (r[c] - b) / b * 100
        print(f"{c:>12} {r[c].mean():9.3f} {d.mean():+8.2f}% {d.std():8.2f} "
              f"{int((r[c] > b).sum()):>7}/{len(r)}")


if __name__ == "__main__":
    main()
