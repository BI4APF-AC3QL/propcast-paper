"""在 12 折 CV 下重新检验第 5.3.2 节的「频率扰动必须同步缩放 MUF」。

该结论原先只在单一切分上验证过（不同步 -0.49% / 同步 +0.21%）。既然第 7 章正要
论证单一切分不可靠，这条也必须重测。物理机理（校正量对 f/MUF 敏感）与具体数值
是两回事，前者成立不代表后者可信。
"""
from __future__ import annotations

import lightgbm as lgb
import numpy as np
import pandas as pd

from models.features import FEATURE_NAMES, build_features
from models.features import apply_baseline_floor

RAWCOLS = ["distance_km", "tx_lat", "tx_lon", "rx_lat", "rx_lon", "hour_utc",
           "month", "freq_mhz", "ssn", "tx_power_dbm", "voacap_snr", "voacap_muf"]
DF = [-0.30, -0.15, 0.0, 0.15, 0.30]
SIGMAS = [0.10, 0.20, 0.35]


def rmse(y, p):
    return float(np.sqrt(((y - p) ** 2).mean()))


def main() -> None:
    df = apply_baseline_floor(pd.read_parquet("data/processed/_raw_recovered.parquet"))
    df["year"] = pd.to_datetime(df["ts"], unit="s").dt.year
    groups = sorted(df.groupby(["year", "month"]).size().index.tolist())
    rng = np.random.default_rng(0)
    recs = []

    for yr, mo in groups:
        te = df[(df.year == yr) & (df.month == mo)]
        rest = df[~((df.year == yr) & (df.month == mo))]
        idx = rng.permutation(len(rest))
        nv = int(len(rest) * 0.1)
        va, tr = rest.iloc[idx[:nv]], rest.iloc[idx[nv:]]

        m = lgb.LGBMRegressor(n_estimators=1500, learning_rate=0.05, num_leaves=63,
                              subsample=0.9, colsample_bytree=0.9, random_state=42, verbose=-1)
        m.fit(tr[FEATURE_NAMES].to_numpy(), tr["residual"].to_numpy(),
              eval_set=[(va[FEATURE_NAMES].to_numpy(), va["residual"].to_numpy())],
              callbacks=[lgb.early_stopping(50, verbose=False)])

        y = te["residual"].to_numpy()
        base = rmse(y, m.predict(te[FEATURE_NAMES].to_numpy()))
        raws = te[RAWCOLS].to_dict("records")

        # 两种扰动方式：同步缩放 MUF（保持 f/MUF）vs 只动频率
        p_sync, p_free = {}, {}
        for a in DF:
            p_sync[a] = m.predict(np.array([build_features({
                **r, "freq_mhz": r["freq_mhz"] * (1 + a),
                "voacap_muf": r["voacap_muf"] * (1 + a)}) for r in raws]))
            p_free[a] = m.predict(np.array([build_features({
                **r, "freq_mhz": r["freq_mhz"] * (1 + a)}) for r in raws]))

        row = {"fold": f"{yr}-{mo:02d}", "base": base}
        for s in SIGMAS:
            w = {a: np.exp(-0.5 * (a / s) ** 2) for a in DF}
            tot = sum(w.values())
            row[f"同步{s}"] = (base - rmse(y, sum(w[a] * p_sync[a] for a in DF) / tot)) / base * 100
            row[f"不同步{s}"] = (base - rmse(y, sum(w[a] * p_free[a] for a in DF) / tot)) / base * 100
        recs.append(row)
        print(f"  {row['fold']} 完成")

    r = pd.DataFrame(recs)
    r.to_csv("data/processed/_exp_muf_sync.csv", index=False)
    print(f"\n{'配置':>12} {'均值Δ%':>9} {'标准差':>8} {'改善折数':>9} {'配对t':>8}")
    from scipy import stats
    for s in SIGMAS:
        for tag in ("同步", "不同步"):
            v = r[f"{tag}{s}"]
            t, p = stats.ttest_1samp(v, 0.0)
            print(f"{tag + str(s):>12} {v.mean():+9.3f} {v.std():8.3f} "
                  f"{int((v > 0).sum()):>6}/{len(v)} {t:+7.2f} (p={p:.3f})")
    print("\n同步 vs 不同步 的配对检验：")
    for s in SIGMAS:
        d = r[f"同步{s}"] - r[f"不同步{s}"]
        t, p = stats.ttest_rel(r[f"同步{s}"], r[f"不同步{s}"])
        print(f"  σ_f={s}: 同步优于不同步 {d.mean():+.3f}±{d.std():.3f} 个百分点，"
              f"{int((d > 0).sum())}/{len(d)} 折，t={t:+.2f} p={p:.4f}")


if __name__ == "__main__":
    main()
