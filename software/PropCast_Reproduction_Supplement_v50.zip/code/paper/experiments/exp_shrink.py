"""向物理基线全局收缩的代价（第 7.3.2 节）。

第 5.4 节论证了"稀疏区退回纯物理模型"是错的。本脚本量化其最极端的形式：
对 ML 校正量作全局收缩

    r'(x) = m + a · (r(x) − m),      m = 该折校正量的均值

a = 1 为不收缩，a = 0 为把校正量压成常数 m（此时输出等价于"VOACAP + 一个固定
偏置"，即彻底放弃逐链路校正）。收缩到均值而非零，是为了把"丢弃个体校正"与
"丢弃整体偏置修正"两件事分开——后者的代价大到没有讨论价值（见表 4-2 的
−22.18 dB 偏差），前者才是"稀疏区该不该更信物理模型"的真正问题。

协议与 exp_cv.py 一致：留一 (年, 月) 交叉验证，每折从其余数据另切 10 % 作
早停验证集。报告各折相对变化的均值与标准差（口径见论文表 5-4 的说明）。

    python paper/experiments/exp_shrink.py   # -> data/processed/_exp_shrink.csv
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import lightgbm as lgb

from models.features import FEATURE_NAMES
from models.features import apply_baseline_floor
from models.hyperparams import LGBM_PARAMS, EARLY_STOPPING_ROUNDS

ALPHAS = [0.95, 0.90, 0.75, 0.50, 0.25, 0.0]
OUT = "data/processed/_exp_shrink.csv"


def rmse(y, p) -> float:
    return float(np.sqrt(((y - p) ** 2).mean()))


def main() -> None:
    df = apply_baseline_floor(pd.read_parquet("data/processed/_raw_recovered.parquet"))
    df["year"] = pd.to_datetime(df["ts"], unit="s").dt.year
    groups = sorted(df.groupby(["year", "month"]).size().items(), key=lambda kv: kv[0])

    rng = np.random.default_rng(0)
    rows = []
    for (yr, mo), _ in groups:
        te = df[(df.year == yr) & (df.month == mo)]
        rest = df[~((df.year == yr) & (df.month == mo))]
        idx = rng.permutation(len(rest))
        nv = int(len(rest) * 0.1)
        va, tr = rest.iloc[idx[:nv]], rest.iloc[idx[nv:]]

        model = lgb.LGBMRegressor(**LGBM_PARAMS)
        model.fit(tr[FEATURE_NAMES].to_numpy(), tr["residual"].to_numpy(),
                  eval_set=[(va[FEATURE_NAMES].to_numpy(), va["residual"].to_numpy())],
                  callbacks=[lgb.early_stopping(EARLY_STOPPING_ROUNDS, verbose=False)])

        y = te["residual"].to_numpy()
        r = model.predict(te[FEATURE_NAMES].to_numpy())
        m = float(r.mean())
        b0 = rmse(y, r)

        rec = {"fold": f"{yr}-{mo:02d}", "n": len(te), "base": b0,
               "trees": model.best_iteration_}
        for a in ALPHAS:
            # 正值 = 劣化百分比，与 7.3.2 节的表述方向一致
            rec[f"a{a}"] = (rmse(y, m + a * (r - m)) - b0) / b0 * 100
        rows.append(rec)
        print(f"  {rec['fold']} 完成  n={len(te)}  base={b0:.3f}  trees={rec['trees']}")

    res = pd.DataFrame(rows)
    res.to_csv(OUT, index=False)
    print(f"\n已写入 {OUT}\n")
    print(f"{'a':>6s}{'劣化均值':>12s}{'标准差':>10s}{'劣化折数':>10s}")
    for a in ALPHAS:
        c = res[f"a{a}"]
        print(f"{a:6.2f}{c.mean():11.2f}%{c.std(ddof=1):10.2f}{(c > 0).sum():8d}/12")


if __name__ == "__main__":
    main()
