"""众包数据到底有没有让模型变好？（多折受控验证）

背景
----
生产重训按 `cut = int(len(df) * 0.8)` 在时间排序的全表上切分。历史 WSPR 是开头
一整块 93 500 条，切分点落在它内部，于是**训练集 100% 是历史数据、可信测试集 93%
是新采集的 FT8**——候选模型从未见过新数据却被拿新数据评判。实测 54 次重训中候选
一律更差，且差距随数据量扩大（r=+0.425，+0.097 pp/千条），与该结构完全吻合。

单次改用「按来源分层 80/20」后候选反超 0.26%。但论文第 7.1 节的结论正是：单一切分
可能给出**符号相反**的结果。因此本脚本按多折协议重做，避免据单次结果下判断。

协议
----
新观测只跨约两天，无法套用留一 (年,月)。改为把新观测按**时间**切成 K 块（时间块而
非随机块：同一对电台相隔数分钟的近重复样本会让随机划分泄漏，且时间块更贴近部署）。

对每一折 k：
    测试集   = 新观测的第 k 块（仅可信样本）
    基线模型 = 只用历史数据训练
    增强模型 = 历史数据 + 除第 k 块以外的全部新观测
两者共用**同一个固定的早停验证集**（从历史数据尾部切出，且不参与任何训练），
使唯一变量就是"训练时有没有新数据"。

同时在一份**始终排除在训练之外**的历史留出集上评估两者，检查加入新数据是否
损害了原有分布上的表现。

    python paper/experiments/exp_crowd_gain.py     # -> data/processed/_exp_crowd.csv
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import lightgbm as lgb
from scipy import stats

from models.features import FEATURE_NAMES
from models.hyperparams import LGBM_PARAMS, EARLY_STOPPING_ROUNDS
from models.retrain import _load_all, _reject_outliers

K = 6
HIST_SOURCE = "wspr-historical"
OUT = "data/processed/_exp_crowd.csv"


def rmse(y, p) -> float:
    return float(np.sqrt(((y - p) ** 2).mean()))


def fit(train: pd.DataFrame, val: pd.DataFrame) -> lgb.LGBMRegressor:
    m = lgb.LGBMRegressor(**LGBM_PARAMS)
    m.fit(train[FEATURE_NAMES].to_numpy(), train["residual"].to_numpy(),
          eval_set=[(val[FEATURE_NAMES].to_numpy(), val["residual"].to_numpy())],
          callbacks=[lgb.early_stopping(EARLY_STOPPING_ROUNDS, verbose=False)])
    return m


def main() -> None:
    df, dropped = _reject_outliers(_load_all())
    hist = df[df["source"] == HIST_SOURCE].sort_values("ts").reset_index(drop=True)
    new = df[df["source"] != HIST_SOURCE].sort_values("ts").reset_index(drop=True)
    print(f"历史 {len(hist)} 条，新观测 {len(new)} 条（剔除离群 {dropped} 条）")
    if len(new) < K * 200:
        raise SystemExit(f"新观测不足以切 {K} 折（每折至少 200 条）")

    # 历史留出集：始终不参与训练，用来检查加入新数据是否损害原分布
    h_hold = int(len(hist) * 0.90)
    hist_hold = hist.iloc[h_hold:]
    rest = hist.iloc[:h_hold]
    # 固定早停验证集：两个模型共用，且不参与任何训练
    v_cut = int(len(rest) * 0.95)
    hist_train, val = rest.iloc[:v_cut], rest.iloc[v_cut:]
    print(f"历史拆分：训练 {len(hist_train)} / 早停验证 {len(val)} / 留出 {len(hist_hold)}")

    new_t = new[new["trusted"]].reset_index(drop=True)
    blocks = np.array_split(np.arange(len(new_t)), K)
    print(f"新观测按时间切 {K} 折，各折 {[len(b) for b in blocks]} 条"
          f"（其中可信 {len(new_t)} 条）\n")

    Xh, yh = hist_hold[FEATURE_NAMES].to_numpy(), hist_hold["residual"].to_numpy()
    rows = []
    for k, blk in enumerate(blocks):
        te = new_t.iloc[blk]
        keep = new_t.drop(new_t.index[blk])
        # 未参与评判的用户上报也进训练（与生产一致：训练用全部、评判只用可信）
        aug_extra = pd.concat([keep, new[~new["trusted"]]], ignore_index=True)
        base_tr = hist_train
        aug_tr = pd.concat([hist_train, aug_extra], ignore_index=True).sort_values("ts")

        mb, ma = fit(base_tr, val), fit(aug_tr, val)
        X, y = te[FEATURE_NAMES].to_numpy(), te["residual"].to_numpy()
        b_new, a_new = rmse(y, mb.predict(X)), rmse(y, ma.predict(X))
        b_h, a_h = rmse(yh, mb.predict(Xh)), rmse(yh, ma.predict(Xh))
        rows.append({
            "fold": k, "n_test": len(te), "n_aug_extra": len(aug_extra),
            "base_new": b_new, "aug_new": a_new,
            "gain_new_pct": (b_new - a_new) / b_new * 100,
            "base_hist": b_h, "aug_hist": a_h,
            "gain_hist_pct": (b_h - a_h) / b_h * 100,
            "trees_base": mb.best_iteration_, "trees_aug": ma.best_iteration_,
        })
        r = rows[-1]
        print(f"  折{k}  新数据上 {b_new:7.3f} -> {a_new:7.3f} ({r['gain_new_pct']:+6.2f} %)"
              f"   历史留出 {b_h:6.3f} -> {a_h:6.3f} ({r['gain_hist_pct']:+6.2f} %)")

    res = pd.DataFrame(rows)
    res.to_csv(OUT, index=False)
    print(f"\n已写入 {OUT}\n")

    for label, col, a, b in (("新观测（众包分布）", "gain_new_pct", "aug_new", "base_new"),
                             ("历史留出集", "gain_hist_pct", "aug_hist", "base_hist")):
        g = res[col]
        t = stats.ttest_rel(res[a], res[b])
        try:
            w = stats.wilcoxon(res[a], res[b]).pvalue
        except ValueError:
            w = float("nan")
        print(f"=== {label} ===")
        print(f"  加入新数据后的相对增益：{g.mean():+.2f} % ± {g.std(ddof=1):.2f}"
              f"   改善 {(g > 0).sum()}/{K} 折")
        print(f"  配对 t 检验 p={t.pvalue:.4f}   Wilcoxon p={w:.4f}")
        # 方向要分开判：只看 (g>0) 会把「显著变差」误报成「证据不足」
        consistent = max((g > 0).sum(), (g < 0).sum()) >= K - 1
        if t.pvalue < 0.05 and consistent:
            print(f"  结论：{'增益' if g.mean() > 0 else '劣化'}显著\n")
        else:
            print("  结论：证据不足以判定\n")

    print("说明：早停验证集固定取自历史数据，两模型共用。这对增强模型略有不利"
          "（选轮数的依据里没有新数据分布），因此上面的增益是保守估计。")


if __name__ == "__main__":
    main()
