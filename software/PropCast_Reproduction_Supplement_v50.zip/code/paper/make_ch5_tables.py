"""生成第 5 章的表 5-1 与表 5-8（抖动与训练支撑）。

为什么要有这个脚本：这两张表原先用**线上标定文件**计算训练支撑，而该文件随持续采集
每轮重训更新，于是论文的核心数字会随系统运行漂移（实测北京→东京的支撑由 25 901
变为 27 926）。第 5 章的全部实验本就在固定的历史数据集上完成，支撑理应据此计算。

本脚本用 `dataset_multiyear.parquet`（93 500 条，固定）构造一份**仅含历史数据**的
标定，据此计算各参考路径的支撑、平滑核宽与主模型权重，并测量三种配置下的评分抖动。
结果与表 5-2 的距离分布同源，彼此可对照。

    python paper/make_ch5_tables.py          # 打印 Markdown 表
    python paper/make_ch5_tables.py --write  # 写回 ch5 的标记块
"""
from __future__ import annotations

import argparse
import math
import re
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "backend"))

from models import calibration as cal  # noqa: E402
from models.base import GeoLocation, PredictRequest  # noqa: E402
from models.features import apply_baseline_floor
from models.features import build_features  # noqa: E402
from models.geo import great_circle_km  # noqa: E402
from models.hybrid_model import HybridModel, _snr_to_reliability  # noqa: E402
from models.voacap_model import VoacapModel, _reliability_to_score  # noqa: E402

CH5 = Path(__file__).parent / "ch5_稀疏观测下的稳健性.md"
T1_BEGIN, T1_END = "<!-- TABLE5-1:BEGIN -->", "<!-- TABLE5-1:END -->"
T7_BEGIN, T7_END = "<!-- TABLE5-8:BEGIN -->", "<!-- TABLE5-8:END -->"

TX = (39.9, 116.4)
PATHS = [("东京", 35.7, 139.7), ("悉尼", -33.9, 151.2), ("伦敦", 51.5, -0.1),
         ("纽约", 40.7, -74.0), ("圣保罗", -23.5, -46.6)]
BANDS = ["80m", "40m", "30m", "20m", "17m", "15m", "10m"]
MONTH, SSN, PW = 8, 78.0, 100.0
SCORE_THRESHOLD = 10


def historical_calibration() -> tuple[dict, int, float]:
    """仅由历史训练集构造标定（不含持续采集的观测），保证数字不随系统运行漂移。

    必须一并给出 `incumbent_rmse`：可靠度尺度 σ_R = RMSE/1.7 由它决定，缺了会
    静默退回产物里的旧尺度（4.29 dB），"完整方法"就丢掉了 5.5 节那项改进。
    此处取 eval.json 中在**历史单一时间留出集**上的实测 RMSE——与生产代码
    (retrain.py) 计算 incumbent_rmse 的口径相同，只是冻结在固定数据集上。
    """
    import json

    hist = apply_baseline_floor(pd.read_parquet(ROOT / "data/processed/dataset_multiyear.parquet"))
    counts, _ = np.histogram(hist["distance_km"], bins=cal.N_DIST_BINS,
                             range=(0.0, cal.N_DIST_BINS * cal.DIST_BIN_KM))
    rmse = json.load(open(ROOT / "data/processed/eval.json", encoding="utf-8"))["hybrid"]["rmse"]
    return ({"dist_bin_km": cal.DIST_BIN_KM,
             "distance_hist": [int(v) for v in counts],
             "incumbent_rmse": rmse}, len(hist), rmse)


def _req(la: float, lo: float) -> PredictRequest:
    return PredictRequest(tx=GeoLocation(lat=TX[0], lon=TX[1]),
                          rx=GeoLocation(lat=la, lon=lo), bands=BANDS,
                          hours_utc=list(range(24)), month=MONTH, ssn=SSN, tx_power_w=PW)


def _grid(cells, key="score") -> np.ndarray:
    m = {(c.band, c.hour_utc): getattr(c, key) for c in cells}
    return np.array([[m[(b, h)] for h in range(24)] for b in BANDS])


def jitter(ref: np.ndarray, g: np.ndarray) -> float:
    """可读单元上相邻小时评分差的平均绝对值；无可读单元时返回 nan。"""
    m = (ref > SCORE_THRESHOLD) | (g > SCORE_THRESHOLD)
    mm = m[:, 1:] & m[:, :-1]
    return float(np.abs(np.diff(g, axis=1))[mm].mean()) if mm.sum() else float("nan")


def unregularized(hyb: HybridModel, la: float, lo: float, scale: float) -> np.ndarray:
    """未加任何正则的原始混合模型：单点预测 + 旧的可靠度尺度。"""
    base = hyb._baseline.predict(_req(la, lo))
    art = hyb._corrector
    dist = great_circle_km(TX[0], TX[1], la, lo)
    p_dbm = 10.0 * math.log10(PW) + 30.0
    X = [build_features({
        "distance_km": dist, "tx_lat": TX[0], "tx_lon": TX[1], "rx_lat": la, "rx_lon": lo,
        "hour_utc": float(c.hour_utc), "month": MONTH, "freq_mhz": c.freq_mhz,
        "ssn": SSN, "tx_power_dbm": p_dbm,
        "voacap_snr": c.snr_db, "voacap_muf": c.muf_mhz}) for c in base.cells]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = art["model"].predict(np.asarray(X, dtype=float))
    center = art.get("snr_center", -13.0)
    m = {}
    for c, dd in zip(base.cells, d):
        s = c.snr_db + float(dd)
        m[(c.band, c.hour_utc)] = _reliability_to_score(
            _snr_to_reliability(s, center, scale), s)
    return np.array([[m[(b, h)] for h in range(24)] for b in BANDS])


def collect() -> tuple[list[dict], int, float, float]:
    calib, n_hist, rmse = historical_calibration()
    voa = VoacapModel()
    hyb = HybridModel()
    old_scale = max(2.0, hyb._corrector.get("snr_scale", 8.0))
    # 用历史标定覆盖线上标定，使自适应参数由固定数据集决定
    hyb._calib = calib

    rows = []
    for name, la, lo in PATHS:
        km = great_circle_km(TX[0], TX[1], la, lo)
        n = cal.support_at(calib, km)
        sigma_h, _ = cal.bandwidth(n)
        w = cal.blend_weight(n)
        sv = _grid(voa.predict(_req(la, lo)).cells)
        s0 = unregularized(hyb, la, lo, old_scale)
        s1 = _grid(hyb.predict(_req(la, lo)).cells)
        rows.append({
            "name": name, "km": km, "n": n, "share": n / n_hist * 100,
            "sigma_h": sigma_h, "w": w,
            "voacap": jitter(sv, sv), "raw": jitter(sv, s0), "full": jitter(sv, s1),
        })
    return rows, n_hist, old_scale, rmse


def render_t1(rows: list[dict]) -> str:
    body = "\n".join(
        f"| 北京→{r['name']} | {r['km']:,.0f} | {r['n']:,} | {r['share']:.1f} % | "
        + (f"{r['voacap']:.2f}" if not math.isnan(r["voacap"]) else "—（全闭合）")
        + f" | {r['raw']:.2f} |" for r in rows).replace(",", " ")
    return f"""{T1_BEGIN}
**表 5-1 评分抖动与训练支撑的关系**

| 路径 | 距离 (km) | 该距离档训练样本 | 占训练集 | VOACAP | 混合模型 |
|---|---|---|---|---|---|
{body}
{T1_END}"""


def render_t7(rows: list[dict]) -> str:
    body = "\n".join(
        f"| 北京→{r['name']} | {r['n']:,} | {r['sigma_h']:.2f} h | {r['w']:.2f} | "
        + (f"{r['voacap']:.2f}" if not math.isnan(r["voacap"]) else "—")
        + f" | {r['raw']:.2f} | {r['full']:.2f} | {(1 - r['full'] / r['raw']) * 100:.1f} % |"
        for r in rows).replace(",", " ")
    return f"""{T7_BEGIN}
**表 5-8 正则化前后的评分抖动对比**

| 路径 | 训练支撑 | $\\sigma_h$ | $w$ | VOACAP | 未正则 | 完整方法 | 降幅 |
|---|---|---|---|---|---|---|---|
{body}
{T7_END}"""


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true")
    a = ap.parse_args()

    rows, n_hist, old_scale, rmse = collect()
    t1, t7 = render_t1(rows), render_t7(rows)
    if not a.write:
        print(t1 + "\n\n" + t7)
        print(f"\n（历史训练集 {n_hist:,} 条；未正则配置所用的旧可靠度尺度 {old_scale:.2f} dB）")
        return

    text = CH5.read_text(encoding="utf-8")
    for begin, end, block in ((T1_BEGIN, T1_END, t1), (T7_BEGIN, T7_END, t7)):
        if begin not in text or end not in text:
            raise SystemExit(f"未在 {CH5.name} 找到 {begin} … {end}")
        text = re.sub(re.escape(begin) + r".*?" + re.escape(end), lambda _: block,
                      text, flags=re.S)
    CH5.write_text(text, encoding="utf-8")
    print(f"已更新 {CH5.name} 的表 5-1 与表 5-8")


if __name__ == "__main__":
    main()
