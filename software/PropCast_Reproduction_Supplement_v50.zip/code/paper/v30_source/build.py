"""Build the versioned v30 manuscript from the editable chapter sources."""
from pathlib import Path
import re
import subprocess
import json
import sys
from html import escape
from format_docx import format_document

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else PAPER / "论文全文_去防御性修订版_v30.docx"
MD = HERE / "全文_v30_排版源.md"
REFERENCE = PAPER / "论文全文_格式规范版_v27.docx"
PAGE_MAP = HERE / "toc_pages.json"

def get(name):
    return (HERE / name).read_text(encoding="utf-8").strip()

def toc(chapters):
    pages = json.loads(PAGE_MAP.read_text(encoding="utf-8")) if PAGE_MAP.exists() else {}
    entries = []
    for chapter in chapters:
        for line in chapter.splitlines():
            match = re.match(r"^(#{1,2})\s+(.+)", line)
            if not match:
                continue
            level, heading = len(match.group(1)), match.group(2)
            heading = re.sub(r"\s*\{#[^}]+\}\s*$", "", heading)
            key_match = re.match(r"(\d+(?:\.\d+)?)", heading)
            if key_match:
                key = key_match.group(1)
            else:
                numerals = "一二三四五六"
                key = str(numerals.index(heading[1]) + 1)
            entries.append((level, heading, pages.get(key, "")))
    entries.extend([(1, "参考文献", pages.get("refs", "")), (1, "谢辞", pages.get("thanks", ""))])
    xml = []
    for level, heading, page in entries:
        indent = 0 if level == 1 else 320
        bold = "<w:b/>" if level == 1 else ""
        xml.append(
            '<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="exact"/>'
            f'<w:ind w:left="{indent}"/><w:tabs><w:tab w:val="right" w:leader="dot" w:pos="8350"/></w:tabs>'
            '</w:pPr><w:r><w:rPr><w:sz w:val="20"/>'+bold+'</w:rPr><w:t>'
            +escape(heading)+'</w:t></w:r><w:r><w:tab/></w:r>'
            '<w:r><w:rPr><w:sz w:val="20"/></w:rPr><w:t>'+str(page)+'</w:t></w:r></w:p>'
        )
    return "# 目录\n\n~~~{=openxml}\n" + "\n".join(xml) + "\n~~~"

def main():
    if OUT.exists():
        raise SystemExit(f"Output exists; preserve versioned file: {OUT}")
    abstract = get("00_摘要_v30.md")
    chapters = [get(f"ch{i}.md") for i in range(1, 7)]
    tail = [get("参考文献.md"), get("致谢.md")]
    parts = [abstract, toc(chapters), *chapters, *tail]
    MD.write_text("\n\n".join(parts) + "\n", encoding="utf-8")
    command = [
        r"C:\Program Files\Pandoc\pandoc.exe",
        str(MD), "-o", str(OUT),
        "--standalone", "--resource-path", str(HERE),
        "--reference-doc", str(REFERENCE),
        "--number-sections=false",
    ]
    print("Building", OUT)
    subprocess.run(command, check=True)
    format_document(OUT)
    print(OUT)

if __name__ == "__main__":
    main()
