"""Read-only descriptive audit for the v29 manuscript.

This script does not train or evaluate a model. Its output describes the frozen
local WSPR training table and the 2026-09-12 observation snapshot only.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "processed"
OUT = Path(__file__).with_name("coverage_audit.json")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def pct(value: int, denominator: int) -> float:
    return round(100 * value / denominator, 3)


def dist_bins(series: pd.Series) -> dict[str, dict[str, float | int]]:
    limits = [0, 2000, 5000, 10000, 14000, np.inf]
    labels = ["lt_2000", "2000_4999", "5000_9999", "10000_13999", "ge_14000"]
    binned = pd.cut(series, limits, labels=labels, right=False)
    counts = binned.value_counts(sort=False)
    return {str(k): {"n": int(v), "pct": pct(int(v), len(series))} for k, v in counts.items()}


def temporal_summary(frame: pd.DataFrame) -> dict:
    dates = pd.to_datetime(frame["ts"], unit="s", utc=True)
    month = dates.dt.month.value_counts().sort_index()
    year = dates.dt.year.value_counts().sort_index()
    hour = dates.dt.hour.value_counts().sort_index()
    return {
        "start_utc": str(dates.min()),
        "end_utc": str(dates.max()),
        "year_counts": {str(k): int(v) for k, v in year.items()},
        "month_counts": {str(k): int(v) for k, v in month.items()},
        "hour_counts": {str(k): int(v) for k, v in hour.items()},
    }


def main() -> None:
    hist_path = DATA / "dataset_multiyear.parquet"
    live_path = DATA / "observations.parquet"
    hist = pd.read_parquet(hist_path, columns=["ts", "distance_km", "band", "freq_mhz", "ssn", "voacap_snr"])
    live = pd.read_parquet(live_path, columns=["ts", "distance_km", "band", "freq_mhz", "ssn", "kp", "source", "mode", "trusted", "rx_call", "tx_call", "voacap_snr"])
    receiver_names = live["rx_call"].dropna().astype(str).str.strip()
    receivers = receiver_names[receiver_names.ne("")].value_counts()
    top_1pct = max(1, int(np.ceil(0.01 * len(receivers))))
    top_10 = receivers.head(10)
    output = {
        "scope": "Descriptive only; no model comparison, reliability calibration or population inference.",
        "files": {
            hist_path.name: {"sha256": sha256(hist_path), "rows": len(hist)},
            live_path.name: {"sha256": sha256(live_path), "rows": len(live)},
        },
        "history": {
            "temporal": temporal_summary(hist),
            "distance": dist_bins(hist["distance_km"]),
            "bands": {str(k): int(v) for k, v in hist["band"].value_counts().items()},
            "ssn_missing": int(hist["ssn"].isna().sum()),
            "voacap_floor_or_below": int((hist["voacap_snr"] <= -120).sum()),
        },
        "observation_snapshot": {
            "temporal": temporal_summary(live),
            "distance": dist_bins(live["distance_km"]),
            "sources": {str(k): int(v) for k, v in live["source"].value_counts(dropna=False).items()},
            "modes": {str(k): int(v) for k, v in live["mode"].value_counts(dropna=False).items()},
            "trusted": {str(k): int(v) for k, v in live["trusted"].value_counts(dropna=False).items()},
            "bands": {str(k): int(v) for k, v in live["band"].value_counts(dropna=False).items()},
            "ssn_missing": int(live["ssn"].isna().sum()),
            "kp_missing": int(live["kp"].isna().sum()),
            "voacap_floor_or_below": int((live["voacap_snr"] <= -120).sum()),
            "unique_receivers": int(len(receivers)),
            "top_1pct_receivers_n": top_1pct,
            "top_1pct_receivers_share_pct": pct(int(receivers.head(top_1pct).sum()), len(live)),
            "top_10_receivers_share_pct": pct(int(top_10.sum()), len(live)),
            "top_receiver_rows": int(receivers.iloc[0]),
        },
    }
    OUT.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(OUT)


if __name__ == "__main__":
    main()
