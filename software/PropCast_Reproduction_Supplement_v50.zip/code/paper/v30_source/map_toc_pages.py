"""Create static contents page numbers from the rendered v30 PDF."""
from pathlib import Path
import json
import re
import pdfplumber
import sys

HERE = Path(__file__).resolve().parent
PDF = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / "_qa_v30_draft" / "论文全文_去防御性修订版_v30_draft.pdf"
OUT = HERE / "toc_pages.json"
text_pages = []
with pdfplumber.open(PDF) as pdf:
    text_pages = [(page.extract_text() or "") for page in pdf.pages]

body_start = next(
    i for i, text in enumerate(text_pages)
    if i >= 2 and re.search(r"(?m)^第一章\s+", text)
)
headings = []
for chapter in range(1, 7):
    source = (HERE / f"ch{chapter}.md").read_text(encoding="utf-8")
    headings.append((str(chapter), ""))
    headings.extend(re.findall(r"(?m)^##\s+(\d+\.\d+)\s+([^\n{]+)", source))
headings.extend([("refs", ""), ("thanks", "")])

pages = {}
for key, title in headings:
    if key.isdigit():
        chinese = "一二三四五六"[int(key)-1]
        pattern = rf"(?m)^第{chinese}章\s+"
    elif key == "refs":
        pattern = r"(?m)^参考文献\s*$"
    elif key == "thanks":
        pattern = r"(?m)^谢辞\s*$"
    else:
        pattern = rf"(?m)^{re.escape(key)}\s+{re.escape(title.strip()[:4])}"
    found = [i for i in range(body_start, len(text_pages)) if re.search(pattern, text_pages[i])]
    if len(found) != 1:
        raise RuntimeError(f"{key}: expected one heading page, got {found}")
    pages[key] = found[0] - body_start + 1

OUT.write_text(json.dumps(pages, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"Mapped {len(pages)} contents entries; chapter starts: {[pages[str(i)] for i in range(1, 7)]}")
