"""Apply the small, reproducible table layout fixes after Pandoc export."""

from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt


WIDTHS_CM = {
    5: [2.5, 6.4, 4.7],       # Table 2-5: feature class should not wrap per character.
    6: [2.4, 3.7, 3.7, 3.8],
    7: [2.3, 2.4, 2.4, 6.5],
    9: [2.6, 1.8, 2.7, 2.3, 2.1, 2.1],
    16: [2.6, 1.8, 1.5, 1.2, 2.0, 1.55, 1.95, 1.4],
    17: [2.55, 3.55, 3.6, 3.9],
    23: [4.2, 1.95, 7.45],
}
START_NEW_PAGE = ('表2-6 ', '表3-8 ', '表3-10 ')


def format_document(path: Path) -> None:
    doc = Document(path)
    if len(doc.tables) != 27:
        raise ValueError(f'Expected 27 tables, found {len(doc.tables)}')

    for number, table in enumerate(doc.tables, 1):
        table.autofit = False
        if number in WIDTHS_CM:
            widths = WIDTHS_CM[number]
            if len(widths) != len(table.columns):
                raise ValueError(f'Table {number} column count changed')
            for column, width in zip(table.columns, widths):
                column.width = Cm(width)
            for row in table.rows:
                for cell, width in zip(row.cells, widths):
                    cell.width = Cm(width)

        if number == 7:
            labels = ('参数', '离线实验', '生产快照', '说明')
            for cell, label in zip(table.rows[0].cells, labels):
                cell.text = label
                for run in cell.paragraphs[0].runs:
                    run.bold = True

        # A row must remain intact; a continued table repeats its heading.
        for row_index, row in enumerate(table.rows):
            row.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tr_pr = row._tr.get_or_add_trPr()
            if tr_pr.find(qn('w:cantSplit')) is None:
                tr_pr.append(OxmlElement('w:cantSplit'))
            if row_index == 0 and tr_pr.find(qn('w:tblHeader')) is None:
                tr_pr.append(OxmlElement('w:tblHeader'))
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    paragraph.paragraph_format.space_before = Cm(0)
                    paragraph.paragraph_format.space_after = Cm(0)
                    if row_index == 0:
                        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    if number == 17:
                        for run in paragraph.runs:
                            run.font.size = Pt(10.5)

    in_references = False
    for paragraph in doc.paragraphs:
        if paragraph.text == '参考文献':
            in_references = True
        elif paragraph.text == '谢辞':
            in_references = False
        elif in_references:
            # Keep the bibliography together without shrinking the main text.
            for run in paragraph.runs:
                run.font.size = Pt(9.5)
        if paragraph.style.name == 'Heading 1' and (
            paragraph.text == '目录'
            or paragraph.text.startswith(('第一章', '第二章', '第三章', '第四章', '第五章', '第六章'))
            or paragraph.text in ('参考文献', '谢辞')
        ):
            paragraph.paragraph_format.page_break_before = True
        if paragraph.text.startswith(START_NEW_PAGE):
            paragraph.paragraph_format.page_break_before = True
            paragraph.paragraph_format.keep_with_next = True

    doc.save(path)


if __name__ == '__main__':
    import sys
    format_document(Path(sys.argv[1]))
