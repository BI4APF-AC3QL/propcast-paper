"""Check the frozen v30 manuscript and its rendered delivery artifacts."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from zipfile import ZipFile

from docx import Document
from pypdf import PdfReader


ROOT = Path(__file__).resolve().parent
PAPER = ROOT.parent
DOCX = PAPER / "论文全文_去防御性修订版_v30.docx"
QA = PAPER / "_qa_v30_final_verified_76"
PDF = QA / "论文全文_去防御性修订版_v30.pdf"
RESULT = ROOT / "final_qa_v30.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    chapters = [(ROOT / f"ch{i}.md").read_text(encoding="utf-8") for i in range(1, 7)]
    han_counts = [len(re.findall(r"[\u3400-\u9fff]", chapter)) for chapter in chapters]
    cited = {
        int(number)
        for chapter in chapters
        for number in re.findall(r"\^\\\[(\d+)\\\]\^", chapter)
    }
    references = (ROOT / "参考文献.md").read_text(encoding="utf-8")
    reference_numbers = [int(n) for n in re.findall(r"(?m)^\\\[(\d+)\\\]", references)]
    toc = json.loads((ROOT / "toc_pages.json").read_text(encoding="utf-8"))
    doc = Document(DOCX)
    chapter_titles = [f"第{n}章" for n in "一二三四五六"]
    chapter_title_counts = {
        title: sum(
            paragraph.style.name == "Heading 1" and paragraph.text.startswith(title)
            for paragraph in doc.paragraphs
        )
        for title in chapter_titles
    }
    with ZipFile(DOCX) as archive:
        broken_zip_entry = archive.testzip()
        media = [name for name in archive.namelist() if name.startswith("word/media/")]
    pngs = list(QA.glob("page-*.png"))
    page_numbers = sorted(int(path.stem.removeprefix("page-")) for path in pngs)
    pdf_pages = len(PdfReader(PDF).pages)
    checks = {
        "docx_zip_integrity": broken_zip_entry is None,
        "six_chapter_titles_once": all(count == 1 for count in chapter_title_counts.values()),
        "tables_27": len(doc.tables) == 27,
        "inline_figures_12": len(doc.inline_shapes) == 12,
        "reference_sequence_1_to_23": reference_numbers == list(range(1, 24)),
        "all_references_cited": cited == set(reference_numbers),
        "toc_entries_103": len(toc) == 103,
        "toc_final_pages": toc.get("refs") == 72 and toc.get("thanks") == 73,
        "pdf_pages_76": pdf_pages == 76,
        "png_pages_1_to_76": page_numbers == list(range(1, 77)),
    }
    report = {
        "source_scope": "Six editable chapter Markdown files; Han characters only, including headings, tables, and captions; excludes abstract, bibliography, contents and markup.",
        "han_counts_by_chapter": dict(zip(chapter_titles, han_counts)),
        "han_count_total": sum(han_counts),
        "docx_sha256": sha256(DOCX),
        "pdf_sha256": sha256(PDF),
        "docx_tables": len(doc.tables),
        "docx_media": len(media),
        "inline_shapes": len(doc.inline_shapes),
        "chapter_title_counts": chapter_title_counts,
        "reference_numbers": reference_numbers,
        "cited_reference_numbers": sorted(cited),
        "toc_entry_count": len(toc),
        "toc_page_map": toc,
        "pdf_pages": pdf_pages,
        "png_pages": len(pngs),
        "checks": checks,
        "pass": all(checks.values()),
    }
    RESULT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "toc_page_map"}, ensure_ascii=False, indent=2))
    if not report["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
