"""Summarize stored per-fold experiment outputs without retraining models."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "processed"
OUT = Path(__file__).with_name("fold_summary.json")


def hash_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def summary(values: pd.Series) -> dict:
    x = values.to_numpy(dtype=float)
    return {
        "mean_pct": round(float(x.mean()), 6),
        "median_pct": round(float(np.median(x)), 6),
        "min_pct": round(float(x.min()), 6),
        "max_pct": round(float(x.max()), 6),
        "positive_folds": int(np.sum(x > 0)),
        "negative_folds": int(np.sum(x < 0)),
        "n_folds": int(len(x)),
    }


def main() -> None:
    cv_path = DATA / "_exp_cv.csv"
    ab_path = DATA / "_exp_ablation.csv"
    sh_path = DATA / "_exp_shrink.csv"
    cv, ab, sh = (pd.read_csv(p) for p in (cv_path, ab_path, sh_path))
    if not (cv["fold"].tolist() == ab["fold"].tolist() == sh["fold"].tolist()):
        raise ValueError("Fold order differs across stored outputs")
    output = {
        "scope": "Descriptive reanalysis of saved 12-fold outputs; no new model training or independent significance test.",
        "sha256": {p.name: hash_file(p) for p in (cv_path, ab_path, sh_path)},
        "base_rmse_db": {
            "mean": round(float(cv["base"].mean()), 6),
            "median": round(float(cv["base"].median()), 6),
            "min": round(float(cv["base"].min()), 6),
            "max": round(float(cv["base"].max()), 6),
        },
        "h4_improvement": summary(cv["h4.0"]),
        "f02_improvement": summary(cv["f0.2"]),
        "extended_features_improvement": summary(100 * (ab["完整"] - ab["v2扩展"]) / ab["完整"]),
        "zero_voacap_improvement": summary(100 * (ab["完整"] - ab["去VOACAP基线"]) / ab["完整"]),
        "shrink_alpha_095_improvement": summary(-sh["a0.95"]),
    }
    OUT.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(OUT)


if __name__ == "__main__":
    main()
