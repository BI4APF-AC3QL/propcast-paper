"""生成第 6 章的闭环运行状态快照（表 6-1 与 6.5 节的数值）。

为什么要有这个脚本：第 6 章引用的是一个**持续运行**系统的瞬时状态。系统每 15 分钟
采集一批、通常累计两批（约 30 分钟）重训一次，因此手工写进正文的数字必然越放越旧——本文撰写期间已
出现过一次（2 234 → 8 733 → …）。把这些数字改为脚本生成并**显式标注数据截止时间**，
既避免内部不一致，也让审稿人能复算。

    python paper/snapshot_system_state.py            # 打印 Markdown 片段
    python paper/snapshot_system_state.py --write    # 直接写回 ch6 的对应段落

写回采用标记块定位（<!-- SNAPSHOT:BEGIN --> … <!-- SNAPSHOT:END -->），
不依赖行号，正文其余部分不受影响。
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
# 脚本按 README 从项目根目录直接运行时，Python 只把 paper/ 放进
# sys.path。项目模块必须在顶层导入前显式加入，否则命令本身不可复现。
import sys
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "backend"))

from models.features import apply_baseline_floor

CH3 = Path(__file__).parent / "ch3_数据与特征.md"
CH6 = Path(__file__).parent / "ch6_众包持续学习系统.md"
BEGIN, END = "<!-- SNAPSHOT:BEGIN -->", "<!-- SNAPSHOT:END -->"
X_BEGIN, X_END = "<!-- XSOURCE:BEGIN -->", "<!-- XSOURCE:END -->"


def settings_new_train_frac() -> float:
    """生产使用的新数据放入比例；取不到配置时退回代码默认值。"""
    try:
        from propcast.config import settings

        return float(settings.retrain_new_train_frac)
    except Exception:  # noqa: BLE001 —— 脚本可在无后端依赖时运行
        return 0.5


def _vals(hist: list[dict], key: str) -> list[float]:
    """取某字段的全部有效数值。缺失/为 null 的记录直接跳过——重建在役基线或
    冷启动时没有可比的在役模型，该字段为 null，混进极值计算会直接报错。"""
    return [h[key] for h in hist if isinstance(h.get(key), (int, float))]


def collect() -> dict:
    from data.obs_store import TRUSTED_SOURCES

    obs = apply_baseline_floor(pd.read_parquet(ROOT / "data/processed/observations.parquet"))
    hist = [json.loads(l) for l in
            open(ROOT / "data/processed/retrain_history.jsonl", encoding="utf-8")]
    mul = apply_baseline_floor(pd.read_parquet(ROOT / "data/processed/dataset_multiyear.parquet"))

    # 可信测试集的构成。**必须调用生产代码的切分函数**，不要在这里另写一份：
    # 此处原本硬编码了「全表按时间取后 20%」，而生产已改为按来源分层切分
    # （models/retrain.split_by_source），于是本表报出的测试集构成与门槛实际
    # 使用的那一份对不上，正文却拿它解释门槛的行为。
    from models.retrain import split_by_source

    mul2 = mul[["residual", "ts"]].copy()
    mul2["source"] = "wspr-historical"
    both = pd.concat([mul2, obs[["residual", "ts", "source"]]], ignore_index=True)
    both["trusted"] = both["source"].isin(TRUSTED_SOURCES)
    both = both[np.isfinite(both["residual"])].sort_values("ts").reset_index(drop=True)
    _, _, te = split_by_source(both, settings_new_train_frac())
    tt = te[te["trusted"]]
    n_new_in_test = int((tt["source"] == "pskreporter").sum())

    # “数据截止”必须来自实际产物，而不能使用脚本执行时钟。否则采集循环停摆时，
    # 论文会把一个没有新增数据的时刻误写成最新数据时刻。观测和重训记录取较晚者，
    # 并统一按 UTC 精确到分钟展示。
    obs_ts = obs["ts"]
    if pd.api.types.is_numeric_dtype(obs_ts):
        # observations.parquet 的生产字段为 Unix 秒；不指定 unit 会被 pandas
        # 当作纳秒解析到 1970 年。
        obs_cutoff = pd.to_datetime(obs_ts, unit="s", utc=True, errors="coerce").max()
    else:
        obs_cutoff = pd.to_datetime(obs_ts, utc=True, errors="coerce").max()
    hist_cutoff = max(
        (pd.Timestamp(h["at"]) for h in hist if h.get("at")),
        default=pd.NaT,
    )
    cutoff = max(t for t in (obs_cutoff, hist_cutoff) if not pd.isna(t))

    return {
        "hist": hist,
        "cutoff": cutoff.tz_convert("UTC").strftime("%Y-%m-%d %H:%M UTC"),
        "total": len(obs),
        "trusted": int(obs["source"].isin(TRUSTED_SOURCES).sum()),
        "contributed": int((~obs["source"].isin(TRUSTED_SOURCES)).sum()),
        "stations": int(obs["rx_call"].replace("", None).nunique()),
        "n_retrain": len(hist),
        "n_promoted": sum(h["promoted"] for h in hist),
        # 重建在役基线那一次没有可比的在役模型，incumbent_rmse 为 null；
        # 首轮冷启动同理。取极值前必须滤掉，否则整个脚本崩在这里。
        "cand_lo": min(_vals(hist, "rmse"), default=float("nan")),
        "cand_hi": max(_vals(hist, "rmse"), default=float("nan")),
        "inc_lo": min(_vals(hist, "incumbent_rmse"), default=float("nan")),
        "inc_hi": max(_vals(hist, "incumbent_rmse"), default=float("nan")),
        "n_hist": len(mul),
        "share_new": len(obs) / len(mul) * 100,
        "test_total": len(tt),
        "test_new": n_new_in_test,
        "test_new_pct": n_new_in_test / len(tt) * 100,
        # 3.3 节的跨数据源口径校验：两个来源各自的残差中位数。
        # 二者不应相等——PSKReporter 无发射功率字段，统一按 50 W 处理，
        # 而 WSPR 实际为毫瓦级，该假设必然使残差系统性偏负。
        "res_hist": float(mul["residual"].median()),
        "res_new": float(obs.loc[obs["source"] == "pskreporter", "residual"].median()),
        "n_new_psk": int((obs["source"] == "pskreporter").sum()),
    }


def _n(v: int) -> str:
    """千分位用空格，与全文（如 93 500）一致。"""
    return f"{v:,}".replace(",", " ")


def _chart_stats(hist: list[dict]) -> tuple[int, int]:
    """返回图 4-2 使用的记录数和上线数；排除已知受污染时段。"""
    bad_start = pd.Timestamp("2026-08-11T08:48:59Z")
    bad_end = pd.Timestamp("2026-08-12T13:30:00Z")
    keep = []
    for row in hist:
        at = pd.Timestamp(row["at"])
        if at < bad_start or at > bad_end:
            keep.append(row)
    return len(keep), sum(bool(row.get("promoted")) for row in keep)


def render_xsource(s: dict) -> str:
    """2.3 节的跨数据源口径校验段落。"""
    gap = abs(s["res_hist"] - s["res_new"])
    return f"""{X_BEGIN}
为消除实现路径造成的口径分叉，历史建库与持续采集复用同一单点基线计算函数。该风险并非假设：早期采集程序曾对全部波段误用 20 m 参数，导致该批观测的残差相对历史训练分布偏移约 20 dB。修正后，历史 WSPR 训练集的残差中位数为 ${s['res_hist']:.1f}$ dB（{_n(s['n_hist'])} 条），持续采集的 PSKReporter 观测为 ${s['res_new']:.1f}$ dB（{_n(s['n_new_psk'])} 条，数据截止 {s['cutoff']}），两者相差 {gap:.1f} dB。

两组中位数**没有相等的理论预期**。PSKReporter 缺少发射功率字段，本文按 50 W 统一赋值（2.1 节）；WSPR 的实际功率则处于毫瓦至数瓦量级，该近似会使新数据残差呈系统性负偏。此处能够核查的是错误基线口径所造成的数量级偏移是否消失：口径错误时差异约 20 dB，修复后降至 {gap:.1f} dB。剩余差异的方向与功率假设相容，但模式、参考带宽、设备和上报机制的异质性仍构成竞争解释；该比较不足以证明两种观测机制已完全同分布。
{X_END}"""


def render(s: dict) -> str:
    # 措辞必须随实际上线次数走。此处曾写死"无一通过准入门槛"，在第一次上线
    # 发生后与同表的计数直接矛盾——生成式表格配手写断言就会这样对不上。
    n_rej = s["n_retrain"] - s["n_promoted"]
    if s["n_promoted"] == 0:
        verdict = (f"**必须如实说明：闭环运行至今未带来任何精度提升。** "
                   f"{s['n_retrain']} 次自动重训的候选模型全部劣于在役模型，"
                   f"无一通过准入门槛。")
        drift = "在役产物自始至终未被替换过，其参数完全没有改变"
    else:
        times = "一次" if s["n_promoted"] == 1 else f" {s['n_promoted']} 次"
        verdict = (f"**闭环已产生{times}模型更替。** {_n(s['n_retrain'])} 次自动重训中，"
                   f"{_n(s['n_promoted'])} 次通过准入门槛并替换了在役产物，"
                   f"其余 {_n(n_rej)} 次被拒绝。修正前后的对照见 4.5.2 节。")
        drift = (f"在役产物在此期间仅被替换 {s['n_promoted']} 次，"
                 f"曲线的其余变化并非来自模型改动")
    # 只有一条记录时谈不上"随重训次数变化"；硬套那句话会得到
    # "12.23 → 12.23 dB 上升"这种自相矛盾的图注。
    if s["n_retrain"] <= 1:
        trend = "记录重建后至今仅完成一次重训，尚不足以呈现趋势。"
    else:
        trend = (f"图中在役模型的 RMSE 由 {s['inc_lo']:.2f} 变化至 {s['inc_hi']:.2f} dB，"
                 f"但{drift}——变化主要来自测试集构成本身。")
    chart_n, chart_promoted = _chart_stats(s["hist"])
    return f"""{BEGIN}
**表 4-2 持续学习闭环运行状态（数据截止 {s['cutoff']}）**

| 项目 | 数值 |
|---|---|
| 累积观测 | {_n(s['total'])} 条 |
| 后端自采（可信） | {_n(s['trusted'])} 条 |
| 用户贡献 | {_n(s['contributed'])} 条 |
| 覆盖接收站点 | {_n(s['stations'])} 个 |
| 自动重训次数 | {_n(s['n_retrain'])} |
| **通过门槛上线次数** | **{_n(s['n_promoted'])}** |

```{{=openxml}}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

**续表 4-2**

| 项目 | 数值 |
|---|---|
| 候选模型 RMSE 范围 | {s['cand_lo']:.2f} – {s['cand_hi']:.2f} dB |
| 在役模型 RMSE（实测） | {s['inc_lo']:.2f} – {s['inc_hi']:.2f} dB |

> 本表由 `python paper/snapshot_system_state.py` 生成。系统持续运行，各项计数随时间增长；定稿时应重新生成一次并以此处标注的截止时间为准。

{verdict}清理后的可比重训记录见图 4-2。截至数据截止时刻，新观测已达历史数据的 {s['share_new']:.1f} %。

![](figures/fig6-2_重训记录.png)

**图 4-2** 闭环重训与准入记录（图像剔除 2026-08-11 08:48:59 至 2026-08-12 13:30:00 UTC 的受污染记录后，共 {_n(chart_n)} 次自动重训，其中 {_n(chart_promoted)} 次上线；可信测试集；RMSE 单位：dB）：蓝色圆线为在役模型 RMSE，红色方虚线为候选模型 RMSE，浅红阴影表示候选劣于在役，绿色星标表示通过准入并上线，绿色点虚线表示累计训练样本数（千条）；横轴为自动重训序号。图中 RMSE 轨迹用于记录运行状态，不用于跨轮次比较模型质量；截至数据截止时刻，可信测试集共 {_n(s['test_total'])} 条，其中 {_n(s['test_new'])} 条（{s['test_new_pct']:.0f} %）来自新采集的数据。
{END}"""


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true", help="写回 ch6 的标记块")
    a = ap.parse_args()

    s = collect()
    block, xblock = render(s), render_xsource(s)
    if not a.write:
        print(block)
        print()
        print(xblock)
        return

    for path, beg, end, blk in ((CH6, BEGIN, END, block),
                                (CH3, X_BEGIN, X_END, xblock)):
        text = path.read_text(encoding="utf-8")
        if beg not in text or end not in text:
            raise SystemExit(f"未在 {path.name} 中找到 {beg} … {end} 标记块")
        new = re.sub(re.escape(beg) + r".*?" + re.escape(end), lambda _: blk,
                     text, flags=re.S)
        path.write_text(new, encoding="utf-8")
        print(f"已更新 {path.name} 的快照块")

    # 图 6-2 画的是同一份重训记录，必须与表 6-1 同时刷新。否则系统只要再重训一次，
    # 图注里的次数就与表对不上——实测两者在数分钟内即可错位。
    import subprocess

    subprocess.run([sys.executable, str(Path(__file__).parent / "figures" / "make_ch6_figs.py")],
                   cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
